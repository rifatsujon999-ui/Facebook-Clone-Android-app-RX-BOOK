# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# 🔒 RX BOOK Cryptographic Obfuscation & R8 Optimization Strategy
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Retain line numbers and sanitize source file attribute for Play Console crash symbol mapping
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# 🛡️ Model Safety & Deserialization Guard
# Prevents R8 from shrinking or mutating network models and UI component reflection hooks
-keep class com.rxbook.app.models.** { *; }
-keep class com.example.models.** { *; }
-keep class com.example.ui.components.** { *; }

# ⚡ Socket & Media Memory Pipeline Warnings
# Silences downstream warnings from network/real-time signaling frameworks during dead-code stripping
-dontwarn okhttp3.**
-dontwarn io.socket.**
-dontwarn retrofit2.**


