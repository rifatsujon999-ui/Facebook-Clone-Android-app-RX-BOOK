package com.example.data

import com.example.R
import com.example.model.ChatConversation
import com.example.model.ChatMessage
import com.example.model.NotificationItem
import com.example.model.ReactionType
import com.example.model.SocialComment
import com.example.model.SocialPost
import com.example.model.SocialStory
import com.example.model.SocialUser
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

object RxBookRepository {

  var currentUser = SocialUser(
    id = "user_me",
    username = "alex_mercer",
    displayName = "Alex Mercer",
    avatarDrawableRes = R.drawable.rx_book_app_icon_1789358378841,
    avatarUrl = null,
    email = "",
    phone = "",
    bio = "Senior Software Architect & Digital Creator 🚀 Building scalable ecosystems for 2027.",
    isVerified = true,
    isOnline = true,
    followersCount = 8420,
    followingCount = 412,
    friendsCount = 980
  )

  fun refreshCurrentUserFromFirebase(onComplete: ((SocialUser) -> Unit)? = null) {
    try {
      val authUser = Firebase.auth.currentUser
      if (authUser == null) {
        onComplete?.invoke(currentUser)
        return
      }

      val fallbackName = authUser.displayName?.ifBlank { null } ?: currentUser.displayName
      val fallbackEmail = authUser.email ?: currentUser.email
      val fallbackPhoto = authUser.photoUrl?.toString() ?: currentUser.avatarUrl

      FirebaseFirestore.getInstance()
        .collection("users")
        .document(authUser.uid)
        .get()
        .addOnSuccessListener { doc ->
          if (doc != null && doc.exists()) {
            val name = doc.getString("name")?.ifBlank { null } ?: fallbackName
            val email = doc.getString("email")?.ifBlank { null } ?: fallbackEmail
            val phone = doc.getString("phone") ?: currentUser.phone
            val photoUrl = doc.getString("photoUrl")?.ifBlank { null } ?: fallbackPhoto

            currentUser = currentUser.copy(
              id = authUser.uid,
              displayName = name,
              email = email,
              phone = phone,
              avatarUrl = photoUrl
            )
          } else {
            currentUser = currentUser.copy(
              id = authUser.uid,
              displayName = fallbackName,
              email = fallbackEmail,
              avatarUrl = fallbackPhoto
            )
          }
          onComplete?.invoke(currentUser)
        }
        .addOnFailureListener {
          currentUser = currentUser.copy(
            id = authUser.uid,
            displayName = fallbackName,
            email = fallbackEmail,
            avatarUrl = fallbackPhoto
          )
          onComplete?.invoke(currentUser)
        }
    } catch (e: Exception) {
      onComplete?.invoke(currentUser)
    }
  }

  val sampleUsers = listOf(
    SocialUser(
      id = "user_1",
      username = "sophia_chen",
      displayName = "Sophia Chen",
      avatarDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      bio = "Distributed Systems Engineer @ FinTech | AI Researcher",
      isVerified = true,
      isOnline = true,
      followersCount = 14200,
      followingCount = 310,
      friendsCount = 1250,
      friendshipStatus = "FRIENDS"
    ),
    SocialUser(
      id = "user_2",
      username = "marcus_vance",
      displayName = "Marcus Vance",
      avatarDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      bio = "National Geographic Explorer & Landscape Filmmaker 🏔️",
      isVerified = true,
      isOnline = false,
      followersCount = 48500,
      followingCount = 190,
      friendsCount = 840,
      friendshipStatus = "FRIENDS"
    ),
    SocialUser(
      id = "user_3",
      username = "elena_rostova",
      displayName = "Elena Rostova",
      avatarDrawableRes = R.drawable.luxury_modern_villa_1789284896961,
      bio = "Spatial UX Designer & Creative Technologist in Tokyo",
      isVerified = false,
      isOnline = true,
      followersCount = 3200,
      followingCount = 420,
      friendsCount = 512,
      friendshipStatus = "PENDING"
    )
  )

  val sampleStories = listOf(
    SocialStory(
      id = "story_me",
      user = currentUser,
      mediaDrawableRes = R.drawable.rx_book_app_icon_1789358378841,
      isUserStory = true,
      hasUnseen = false
    ),
    SocialStory(
      id = "story_1",
      user = sampleUsers[1],
      mediaDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      hasUnseen = true
    ),
    SocialStory(
      id = "story_2",
      user = sampleUsers[0],
      mediaDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      hasUnseen = true
    ),
    SocialStory(
      id = "story_3",
      user = sampleUsers[2],
      mediaDrawableRes = R.drawable.luxury_modern_villa_1789284896961,
      hasUnseen = false
    )
  )

  val initialPosts = listOf(
    SocialPost(
      id = "post_video_1",
      author = sampleUsers[1], // Marcus Vance
      content = "🎬 [Stream Pipeline] Captured raw 4K cinematic footage of drone navigation over neon skyscraper rooftops. Processed via RX BOOK Adaptive Bitrate Engine with zero CLS layout clamping! 🌆✨ #VeoAI #AIVideo #Cinematic",
      mediaDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      videoUrl = "https://vjs.zencdn.net/v/oceans.mp4",
      videoAspectRatio = "16:9",
      isAiGenerated = true,
      timeAgo = "Just now",
      reactionCounts = mapOf(
        ReactionType.LOVE to 482,
        ReactionType.LIKE to 310,
        ReactionType.WOW to 142
      ),
      userReaction = ReactionType.LOVE,
      commentsCount = 53,
      sharesCount = 38,
      visibility = "PUBLIC"
    ),
    SocialPost(
      id = "post_video_2",
      author = sampleUsers[0], // Sophia Chen
      content = "⚡ Real-time stream telemetry check! Sliced into 3-second segments with pre-buffered HLS endpoints. Smooth 60 FPS playback on Compose without main-thread jank. 🎥🚀 #VideoStreaming #HLS #AndroidDev",
      mediaDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
      videoAspectRatio = "16:9",
      isAiGenerated = false,
      timeAgo = "1 hr ago",
      reactionCounts = mapOf(
        ReactionType.LIKE to 619,
        ReactionType.LOVE to 287,
        ReactionType.WOW to 88
      ),
      userReaction = ReactionType.LIKE,
      commentsCount = 92,
      sharesCount = 45,
      visibility = "PUBLIC"
    ),
    SocialPost(
      id = "post_1",
      author = sampleUsers[1], // Marcus
      content = "Dawn over Moraine Lake in the Canadian Rockies. The glacial turquoise water was like glass at 5:30 AM before the valley winds picked up. Captured with 100mm cine prime. 🏔️✨ #Travel #NaturePhotography #Wilderness",
      mediaDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      timeAgo = "2 hrs ago",
      reactionCounts = mapOf(
        ReactionType.LOVE to 342,
        ReactionType.LIKE to 184,
        ReactionType.WOW to 95
      ),
      userReaction = ReactionType.LOVE,
      commentsCount = 48,
      sharesCount = 29,
      visibility = "PUBLIC"
    ),
    SocialPost(
      id = "post_2",
      author = sampleUsers[0], // Sophia
      content = "Just merged our distributed caching rewrite to production! Swapped strict 15-minute TTLs with randomized Redis Jitter (15m + rand(1, 60)s). P99 database read latency dropped from 84ms to 9.2ms. Zero thundering herds during the morning traffic peak. 🚀⚡ #SoftwareEngineering #Redis #DistributedSystems",
      mediaDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      timeAgo = "4 hrs ago",
      reactionCounts = mapOf(
        ReactionType.LIKE to 520,
        ReactionType.LOVE to 215,
        ReactionType.HAHA to 14
      ),
      userReaction = ReactionType.LIKE,
      commentsCount = 76,
      sharesCount = 64,
      visibility = "PUBLIC"
    ),
    SocialPost(
      id = "post_3",
      author = sampleUsers[2], // Elena
      content = "Reflecting on architectural spatial transitions in residential design. Cantilevered acoustics glass with deep emerald landscape integration creates an entirely different state of focus. Thoughts on minimal vs maximal living spaces? 📐🏛️",
      mediaDrawableRes = R.drawable.luxury_modern_villa_1789284896961,
      timeAgo = "6 hrs ago",
      reactionCounts = mapOf(
        ReactionType.LIKE to 129,
        ReactionType.LOVE to 88,
        ReactionType.WOW to 31
      ),
      userReaction = null,
      commentsCount = 22,
      sharesCount = 11,
      visibility = "PUBLIC"
    )
  )

  val sampleComments = mapOf(
    "post_1" to listOf(
      SocialComment(
        id = "c_1",
        postId = "post_1",
        author = sampleUsers[0],
        content = "The lighting reflection on the lake bed is unreal! What shutter angle did you run for this?",
        timeAgo = "1 hr ago",
        likesCount = 18,
        isLiked = true
      ),
      SocialComment(
        id = "c_2",
        postId = "post_1",
        author = currentUser,
        content = "Bucket list destination. Absolutely pristine colors Marcus!",
        timeAgo = "45m ago",
        likesCount = 9,
        isLiked = false
      )
    ),
    "post_2" to listOf(
      SocialComment(
        id = "c_3",
        postId = "post_2",
        author = sampleUsers[2],
        content = "Cache stampede prevention is so often overlooked until scale breaks it. Fantastic write-up Sophia!",
        timeAgo = "3 hrs ago",
        likesCount = 42,
        isLiked = true
      )
    )
  )

  val sampleConversations = listOf(
    ChatConversation(
      id = "conv_1",
      partner = sampleUsers[0], // Sophia
      lastMessage = "Let's review the gRPC payload benchmarks at 3 PM!",
      lastMessageTime = "12:42 PM",
      unreadCount = 2,
      isTyping = true
    ),
    ChatConversation(
      id = "conv_2",
      partner = sampleUsers[1], // Marcus
      lastMessage = "Sent you the raw 4K stills from Banff.",
      lastMessageTime = "Yesterday",
      unreadCount = 0,
      isTyping = false
    ),
    ChatConversation(
      id = "conv_3",
      partner = sampleUsers[2], // Elena
      lastMessage = "The design mockups for the new social profile look clean!",
      lastMessageTime = "2d ago",
      unreadCount = 0,
      isTyping = false
    )
  )

  val sampleMessages = mapOf(
    "conv_1" to listOf(
      ChatMessage("m_1", "conv_1", "user_1", "Hey Alex, did you check the new BullMQ image queue?", "12:30 PM", isFromMe = false),
      ChatMessage("m_2", "conv_1", "user_me", "Yes! AVIF compression with 4-component BlurHash is working smoothly.", "12:35 PM", isFromMe = true),
      ChatMessage("m_3", "conv_1", "user_1", "Awesome. Let's review the gRPC payload benchmarks at 3 PM!", "12:42 PM", isFromMe = false)
    )
  )

  val sampleNotifications = listOf(
    NotificationItem(
      id = "notif_1",
      actor = sampleUsers[0],
      actionText = "loved your post about High-Availability Read Replicas.",
      timeAgo = "10m ago",
      isRead = false,
      iconEmoji = "❤️",
      postPreview = "Swapped strict 15-minute TTLs with randomized Redis Jitter..."
    ),
    NotificationItem(
      id = "notif_2",
      actor = sampleUsers[2],
      actionText = "sent you a friend request.",
      timeAgo = "1 hr ago",
      isRead = false,
      iconEmoji = "👥"
    ),
    NotificationItem(
      id = "notif_3",
      actor = sampleUsers[1],
      actionText = "commented on your photo: 'Incredible depth of field!'",
      timeAgo = "3 hrs ago",
      isRead = true,
      iconEmoji = "💬"
    ),
    NotificationItem(
      id = "notif_4",
      actor = sampleUsers[0],
      actionText = "shared your post to the Systems Engineering group.",
      timeAgo = "Yesterday",
      isRead = true,
      iconEmoji = "🔄"
    )
  )

  val sampleCommunityGroups = listOf(
    com.example.model.CommunityGroup(
      id = "group_1",
      name = "Android & Kotlin Architecture",
      description = "Modern Jetpack Compose, Coroutines, MVI, and high-performance mobile engineering.",
      membersCount = 42800,
      category = "Technology",
      avatarDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      isJoined = true,
      privacy = "PUBLIC"
    ),
    com.example.model.CommunityGroup(
      id = "group_2",
      name = "Global Travel & Nature Photography",
      description = "Landscape photography, gear reviews, and expedition trip journals worldwide.",
      membersCount = 89400,
      category = "Photography",
      avatarDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      isJoined = false,
      privacy = "PUBLIC"
    ),
    com.example.model.CommunityGroup(
      id = "group_3",
      name = "Distributed Cloud & High-QPS Systems",
      description = "Kafka, Redis caching strategies, gRPC, and large-scale microservice architectures.",
      membersCount = 61200,
      category = "Engineering",
      avatarDrawableRes = R.drawable.rx_book_app_icon_1789358378841,
      isJoined = false,
      privacy = "PUBLIC"
    ),
    com.example.model.CommunityGroup(
      id = "group_4",
      name = "Modern Architecture & Living Spaces",
      description = "Minimalist interior design, sustainable villa architecture, and spatial harmony.",
      membersCount = 31500,
      category = "Design",
      avatarDrawableRes = R.drawable.luxury_modern_villa_1789284896961,
      isJoined = true,
      privacy = "PUBLIC"
    )
  )

  val initialSearchHistory = listOf(
    "Sophia Chen",
    "Distributed Cloud",
    "Kotlin Architecture",
    "Marcus Vance",
    "Tokyo Design"
  )

  val sampleReels = listOf(
    com.example.model.RxReel(
      id = "reel_1",
      hlsUrl = "https://vjs.zencdn.net/v/oceans.mp4",
      blurHash = "L6PZfSi_.AyE_3t7t7R**0o#DgR4",
      author = sampleUsers[1], // Marcus Vance
      caption = "🌆 Neon cyberpunk skyscraper drone flight at twilight. Full 4K HDR rendering on RX Reels! #VeoAI #Cyberpunk #Cinematic",
      likes = "142.8K",
      likesCount = 142800,
      comments = "2,419",
      commentsCount = 2419,
      shares = "18.4K",
      audioTrackTitle = "Veo Synthwave Orchestral • AI Audio Engine",
      posterDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
      isLiked = false,
      isFollowing = false
    ),
    com.example.model.RxReel(
      id = "reel_2",
      hlsUrl = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
      blurHash = "LEHV6nWB2yk8pyo0adR*.7kCMdnj",
      author = sampleUsers[0], // Sophia Chen
      caption = "⚡ Zero-CLS vertical reels engine running on Compose! Safe play lifecycle constraints only render the active viewport. 🚀📱 #AndroidDev #Compose",
      likes = "89.3K",
      likesCount = 89300,
      comments = "1,150",
      commentsCount = 1150,
      shares = "9.2K",
      audioTrackTitle = "Tech Ambient Horizon • Sophia Chen",
      posterDrawableRes = R.drawable.rx_feed_post_tech_1789358410043,
      isLiked = true,
      isFollowing = true
    ),
    com.example.model.RxReel(
      id = "reel_3",
      hlsUrl = "https://test-videos.co.uk/vids/jellyfish/mp4/h264/720/Jellyfish_720_10s_1MB.mp4",
      blurHash = "LGF5]+Yk^6#M@-5c,1J5@[or[Q6.",
      author = sampleUsers[2], // Elena Rostova
      caption = "🏡 Minimalist concrete & glass spatial architecture in Kyoto hills. Sunlight tracking through glass pavilions. 🌿✨ #SpatialDesign #Architecture",
      likes = "215.1K",
      likesCount = 215100,
      comments = "3,892",
      commentsCount = 3892,
      shares = "31.7K",
      audioTrackTitle = "Kyoto Zen Lo-Fi • Elena Rostova",
      posterDrawableRes = R.drawable.luxury_modern_villa_1789284896961,
      isLiked = false,
      isFollowing = false
    ),
    com.example.model.RxReel(
      id = "reel_4",
      hlsUrl = "https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4",
      blurHash = "L8I=1g00~q%M%MoffQj[offQfQay",
      author = currentUser,
      caption = "🚀 RX BOOK production engineering: Real-time messaging, Veo video synthesis, and 60fps Reels viewer. What feature should we build next? 💬🔥",
      likes = "64.7K",
      likesCount = 64700,
      comments = "874",
      commentsCount = 874,
      shares = "5.1K",
      audioTrackTitle = "Original Audio • Alex Mercer",
      posterDrawableRes = R.drawable.rx_book_app_icon_1789358378841,
      isLiked = true,
      isFollowing = true
    )
  )
}
