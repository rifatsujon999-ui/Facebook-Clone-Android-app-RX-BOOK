package com.example

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import com.example.video.VideoPost

typealias VideoPost = com.example.video.VideoPost

@OptIn(UnstableApi::class)
class VideoAdapter(
    private val videos: List<VideoPost>
) : RecyclerView.Adapter<VideoAdapter.VideoViewHolder>() {

    companion object {
        const val FALLBACK_VIDEO_URL = "https://vjs.zencdn.net/v/oceans.mp4"
    }

    // Overloaded secondary constructor to support List<String> URLs directly as well
    constructor(urls: List<String>, @Suppress("UNUSED_PARAMETER") marker: Unit = Unit) : this(
        urls.mapIndexed { index, url -> VideoPost(index.toString(), url) }
    )

    inner class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val playerView: PlayerView = itemView.findViewById(R.id.playerView)
        val progressBar: View? = itemView.findViewById(R.id.videoProgressBar)
        var player: ExoPlayer? = null
        private var currentUrl: String? = null

        fun bind(video: VideoPost) {
            val videoUrl = video.videoUrl
            // If already bound to the exact same URL and player is intact, avoid re-instantiation
            if (currentUrl == videoUrl && player != null) {
                return
            }

            // Always release any old player before creating a new one.
            // This prevents audio overlapping and player leakage across recycled items.
            releasePlayer()

            currentUrl = videoUrl
            val context = itemView.context
            
            try {
                progressBar?.visibility = View.VISIBLE
                val httpDataSourceFactory = DefaultHttpDataSource.Factory()
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(15000)
                    .setReadTimeoutMs(15000)
                    .setUserAgent("RxBookExoPlayer/1.0")

                val mediaSourceFactory = DefaultMediaSourceFactory(context)
                    .setDataSourceFactory(httpDataSourceFactory)

                val renderersFactory = DefaultRenderersFactory(context)
                    .setEnableDecoderFallback(true)

                player = ExoPlayer.Builder(context, renderersFactory)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .build().also { exoPlayer ->
                        playerView.player = exoPlayer
                        val mediaItem = MediaItem.fromUri(videoUrl)
                        exoPlayer.setMediaItem(mediaItem)
                        exoPlayer.addListener(object : Player.Listener {
                            override fun onPlaybackStateChanged(playbackState: Int) {
                                progressBar?.visibility = if (playbackState == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                            }

                            override fun onPlayerError(error: PlaybackException) {
                                progressBar?.visibility = View.GONE
                                android.util.Log.e("VideoAdapter", "PlaybackException caught gracefully: ${error.errorCodeName} (${error.errorCode}): ${error.message}")
                                // If 403 or network failure occurs on first load, attempt graceful fallback once
                                if (currentUrl != FALLBACK_VIDEO_URL) {
                                    currentUrl = FALLBACK_VIDEO_URL
                                    exoPlayer.setMediaItem(MediaItem.fromUri(FALLBACK_VIDEO_URL))
                                    exoPlayer.prepare()
                                    exoPlayer.playWhenReady = true
                                }
                            }
                        })
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = true
                    }
            } catch (e: Exception) {
                progressBar?.visibility = View.GONE
                android.util.Log.e("VideoAdapter", "Failed to initialize ExoPlayer: ${e.message}", e)
            }
        }

        fun releasePlayer() {
            player?.stop()
            player?.clearMediaItems()
            player?.release()
            player = null
            playerView.player = null
            progressBar?.visibility = View.GONE
            currentUrl = null
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_video_player, parent, false)
        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        holder.bind(videos[position])
    }

    override fun onViewRecycled(holder: VideoViewHolder) {
        super.onViewRecycled(holder)
        // Critical: Stop and release playback when item scrolls off screen
        holder.releasePlayer()
    }

    override fun onViewDetachedFromWindow(holder: VideoViewHolder) {
        super.onViewDetachedFromWindow(holder)
        // Pause playback if the view is temporarily detached
        holder.player?.pause()
    }

    override fun getItemCount(): Int = videos.size
}
