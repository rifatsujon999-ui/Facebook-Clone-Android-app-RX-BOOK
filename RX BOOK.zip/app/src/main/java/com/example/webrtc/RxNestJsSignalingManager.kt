package com.example.webrtc

import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * RxNestJsSignalingManager:
 * Implements the full WebRTC signaling pipeline according to the NestJS Signaling Mesh architecture:
 *
 * [Caller Client]                                  [NestJS Signaling Mesh]                             [Recipient Client]
 *        |                                                    |                                                    |
 *        | --- 1. initiateCall (SDP Offer) -----------------> |                                                    |
 *        |                                                    | --- 2. incomingCallSignal (SDP Offer) -----------> |
 *        |                                                    |                                                    |
 *        |                                                    | <--- 3. acceptCall (SDP Answer) ------------------ |
 *        | <--- 4. callAcceptedSignal (SDP Answer) ---------- |                                                    |
 *        |                                                    |                                                    |
 *        | <=== 5. Dynamic ICE Candidates Sync (Bi-directional) ===>                                                |
 *        |                                                    |                                                    |
 *        | ====================== 6. Direct P2P Media Connection established (WSS/STUN) ===================> |
 */
object RxNestJsSignalingManager {
  private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())

  private val _sessionState = MutableStateFlow(CallSessionState())
  val sessionState: StateFlow<CallSessionState> = _sessionState.asStateFlow()

  private var timerJob: Job? = null
  private var telemetryJob: Job? = null
  private var signalingJob: Job? = null

  /**
   * 1. initiateCall: Caller starts the call by generating local SDP Offer and sending to NestJS Mesh
   */
  fun initiateCall(
    peerId: String,
    peerName: String,
    peerAvatarRes: Int? = R.drawable.rx_feed_post_tech_1789358410043,
    callType: CallType = CallType.VIDEO,
    autoConnectForDemo: Boolean = true
  ) {
    signalingJob?.cancel()
    timerJob?.cancel()
    telemetryJob?.cancel()

    val callId = "call_${UUID.randomUUID().toString().take(8)}"
    val mockOfferSdp = "v=0\r\no=- 4239847239 2 IN IP4 127.0.0.1\r\ns=RxBook WebRTC Session\r\nt=0 0\r\nm=audio 9 UDP/TLS/RTP/SAVPF 111\r\na=rtpmap:111 opus/48000/2\r\nm=video 9 UDP/TLS/RTP/SAVPF 96\r\na=rtpmap:96 VP8/90000\r\na=sendrecv"

    val initialLog = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.STEP_1_INITIATE_CALL_OFFER,
      source = "Caller Client",
      target = "NestJS Signaling Mesh",
      summary = "initiateCall dispatched with local SDP Offer",
      payloadPreview = "SDP Offer (audio: Opus, video: ${if (callType == CallType.VIDEO) "VP8 1080p" else "Disabled"})"
    )

    _sessionState.value = CallSessionState(
      callId = callId,
      peerId = peerId,
      peerName = peerName,
      peerAvatarRes = peerAvatarRes,
      callType = callType,
      role = CallRole.CALLER,
      status = CallStatus.RINGING_OUTGOING,
      currentStep = SignalingStep.STEP_1_INITIATE_CALL_OFFER,
      signalingLogs = listOf(initialLog)
    )

    if (autoConnectForDemo) {
      runSignalingSequence(callId, mockOfferSdp, callType)
    }
  }

  /**
   * Simulates an incoming call arriving from NestJS Signaling Mesh
   */
  fun receiveIncomingCall(
    callerId: String,
    callerName: String,
    callerAvatarRes: Int? = R.drawable.rx_feed_post_travel_1789358396512,
    callType: CallType = CallType.VIDEO
  ) {
    signalingJob?.cancel()
    timerJob?.cancel()
    telemetryJob?.cancel()

    val callId = "call_${UUID.randomUUID().toString().take(8)}"
    val incomingLog = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.STEP_2_INCOMING_SIGNAL_OFFER,
      source = "NestJS Signaling Mesh",
      target = "Recipient Client",
      summary = "incomingCallSignal received with remote SDP Offer",
      payloadPreview = "SDP Offer received from caller '$callerName' (callId: $callId)"
    )

    _sessionState.value = CallSessionState(
      callId = callId,
      peerId = callerId,
      peerName = callerName,
      peerAvatarRes = callerAvatarRes,
      callType = callType,
      role = CallRole.RECIPIENT,
      status = CallStatus.RINGING_INCOMING,
      currentStep = SignalingStep.STEP_2_INCOMING_SIGNAL_OFFER,
      signalingLogs = listOf(incomingLog)
    )
  }

  /**
   * Recipient clicks "Accept Call" -> triggers Step 3 (acceptCall) onwards
   */
  fun acceptIncomingCall() {
    val state = _sessionState.value
    val callId = state.callId ?: return

    signalingJob = coroutineScope.launch {
      // Step 3: Recipient sends acceptCall (SDP Answer) to NestJS Mesh
      val answerLog = SignalingMeshLog(
        id = UUID.randomUUID().toString(),
        step = SignalingStep.STEP_3_ACCEPT_CALL_ANSWER,
        source = "Recipient Client",
        target = "NestJS Signaling Mesh",
        summary = "acceptCall dispatched with local SDP Answer",
        payloadPreview = "SDP Answer accepted by recipient (audio: Opus, video: VP8)"
      )
      _sessionState.update {
        it.copy(
          status = CallStatus.CONNECTING,
          currentStep = SignalingStep.STEP_3_ACCEPT_CALL_ANSWER,
          signalingLogs = it.signalingLogs + answerLog
        )
      }

      delay(400)

      // Step 4: NestJS Mesh routes callAcceptedSignal to Caller
      val acceptedLog = SignalingMeshLog(
        id = UUID.randomUUID().toString(),
        step = SignalingStep.STEP_4_CALL_ACCEPTED_SIGNAL,
        source = "NestJS Signaling Mesh",
        target = "Caller Client",
        summary = "callAcceptedSignal delivered with SDP Answer",
        payloadPreview = "Caller remote description set: answer applied"
      )
      _sessionState.update {
        it.copy(
          currentStep = SignalingStep.STEP_4_CALL_ACCEPTED_SIGNAL,
          signalingLogs = it.signalingLogs + acceptedLog
        )
      }

      delay(500)

      // Step 5: Dynamic ICE Candidates Sync
      completeIceSyncAndEstablishP2p(callId)
    }
  }

  /**
   * Executes the full 6-step diagram flow asynchronously
   */
  private fun runSignalingSequence(callId: String, offerSdp: String, callType: CallType) {
    signalingJob = coroutineScope.launch {
      // Step 1 is already logged
      delay(700)

      // Step 2: Mesh sends incomingCallSignal (SDP Offer) to Recipient
      val step2Log = SignalingMeshLog(
        id = UUID.randomUUID().toString(),
        step = SignalingStep.STEP_2_INCOMING_SIGNAL_OFFER,
        source = "NestJS Signaling Mesh",
        target = "Recipient Client",
        summary = "incomingCallSignal routed via WSS to recipient",
        payloadPreview = "SDP Offer forwarded to socket room '${_sessionState.value.peerId}'"
      )
      _sessionState.update {
        it.copy(
          currentStep = SignalingStep.STEP_2_INCOMING_SIGNAL_OFFER,
          signalingLogs = it.signalingLogs + step2Log
        )
      }

      delay(900)

      // Step 3: Recipient answers with acceptCall (SDP Answer)
      val step3Log = SignalingMeshLog(
        id = UUID.randomUUID().toString(),
        step = SignalingStep.STEP_3_ACCEPT_CALL_ANSWER,
        source = "Recipient Client",
        target = "NestJS Signaling Mesh",
        summary = "acceptCall (SDP Answer) received from recipient",
        payloadPreview = "Remote SDP Answer generated with Opus codec negotiation"
      )
      _sessionState.update {
        it.copy(
          status = CallStatus.CONNECTING,
          currentStep = SignalingStep.STEP_3_ACCEPT_CALL_ANSWER,
          signalingLogs = it.signalingLogs + step3Log
        )
      }

      delay(500)

      // Step 4: NestJS Mesh dispatches callAcceptedSignal (SDP Answer) to Caller
      val step4Log = SignalingMeshLog(
        id = UUID.randomUUID().toString(),
        step = SignalingStep.STEP_4_CALL_ACCEPTED_SIGNAL,
        source = "NestJS Signaling Mesh",
        target = "Caller Client",
        summary = "callAcceptedSignal (SDP Answer) delivered to caller",
        payloadPreview = "Peer connection remote description set successfully"
      )
      _sessionState.update {
        it.copy(
          currentStep = SignalingStep.STEP_4_CALL_ACCEPTED_SIGNAL,
          signalingLogs = it.signalingLogs + step4Log
        )
      }

      delay(600)

      // Step 5 & 6: ICE Sync + P2P Established
      completeIceSyncAndEstablishP2p(callId)
    }
  }

  private suspend fun completeIceSyncAndEstablishP2p(callId: String) {
    // Step 5: Dynamic ICE Candidates Sync
    val step5Log = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.STEP_5_ICE_CANDIDATES_SYNC,
      source = "Caller <===> Recipient",
      target = "NestJS Signaling Mesh",
      summary = "Dynamic ICE Candidates Sync (Bi-directional)",
      payloadPreview = "Exchanged host (192.168.1.12), srflx (STUN 203.0.113.1), and relay (WSS TURN) candidates"
    )
    _sessionState.update {
      it.copy(
        currentStep = SignalingStep.STEP_5_ICE_CANDIDATES_SYNC,
        signalingLogs = it.signalingLogs + step5Log
      )
    }

    delay(700)

    // Step 6: Direct P2P Media Connection established (WSS/STUN)
    val step6Log = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.STEP_6_CONNECTED_P2P,
      source = "Peer to Peer",
      target = "Direct Encrypted Media Socket",
      summary = "Direct P2P Media Connection established (WSS/STUN)",
      payloadPreview = "DTLS-SRTP handshake completed. Direct audio/video UDP streams flowing."
    )
    _sessionState.update {
      it.copy(
        status = CallStatus.CONNECTED,
        currentStep = SignalingStep.STEP_6_CONNECTED_P2P,
        durationSeconds = 0,
        signalingLogs = it.signalingLogs + step6Log
      )
    }

    startCallTimer()
    startTelemetryStream()
  }

  private fun startCallTimer() {
    timerJob?.cancel()
    timerJob = coroutineScope.launch {
      while (isActive && _sessionState.value.status == CallStatus.CONNECTED) {
        delay(1000)
        _sessionState.update { it.copy(durationSeconds = it.durationSeconds + 1) }
      }
    }
  }

  private fun startTelemetryStream() {
    telemetryJob?.cancel()
    telemetryJob = coroutineScope.launch {
      while (isActive && _sessionState.value.status == CallStatus.CONNECTED) {
        delay(2000)
        // Simulate real-time dynamic jitter/latency metrics
        val latencyVariation = (15..28).random().toLong()
        val bitrateVariation = (1800..2350).random()
        val packetLossVariation = if ((0..10).random() > 8) 0.08f else 0.01f

        _sessionState.update {
          it.copy(
            rttLatencyMs = latencyVariation,
            bitrateKbps = bitrateVariation,
            packetsLostPct = packetLossVariation
          )
        }
      }
    }
  }

  fun toggleMic() {
    _sessionState.update { it.copy(isMicMuted = !it.isMicMuted) }
  }

  fun toggleCamera() {
    _sessionState.update { it.copy(isCameraEnabled = !it.isCameraEnabled) }
  }

  fun flipCamera() {
    _sessionState.update { it.copy(isFrontCamera = !it.isFrontCamera) }
  }

  fun toggleSpeaker() {
    _sessionState.update { it.copy(isSpeakerOn = !it.isSpeakerOn) }
  }

  fun endCall() {
    signalingJob?.cancel()
    timerJob?.cancel()
    telemetryJob?.cancel()

    val endLog = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.TERMINATED,
      source = "Client",
      target = "NestJS Signaling Mesh",
      summary = "endCall broadcasted, peer connection closed",
      payloadPreview = "Session terminated after ${_sessionState.value.durationSeconds}s duration."
    )

    _sessionState.update {
      it.copy(
        status = CallStatus.ENDED,
        currentStep = SignalingStep.TERMINATED,
        signalingLogs = it.signalingLogs + endLog
      )
    }

    coroutineScope.launch {
      delay(1200)
      _sessionState.value = CallSessionState()
    }
  }

  fun declineCall() {
    signalingJob?.cancel()
    timerJob?.cancel()
    telemetryJob?.cancel()

    val declineLog = SignalingMeshLog(
      id = UUID.randomUUID().toString(),
      step = SignalingStep.TERMINATED,
      source = "Recipient Client",
      target = "NestJS Signaling Mesh",
      summary = "Call declined by recipient",
      payloadPreview = "rejectCall signal emitted to NestJS Mesh"
    )

    _sessionState.update {
      it.copy(
        status = CallStatus.DECLINED,
        currentStep = SignalingStep.TERMINATED,
        signalingLogs = it.signalingLogs + declineLog
      )
    }

    coroutineScope.launch {
      delay(1000)
      _sessionState.value = CallSessionState()
    }
  }
}
