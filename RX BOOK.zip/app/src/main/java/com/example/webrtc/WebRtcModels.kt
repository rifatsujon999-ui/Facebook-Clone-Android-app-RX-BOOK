package com.example.webrtc

enum class CallType {
  AUDIO,
  VIDEO
}

enum class CallRole {
  CALLER,
  RECIPIENT
}

enum class CallStatus {
  IDLE,
  RINGING_OUTGOING,
  RINGING_INCOMING,
  CONNECTING,
  CONNECTED,
  ENDED,
  DECLINED
}

/**
 * The 6 precise steps matching the NestJS Signaling Mesh WebRTC sequence diagram:
 * 1. initiateCall (SDP Offer) -> NestJS Mesh
 * 2. incomingCallSignal (SDP Offer) -> Recipient Client
 * 3. acceptCall (SDP Answer) -> NestJS Mesh
 * 4. callAcceptedSignal (SDP Answer) -> Caller Client
 * 5. Dynamic ICE Candidates Sync (Bi-directional)
 * 6. Direct P2P Media Connection established (WSS/STUN)
 */
enum class SignalingStep(val stepNumber: Int, val title: String, val description: String) {
  IDLE(0, "Idle", "Waiting for call initiation"),
  STEP_1_INITIATE_CALL_OFFER(1, "initiateCall (SDP Offer)", "Caller dispatches local SDP Offer to NestJS Signaling Mesh"),
  STEP_2_INCOMING_SIGNAL_OFFER(2, "incomingCallSignal (SDP Offer)", "NestJS Mesh delivers SDP Offer to Recipient client"),
  STEP_3_ACCEPT_CALL_ANSWER(3, "acceptCall (SDP Answer)", "Recipient accepts and dispatches SDP Answer to NestJS Mesh"),
  STEP_4_CALL_ACCEPTED_SIGNAL(4, "callAcceptedSignal (SDP Answer)", "NestJS Mesh delivers SDP Answer back to Caller"),
  STEP_5_ICE_CANDIDATES_SYNC(5, "Dynamic ICE Candidates Sync", "Bi-directional ICE candidate exchange via NestJS WebSocket"),
  STEP_6_CONNECTED_P2P(6, "Direct P2P Media Connection", "P2P WebRTC connection established via STUN / TURN fallback"),
  TERMINATED(7, "Call Terminated", "Session ended, ICE transports and audio/video tracks released")
}

data class SdpPayload(
  val callId: String,
  val type: String, // "offer" or "answer"
  val sdp: String,
  val callerId: String,
  val callerName: String,
  val recipientId: String,
  val callType: CallType,
  val timestamp: Long = System.currentTimeMillis()
)

data class IceCandidate(
  val callId: String,
  val sdpMid: String,
  val sdpMLineIndex: Int,
  val candidate: String,
  val from: String,
  val timestamp: Long = System.currentTimeMillis()
)

data class SignalingMeshLog(
  val id: String,
  val step: SignalingStep,
  val source: String,
  val target: String,
  val summary: String,
  val payloadPreview: String,
  val timestamp: Long = System.currentTimeMillis()
)

data class CallSessionState(
  val callId: String? = null,
  val peerId: String = "",
  val peerName: String = "",
  val peerAvatarRes: Int? = null,
  val callType: CallType = CallType.VIDEO,
  val role: CallRole? = null,
  val status: CallStatus = CallStatus.IDLE,
  val currentStep: SignalingStep = SignalingStep.IDLE,
  val isMicMuted: Boolean = false,
  val isCameraEnabled: Boolean = true,
  val isFrontCamera: Boolean = true,
  val isSpeakerOn: Boolean = true,
  val durationSeconds: Int = 0,
  val signalingLogs: List<SignalingMeshLog> = emptyList(),
  val rttLatencyMs: Long = 18,
  val bitrateKbps: Int = 1850,
  val packetsLostPct: Float = 0.05f,
  val audioCodec: String = "Opus 48kHz (Fullband Stereo)",
  val videoCodec: String = "VP8 1080p @ 60fps",
  val stunTurnServer: String = "stun:stun.l.google.com:19302 (Mesh Fallback: WSS TURN)"
)
