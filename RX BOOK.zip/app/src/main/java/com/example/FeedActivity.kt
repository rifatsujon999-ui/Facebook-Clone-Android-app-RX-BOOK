package com.example

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.video.DefaultVideoRepository
import com.example.video.VideoPagingAdapter
import com.example.video.VideoPost
import com.example.video.VideoPreloadManager
import com.example.video.VideoRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Fullscreen vertical video feed powered by:
 * - Backend with Cursor-based pagination
 * - VideoRepository
 * - Paging 3
 * - Vertical RecyclerView with PagerSnapHelper
 * - Media3 ExoPlayer with current video autoplay and next video preload
 * - Automatic next page loading near end
 */
class FeedActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var initialProgressBar: ProgressBar
    private lateinit var btnBack: ImageView
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var snapHelper: PagerSnapHelper

    private lateinit var preloadManager: VideoPreloadManager
    private lateinit var pagingAdapter: VideoPagingAdapter
    private val videoRepository: VideoRepository = DefaultVideoRepository.instance

    private var currentPlayingPosition = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        recyclerView = findViewById(R.id.recyclerView)
        initialProgressBar = findViewById(R.id.initialProgressBar)
        btnBack = findViewById(R.id.btnBack)

        btnBack.setOnClickListener { finish() }

        preloadManager = VideoPreloadManager(this)

        pagingAdapter = VideoPagingAdapter(
            preloadManager = preloadManager,
            onShareClick = { post -> shareVideo(post) }
        )

        layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        snapHelper = PagerSnapHelper()

        recyclerView.layoutManager = layoutManager
        snapHelper.attachToRecyclerView(recyclerView)
        recyclerView.adapter = pagingAdapter

        setupScrollListener()
        observePagingData()
        observeLoadStates()
    }

    private fun setupScrollListener() {
        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    checkAndPlaySnappedItem()
                }
            }

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                // If this is the very first frame or settling, ensure autoplay
                if (currentPlayingPosition == -1 && pagingAdapter.itemCount > 0) {
                    checkAndPlaySnappedItem()
                }
            }
        })
    }

    private fun checkAndPlaySnappedItem() {
        val snapView = snapHelper.findSnapView(layoutManager) ?: return
        val position = layoutManager.getPosition(snapView)

        if (position != RecyclerView.NO_POSITION && position != currentPlayingPosition) {
            currentPlayingPosition = position

            // 1. Autoplay current snapped video
            val currentItem = pagingAdapter.snapshot().items.getOrNull(position)
            val holder = recyclerView.findViewHolderForAdapterPosition(position) as? VideoPagingAdapter.VideoViewHolder
            if (currentItem != null && holder != null) {
                holder.play(currentItem.videoUrl)
            }

            // 2. Preload next video in advance for 0-latency swipe
            val nextPosition = position + 1
            val nextItem = pagingAdapter.snapshot().items.getOrNull(nextPosition)
            if (nextItem != null) {
                preloadManager.preloadNext(nextItem.videoUrl)
            }
        }
    }

    private fun observePagingData() {
        lifecycleScope.launch {
            videoRepository.getVideoFeedStream().collectLatest { pagingData ->
                pagingAdapter.submitData(pagingData)
            }
        }
    }

    private fun observeLoadStates() {
        lifecycleScope.launch {
            pagingAdapter.loadStateFlow.collectLatest { loadStates ->
                initialProgressBar.visibility = if (loadStates.refresh is LoadState.Loading) {
                    View.VISIBLE
                } else {
                    View.GONE
                }

                // When initial items finish loading, autoplay the first video
                if (loadStates.refresh is LoadState.NotLoading && currentPlayingPosition == -1 && pagingAdapter.itemCount > 0) {
                    recyclerView.post { checkAndPlaySnappedItem() }
                }
            }
        }
    }

    private fun shareVideo(post: VideoPost) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Watch '${post.title}' by ${post.authorName} on RX BOOK: ${post.videoUrl}")
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, "Share Video"))
    }

    override fun onResume() {
        super.onResume()
        preloadManager.resumeCurrent()
    }

    override fun onPause() {
        super.onPause()
        preloadManager.pauseCurrent()
    }

    override fun onDestroy() {
        super.onDestroy()
        preloadManager.releaseAll()
    }
}
