package com.example

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.data.RxBookRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage

class EditProfileActivity : AppCompatActivity() {

    private val TAG = "EditProfileActivity"

    private lateinit var ivProfilePicture: ImageView
    private lateinit var btnChangePhoto: Button
    private lateinit var progressBarPhoto: ProgressBar
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPhone: EditText
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button
    private lateinit var btnBack: ImageButton
    private lateinit var btnCancelTop: Button
    private lateinit var progressBarSave: ProgressBar

    private var auth: FirebaseAuth? = null
    private var selectedImageUri: Uri? = null
    private var currentPhotoUrl: String? = null

    // Photo picker using modern Android Photo Picker
    private val pickVisualMediaLauncher = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            ivProfilePicture.load(uri) {
                crossfade(true)
                placeholder(R.drawable.rx_book_app_icon_1789358378841)
            }
        }
    }

    // Fallback photo picker
    private val pickImageFallback = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            ivProfilePicture.load(uri) {
                crossfade(true)
                placeholder(R.drawable.rx_book_app_icon_1789358378841)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        try {
            auth = Firebase.auth
        } catch (e: Exception) {
            Log.w(TAG, "Firebase auth unavailable: ${e.message}")
        }
        val currentUser = auth?.currentUser

        initViews()
        setupListeners(currentUser)
        loadExistingUserData(currentUser)
    }

    private fun initViews() {
        ivProfilePicture = findViewById(R.id.ivProfilePicture)
        btnChangePhoto = findViewById(R.id.btnChangePhoto)
        progressBarPhoto = findViewById(R.id.progressBarPhoto)
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPhone = findViewById(R.id.etPhone)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
        btnBack = findViewById(R.id.btnBack)
        btnCancelTop = findViewById(R.id.btnCancelTop)
        progressBarSave = findViewById(R.id.progressBarSave)
    }

    private fun setupListeners(user: FirebaseUser?) {
        btnBack.setOnClickListener { finish() }
        btnCancel.setOnClickListener { finish() }
        btnCancelTop.setOnClickListener { finish() }

        val openGallery = {
            try {
                pickVisualMediaLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            } catch (e: Exception) {
                pickImageFallback.launch("image/*")
            }
        }

        btnChangePhoto.setOnClickListener { openGallery() }
        ivProfilePicture.setOnClickListener { openGallery() }

        btnSave.setOnClickListener {
            handleSaveChanges(user)
        }
    }

    private fun loadExistingUserData(user: FirebaseUser?) {
        // 1. Preload from FirebaseAuth if available, else from RxBookRepository.currentUser
        val authName = user?.displayName.orEmpty()
        val authEmail = user?.email.orEmpty()
        val authPhone = user?.phoneNumber.orEmpty()
        currentPhotoUrl = user?.photoUrl?.toString() ?: RxBookRepository.currentUser.avatarUrl

        etName.setText(if (authName.isNotEmpty()) authName else RxBookRepository.currentUser.displayName)
        etEmail.setText(if (authEmail.isNotEmpty()) authEmail else RxBookRepository.currentUser.email)
        etPhone.setText(if (authPhone.isNotEmpty()) authPhone else RxBookRepository.currentUser.phone)

        if (!currentPhotoUrl.isNullOrEmpty()) {
            ivProfilePicture.load(currentPhotoUrl) {
                crossfade(true)
                placeholder(R.drawable.rx_book_app_icon_1789358378841)
                error(R.drawable.rx_book_app_icon_1789358378841)
            }
        } else if (!RxBookRepository.currentUser.avatarUrl.isNullOrEmpty()) {
            currentPhotoUrl = RxBookRepository.currentUser.avatarUrl
            ivProfilePicture.load(currentPhotoUrl) {
                crossfade(true)
                placeholder(R.drawable.rx_book_app_icon_1789358378841)
                error(R.drawable.rx_book_app_icon_1789358378841)
            }
        } else {
            ivProfilePicture.setImageResource(R.drawable.rx_book_app_icon_1789358378841)
        }

        // 2. Fetch latest data from Firestore
        if (user != null) {
            try {
                FirebaseFirestore.getInstance().collection("users").document(user.uid)
                    .get()
                    .addOnSuccessListener { doc ->
                        if (doc != null && doc.exists()) {
                            val fsName = doc.getString("name")
                            val fsEmail = doc.getString("email")
                            val fsPhone = doc.getString("phone")
                            val fsPhoto = doc.getString("photoUrl")

                            if (!fsName.isNullOrBlank()) etName.setText(fsName)
                            if (!fsEmail.isNullOrBlank()) etEmail.setText(fsEmail)
                            if (!fsPhone.isNullOrBlank()) etPhone.setText(fsPhone)

                            if (!fsPhoto.isNullOrBlank()) {
                                currentPhotoUrl = fsPhoto
                                ivProfilePicture.load(fsPhoto) {
                                    crossfade(true)
                                    placeholder(R.drawable.rx_book_app_icon_1789358378841)
                                    error(R.drawable.rx_book_app_icon_1789358378841)
                                }
                            }
                        }
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "Failed reading user data from Firestore: ${e.message}")
                    }
            } catch (e: Exception) {
                Log.e(TAG, "Firestore read exception: ${e.message}", e)
            }
        }
    }

    private fun handleSaveChanges(user: FirebaseUser?) {
        val name = etName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val phone = etPhone.text.toString().trim()

        // Validation
        if (name.isEmpty()) {
            etName.error = "Please enter your name"
            etName.requestFocus()
            return
        }

        if (email.isEmpty()) {
            etEmail.error = "Please enter your email"
            etEmail.requestFocus()
            return
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Please enter a valid email address"
            etEmail.requestFocus()
            return
        }

        // If user is null (Guest mode), save locally immediately
        if (user == null) {
            val finalPhotoUrl = selectedImageUri?.toString() ?: currentPhotoUrl
            finalizeSuccess("guest_rx_user", name, email, phone, finalPhotoUrl)
            return
        }

        // UI Loading state
        btnSave.isEnabled = false
        progressBarSave.visibility = View.VISIBLE

        val imageToUpload = selectedImageUri
        if (imageToUpload != null) {
            // Upload to Firebase Storage
            progressBarPhoto.visibility = View.VISIBLE
            uploadProfilePictureToStorage(user.uid, imageToUpload) { uploadedUrl ->
                progressBarPhoto.visibility = View.GONE
                val finalPhotoUrl = uploadedUrl ?: currentPhotoUrl
                saveProfileData(user, name, email, phone, finalPhotoUrl)
            }
        } else {
            saveProfileData(user, name, email, phone, currentPhotoUrl)
        }
    }

    private fun uploadProfilePictureToStorage(
        uid: String,
        imageUri: Uri,
        onComplete: (String?) -> Unit
    ) {
        try {
            val storageRef = FirebaseStorage.getInstance().reference.child("profile_images/$uid.jpg")
            storageRef.putFile(imageUri)
                .addOnSuccessListener {
                    storageRef.downloadUrl
                        .addOnSuccessListener { downloadUri ->
                            onComplete(downloadUri.toString())
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "Storage downloadUrl error: ${e.message}")
                            // Fallback to null but continue saving text profile info
                            onComplete(null)
                        }
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Storage upload error: ${e.message}")
                    Toast.makeText(this, "Photo upload note: ${e.localizedMessage ?: e.message}", Toast.LENGTH_SHORT).show()
                    onComplete(null)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Storage exception: ${e.message}", e)
            onComplete(null)
        }
    }

    private fun saveProfileData(
        user: FirebaseUser,
        name: String,
        email: String,
        phone: String,
        photoUrl: String?
    ) {
        // 1. Update Firebase Auth Profile
        try {
            val profileUpdates = UserProfileChangeRequest.Builder()
                .setDisplayName(name)
                .apply {
                    if (!photoUrl.isNullOrEmpty()) {
                        setPhotoUri(Uri.parse(photoUrl))
                    }
                }
                .build()

            user.updateProfile(profileUpdates).addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "Auth updateProfile failed: ${task.exception?.message}")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "updateProfile exception: ${e.message}")
        }

        // 2. Update Firebase Auth Email if modified
        if (email.isNotEmpty() && !email.equals(user.email, ignoreCase = true)) {
            try {
                user.verifyBeforeUpdateEmail(email)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Verification email sent to $email to confirm update", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener { e ->
                        Log.w(TAG, "verifyBeforeUpdateEmail error: ${e.message}")
                    }
            } catch (e: Exception) {
                Log.w(TAG, "verifyBeforeUpdateEmail exception: ${e.message}")
            }
        }

        // 3. Save to Cloud Firestore
        val profileData = hashMapOf<String, Any>(
            "uid" to user.uid,
            "name" to name,
            "email" to email,
            "phone" to phone,
            "photoUrl" to (photoUrl ?: ""),
            "updatedAt" to System.currentTimeMillis()
        )

        try {
            FirebaseFirestore.getInstance().collection("users").document(user.uid)
                .set(profileData, SetOptions.merge())
                .addOnSuccessListener {
                    finalizeSuccess(user.uid, name, email, phone, photoUrl)
                }
                .addOnFailureListener { e ->
                    // Even if Firestore network fails, fallback update locally
                    Log.w(TAG, "Firestore write warning: ${e.message}")
                    finalizeSuccess(user.uid, name, email, phone, photoUrl)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Firestore set exception: ${e.message}", e)
            finalizeSuccess(user.uid, name, email, phone, photoUrl)
        }
    }

    private fun finalizeSuccess(
        uid: String,
        name: String,
        email: String,
        phone: String,
        photoUrl: String?
    ) {
        // Update local repository so MainActivity picks it up immediately
        RxBookRepository.currentUser = RxBookRepository.currentUser.copy(
            id = uid,
            displayName = name,
            email = email,
            phone = phone,
            avatarUrl = photoUrl ?: RxBookRepository.currentUser.avatarUrl
        )

        progressBarSave.visibility = View.GONE
        btnSave.isEnabled = true
        Toast.makeText(this, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }
}
