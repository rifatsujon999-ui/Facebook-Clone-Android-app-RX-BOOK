package com.example

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.auth

class LoginActivity : AppCompatActivity() {

    private val TAG = "LoginActivity"
    private var auth: FirebaseAuth? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        try {
            auth = Firebase.auth
        } catch (e: Exception) {
            Log.w(TAG, "Firebase initialization notice: ${e.message}")
        }

        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnContinueAsGuest = findViewById<Button>(R.id.btnContinueAsGuest)
        val progressBar = findViewById<ProgressBar>(R.id.progressBarLogin)
        val tvForgotPassword = findViewById<TextView>(R.id.tvForgotPassword)
        val tvGoToSignUp = findViewById<TextView>(R.id.tvGoToSignUp)

        btnContinueAsGuest.setOnClickListener {
            // Direct entrance into RX BOOK Social Feed & Reels in Guest Mode
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter your email and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val firebaseAuth = auth
            if (firebaseAuth == null) {
                Toast.makeText(this, "Firebase is not connected. Entering as Guest...", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
                return@setOnClickListener
            }

            progressBar.visibility = View.VISIBLE
            btnLogin.isEnabled = false

            firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this, "Welcome back!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                .addOnFailureListener { e ->
                    progressBar.visibility = View.GONE
                    btnLogin.isEnabled = true
                    Log.e(TAG, "Login failed: ${e.message}", e)
                    val friendlyMsg = when (e) {
                        is FirebaseAuthInvalidUserException ->
                            "No account found with this email. Please tap 'Sign Up' below to create an account."
                        is FirebaseAuthInvalidCredentialsException ->
                            "Incorrect email or password. If you haven't created an account yet, please tap 'Sign Up'."
                        else -> {
                            if (e.message?.contains("credential is incorrect", ignoreCase = true) == true ||
                                e.message?.contains("malformed or has expired", ignoreCase = true) == true) {
                                "Incorrect email or password, or account doesn't exist yet. Please tap 'Sign Up'."
                            } else {
                                "Login error: ${e.localizedMessage ?: e.message}"
                            }
                        }
                    }
                    Toast.makeText(this, friendlyMsg, Toast.LENGTH_LONG).show()
                }
        }

        tvForgotPassword.setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (email.isEmpty()) {
                Toast.makeText(this, "Please enter your email above first", Toast.LENGTH_SHORT).show()
                etEmail.requestFocus()
                return@setOnClickListener
            }
            progressBar.visibility = View.VISIBLE
            Firebase.auth.sendPasswordResetEmail(email)
                .addOnSuccessListener {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this, "Password reset email sent to $email. Check your inbox!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener { e ->
                    progressBar.visibility = View.GONE
                    Toast.makeText(this, "Reset failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }

        tvGoToSignUp.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            val email = etEmail.text.toString().trim()
            if (email.isNotEmpty()) {
                intent.putExtra("prefill_email", email)
            }
            startActivity(intent)
            finish()
        }

        // ইতিমধ্যে লগইন করা থাকলে সরাসরি mainActivity এ পাঠানো
        if (auth?.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
