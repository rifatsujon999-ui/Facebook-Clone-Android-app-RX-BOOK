package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RxBookRepository
import com.example.model.ChatMessage
import com.example.model.ReactionType
import com.example.model.RxReel
import com.example.model.SocialComment
import com.example.model.SocialPost
import com.example.ui.components.CommentsModal
import com.example.ui.components.CreatePostModal
import com.example.ui.components.RxBookCommentSheet
import com.example.ui.components.RxBookMessengerSheet
import com.example.ui.components.RxBookSearchModal
import com.example.ui.components.RxBookVeoVideoModal
import com.example.ui.components.RxFeedSearchableHeader
import com.example.ui.components.RxReelsViewer
import com.example.ui.components.RxTopBar
import com.example.ui.screens.MessengerScreen
import com.example.ui.screens.NewsFeedScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SocialGraphScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RxBlue
import com.example.ui.theme.RxTextMuted
import com.example.ui.theme.RxTextPrimary
import com.example.ui.theme.RxTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        RxBookApp()
      }
    }
  }
}

@Composable
fun RxBookApp() {
  var currentUser by remember { mutableStateOf(RxBookRepository.currentUser) }

  val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
  androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
    val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
      if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
        currentUser = RxBookRepository.currentUser
        RxBookRepository.refreshCurrentUserFromFirebase { updated ->
          currentUser = updated
        }
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  var stories by remember { mutableStateOf(RxBookRepository.sampleStories) }
  var posts by remember { mutableStateOf(RxBookRepository.initialPosts) }
  var commentsMap by remember { mutableStateOf(RxBookRepository.sampleComments) }
  var conversations by remember { mutableStateOf(RxBookRepository.sampleConversations) }
  var messagesMap by remember { mutableStateOf(RxBookRepository.sampleMessages) }
  var notifications by remember { mutableStateOf(RxBookRepository.sampleNotifications) }
  var networkUsers by remember { mutableStateOf(RxBookRepository.sampleUsers) }
  var communityGroups by remember { mutableStateOf(RxBookRepository.sampleCommunityGroups) }

  var currentTab by remember { mutableIntStateOf(0) }
  var showCreatePostModal by remember { mutableStateOf(false) }
  var showVeoModal by remember { mutableStateOf(false) }
  var showSearchModal by remember { mutableStateOf(false) }
  var showMessengerSheet by remember { mutableStateOf(false) }
  var activePostForComments by remember { mutableStateOf<SocialPost?>(null) }

  // Story Engine State
  var activeStoryForViewing by remember { mutableStateOf<com.example.model.SocialStory?>(null) }
  var showCreateStoryDialog by remember { mutableStateOf(false) }

  // Reels Engine State
  var reels by remember { mutableStateOf(RxBookRepository.sampleReels) }
  var showReelsViewer by remember { mutableStateOf(false) }
  var activeReelIndex by remember { mutableIntStateOf(0) }

  // Feed Search & Category State
  var feedSearchQuery by remember { mutableStateOf("") }
  var feedSelectedCategory by remember { mutableStateOf("All") }
  var isFeedRefreshing by remember { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }
  val coroutineScope = rememberCoroutineScope()
  val context = LocalContext.current
  var lastBackPressedTime by remember { mutableStateOf(0L) }

  // Graceful Back Button handling: closes open sheets/modals, returns to Feed tab, or prompts before exit
  BackHandler {
    when {
      showReelsViewer -> showReelsViewer = false
      showMessengerSheet -> showMessengerSheet = false
      showSearchModal -> showSearchModal = false
      showCreatePostModal -> showCreatePostModal = false
      showVeoModal -> showVeoModal = false
      activePostForComments != null -> activePostForComments = null
      currentTab != 0 -> currentTab = 0
      else -> {
        val now = System.currentTimeMillis()
        if (now - lastBackPressedTime < 2000L) {
          (context as? ComponentActivity)?.finish()
        } else {
          lastBackPressedTime = now
          Toast.makeText(context, "Press back again to exit", Toast.LENGTH_SHORT).show()
        }
      }
    }
  }

  val unreadChatCount = conversations.sumOf { it.unreadCount }
  val unreadNotificationCount = notifications.count { !it.isRead }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      if (currentTab == 0) {
        RxFeedSearchableHeader(
          onSearchClick = { showSearchModal = true },
          onNotificationClick = { currentTab = 3 },
          userAvatarUrl = null,
          userInitial = currentUser.displayName.ifEmpty { "U" },
          onProfileClick = { currentTab = 4 },
          onVideoFeedClick = {
            activeReelIndex = 0
            showReelsViewer = true
          }
        )
      } else {
        RxTopBar(
          unreadChatCount = unreadChatCount,
          onOpenChat = { showMessengerSheet = true },
          onSearchClick = { showSearchModal = true },
          onOpenReels = {
            activeReelIndex = 0
            showReelsViewer = true
          }
        )
      }
    },
    bottomBar = {
      androidx.compose.foundation.layout.Column {
        androidx.compose.material3.Divider(color = com.example.ui.theme.RazorThinBorder, thickness = 1.dp)
        NavigationBar(
          containerColor = com.example.ui.theme.PureWhiteSurface,
          contentColor = RxBlue,
          modifier = Modifier
            .navigationBarsPadding()
            .testTag("rx_bottom_nav"),
          tonalElevation = 0.dp
        ) {
          // Tab 0: Feed
          NavigationBarItem(
            selected = currentTab == 0,
            onClick = { currentTab = 0 },
            icon = { Icon(Icons.Default.Home, contentDescription = "Feed") },
            label = { Text("Feed", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RxBlue,
              selectedTextColor = RxBlue,
              indicatorColor = RxBlue.copy(alpha = 0.12f),
              unselectedIconColor = RxTextSecondary,
              unselectedTextColor = RxTextSecondary
            ),
            modifier = Modifier.testTag("tab_home_feed")
          )

          // Tab 1: Friends
          NavigationBarItem(
            selected = currentTab == 1,
            onClick = { currentTab = 1 },
            icon = { Icon(Icons.Default.People, contentDescription = "Friends") },
            label = { Text("Friends", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RxBlue,
              selectedTextColor = RxBlue,
              indicatorColor = RxBlue.copy(alpha = 0.12f),
              unselectedIconColor = RxTextSecondary,
              unselectedTextColor = RxTextSecondary
            ),
            modifier = Modifier.testTag("tab_friends")
          )

          // Tab 2: Messenger
          NavigationBarItem(
            selected = currentTab == 2,
            onClick = { currentTab = 2 },
            icon = {
              BadgedBox(
                badge = {
                  if (unreadChatCount > 0) {
                    Badge(containerColor = com.example.ui.theme.RxBadgeRed) {
                      Text("$unreadChatCount", fontSize = 9.sp)
                    }
                  }
                }
              ) {
                Icon(Icons.Default.ChatBubble, contentDescription = "Chats")
              }
            },
            label = { Text("Chats", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RxBlue,
              selectedTextColor = RxBlue,
              indicatorColor = RxBlue.copy(alpha = 0.12f),
              unselectedIconColor = RxTextSecondary,
              unselectedTextColor = RxTextSecondary
            ),
            modifier = Modifier.testTag("tab_chats")
          )

          // Tab 3: Notifications
          NavigationBarItem(
            selected = currentTab == 3,
            onClick = { currentTab = 3 },
            icon = {
              BadgedBox(
                badge = {
                  if (unreadNotificationCount > 0) {
                    Badge(containerColor = com.example.ui.theme.RxBadgeRed) {
                      Text("$unreadNotificationCount", fontSize = 9.sp)
                    }
                  }
                }
              ) {
                Icon(Icons.Default.Notifications, contentDescription = "Notifications")
              }
            },
            label = { Text("Alerts", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = RxBlue,
              selectedTextColor = RxBlue,
              indicatorColor = RxBlue.copy(alpha = 0.12f),
              unselectedIconColor = RxTextSecondary,
              unselectedTextColor = RxTextSecondary
            ),
            modifier = Modifier.testTag("tab_alerts")
          )

        // Tab 4: Profile
        NavigationBarItem(
          selected = currentTab == 4,
          onClick = { currentTab = 4 },
          icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
          label = { Text("Menu", fontSize = 10.sp) },
          colors = NavigationBarItemDefaults.colors(
            selectedIconColor = RxBlue,
            selectedTextColor = RxBlue,
            indicatorColor = RxBlue.copy(alpha = 0.12f),
            unselectedIconColor = RxTextSecondary,
            unselectedTextColor = RxTextSecondary
          ),
          modifier = Modifier.testTag("tab_profile")
        )
      }
    }
  },
  snackbarHost = { SnackbarHost(snackbarHostState) }
) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      AnimatedContent(
        targetState = currentTab,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "tab_transition"
      ) { tab ->
        when (tab) {
          0 -> {
            NewsFeedScreen(
              currentUser = currentUser,
              stories = stories,
              posts = posts,
              reels = reels,
              searchQuery = feedSearchQuery,
              selectedCategory = feedSelectedCategory,
              isRefreshing = isFeedRefreshing,
              onRefresh = {
                isFeedRefreshing = true
                coroutineScope.launch {
                  RxBookRepository.refreshCurrentUserFromFirebase { updated ->
                    currentUser = updated
                  }
                  delay(900)
                  // Update first post timestamp to simulate fresh updates and ensure latest content
                  posts = posts.mapIndexed { index, post ->
                    if (index == 0) post.copy(timeAgo = "Just now") else post
                  }
                  isFeedRefreshing = false
                  snackbarHostState.showSnackbar("Feed refreshed!")
                }
              },
              onClearSearch = {
                feedSearchQuery = ""
                feedSelectedCategory = "All"
              },
              onOpenCreatePost = { showCreatePostModal = true },
              onOpenVeoVideo = { showVeoModal = true },
              onOpenReels = {
                activeReelIndex = 0
                showReelsViewer = true
              },
              onReelClick = { index ->
                activeReelIndex = index
                showReelsViewer = true
              },
              onStoryClick = { story ->
                if (story.isUserStory) {
                  showCreateStoryDialog = true
                } else {
                  activeStoryForViewing = story
                }
              },
              onReactionSelected = { postId, reaction ->
                posts = posts.map { post ->
                  if (post.id == postId) {
                    val currentReaction = post.userReaction
                    val updatedCounts = post.reactionCounts.toMutableMap()

                    if (currentReaction == reaction) {
                      // Toggle off
                      updatedCounts[reaction] = (updatedCounts[reaction] ?: 1) - 1
                      post.copy(userReaction = null, reactionCounts = updatedCounts)
                    } else {
                      if (currentReaction != null) {
                        updatedCounts[currentReaction] = (updatedCounts[currentReaction] ?: 1) - 1
                      }
                      updatedCounts[reaction] = (updatedCounts[reaction] ?: 0) + 1
                      post.copy(userReaction = reaction, reactionCounts = updatedCounts)
                    }
                  } else post
                }
              },
              onCommentClick = { post -> activePostForComments = post },
              onShareClick = { post ->
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("Post shared to your RX timeline!")
                }
              },
              onUserClick = { user -> currentTab = 4 },
              suggestedUsers = networkUsers.filter { it.id != currentUser.id },
              onFollowClick = { user ->
                coroutineScope.launch {
                  val isCurrentlyFriends = user.friendshipStatus == "FRIENDS"
                  networkUsers = networkUsers.map {
                    if (it.id == user.id) it.copy(friendshipStatus = if (isCurrentlyFriends) "NONE" else "FRIENDS") else it
                  }
                  snackbarHostState.showSnackbar(
                    if (isCurrentlyFriends) "Unfollowed ${user.displayName}" else "Following ${user.displayName}"
                  )
                }
              },
              onSaveToggle = { post ->
                val newSaved = !post.isSaved
                posts = posts.map { if (it.id == post.id) it.copy(isSaved = newSaved) else it }
                coroutineScope.launch {
                  snackbarHostState.showSnackbar(
                    if (newSaved) "Saved to your bookmarks" else "Removed from saved posts"
                  )
                }
              },
              onHidePost = { post ->
                val previousPosts = posts
                posts = posts.filter { it.id != post.id }
                coroutineScope.launch {
                  val result = snackbarHostState.showSnackbar(
                    message = "Post hidden from your feed",
                    actionLabel = "Undo",
                    duration = androidx.compose.material3.SnackbarDuration.Short
                  )
                  if (result == androidx.compose.material3.SnackbarResult.ActionPerformed) {
                    posts = previousPosts
                  }
                }
              },
              onReportPost = { post ->
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("Report submitted. Thank you for keeping RX BOOK safe.")
                }
              },
              onCopyLink = { post ->
                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                val clip = android.content.ClipData.newPlainText("RX Post Link", "https://rxbook.social/posts/${post.id}")
                clipboard?.setPrimaryClip(clip)
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("Post link copied to clipboard!")
                }
              }
            )
          }

          1 -> {
            SocialGraphScreen(
              users = networkUsers,
              onAcceptRequest = { userId ->
                networkUsers = networkUsers.map {
                  if (it.id == userId) it.copy(friendshipStatus = "FRIENDS") else it
                }
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("Friend request accepted!")
                }
              },
              onAddFriend = { userId ->
                coroutineScope.launch {
                  snackbarHostState.showSnackbar("Friend request dispatched!")
                }
              }
            )
          }

          2 -> {
            MessengerScreen(
              currentUser = currentUser,
              conversations = conversations,
              activeMessages = messagesMap,
              onSendMessage = { convId, text ->
                val newMsg = ChatMessage(
                  id = "msg_${System.currentTimeMillis()}",
                  conversationId = convId,
                  senderId = currentUser.id,
                  text = text,
                  timestamp = "Just now",
                  isFromMe = true
                )
                val currentList = messagesMap[convId] ?: emptyList()
                messagesMap = messagesMap + (convId to (currentList + newMsg))

                // Update last message in conversation
                conversations = conversations.map {
                  if (it.id == convId) it.copy(lastMessage = text, lastMessageTime = "Just now") else it
                }

                // Simulate real-time peer reply after 1.5s
                coroutineScope.launch {
                  delay(1500)
                  val reply = ChatMessage(
                    id = "msg_${System.currentTimeMillis() + 1}",
                    conversationId = convId,
                    senderId = "partner",
                    text = "Got it! Real-time Socket.io transmission confirmed ⚡",
                    timestamp = "Just now",
                    isFromMe = false
                  )
                  val updated = messagesMap[convId] ?: emptyList()
                  messagesMap = messagesMap + (convId to (updated + reply))
                }
              }
            )
          }

          3 -> {
            NotificationsScreen(
              notifications = notifications,
              onNotificationClick = { notif ->
                notifications = notifications.map {
                  if (it.id == notif.id) it.copy(isRead = true) else it
                }
              }
            )
          }

          4 -> {
            ProfileScreen(
              currentUser = currentUser,
              userPosts = posts.filter { it.author.id == currentUser.id }
            )
          }
        }
      }

      // Create Post Modal
      if (showCreatePostModal) {
        CreatePostModal(
          currentUser = currentUser,
          onDismiss = { showCreatePostModal = false },
          onOpenVeoVideo = { showVeoModal = true },
          onPostCreated = { content, hasPhoto ->
            val newPost = SocialPost(
              id = "post_${System.currentTimeMillis()}",
              author = currentUser,
              content = content,
              mediaDrawableRes = if (hasPhoto) R.drawable.rx_feed_post_tech_1789358410043 else null,
              timeAgo = "Just now",
              reactionCounts = mapOf(ReactionType.LIKE to 1),
              userReaction = ReactionType.LIKE,
              commentsCount = 0,
              sharesCount = 0,
              visibility = "PUBLIC"
            )
            posts = listOf(newPost) + posts
            coroutineScope.launch {
              snackbarHostState.showSnackbar("Post published to RX BOOK Feed!")
            }
          }
        )
      }

      // Veo 3 AI Video Modal
      if (showVeoModal) {
        RxBookVeoVideoModal(
          onDismiss = { showVeoModal = false },
          onPublishVideoPost = { videoUrl, prompt, aspectRatio ->
            val newPost = SocialPost(
              id = "veo_${System.currentTimeMillis()}",
              author = currentUser,
              content = "$prompt\n\n#Veo3 #AIVideo #DeepMind #RxBook",
              videoUrl = videoUrl,
              videoAspectRatio = aspectRatio,
              isAiGenerated = true,
              timeAgo = "Just now",
              reactionCounts = mapOf(ReactionType.LOVE to 1, ReactionType.WOW to 1),
              userReaction = ReactionType.LOVE,
              commentsCount = 0,
              sharesCount = 0,
              visibility = "PUBLIC"
            )
            posts = listOf(newPost) + posts
            coroutineScope.launch {
              snackbarHostState.showSnackbar("Veo 3 AI Video ($aspectRatio) published to RxBook Feed!")
            }
          }
        )
      }

      // Comments Sheet
      activePostForComments?.let { post ->
        RxBookCommentSheet(
          postId = post.id,
          onDismiss = { activePostForComments = null },
          onCommentSubmitted = { commentId, text ->
            val newComment = SocialComment(
              id = commentId,
              postId = post.id,
              author = currentUser,
              content = text,
              timeAgo = "Just now",
              likesCount = 0,
              isLiked = false
            )
            val currentComments = commentsMap[post.id] ?: emptyList()
            commentsMap = commentsMap + (post.id to (currentComments + newComment))

            // Update comment count on post
            posts = posts.map {
              if (it.id == post.id) it.copy(commentsCount = it.commentsCount + 1) else it
            }
          }
        )
      }

      if (showSearchModal) {
        RxBookSearchModal(
          onDismiss = { showSearchModal = false },
          allUsers = networkUsers,
          allGroups = communityGroups,
          initialHistory = RxBookRepository.initialSearchHistory,
          onSearchTriggered = { query, tab ->
            println("Debounced Network Query Dispatched -> Query: $query | Segment: $tab")
          },
          onUserSelected = { user ->
            showSearchModal = false
            coroutineScope.launch {
              snackbarHostState.showSnackbar("Connected with ${user.displayName}")
            }
          },
          onGroupJoinedToggle = { groupId ->
            communityGroups = communityGroups.map { g ->
              if (g.id == groupId) {
                val newJoined = !g.isJoined
                val newMembers = if (newJoined) g.membersCount + 1 else g.membersCount - 1
                g.copy(isJoined = newJoined, membersCount = newMembers)
              } else g
            }
          }
        )
      }

      // RxBook Messenger Quick Sheet
      if (showMessengerSheet) {
        RxBookMessengerSheet(
          recipientId = "user_2",
          onDismiss = { showMessengerSheet = false },
          onSocketMessageDispatched = { msgId, text ->
            coroutineScope.launch {
              snackbarHostState.showSnackbar("Message sent securely over socket!")
            }
          }
        )
      }

      // RxReelsViewer Full-Screen Modal
      if (showReelsViewer) {
        androidx.compose.ui.window.Dialog(
          onDismissRequest = { showReelsViewer = false },
          properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
          )
        ) {
          RxReelsViewer(
            reels = reels,
            initialIndex = activeReelIndex,
            onClose = { showReelsViewer = false },
            onShareReel = { reel ->
              coroutineScope.launch {
                snackbarHostState.showSnackbar("Reel shared to timeline: ${reel.caption.take(24)}...")
              }
            }
          )
        }
      }

      // Real-Time WebRTC P2P Call Engine Overlay (NestJS Signaling Mesh)
      com.example.ui.components.RxCallOverlay()

      // Create Story Dialog
      if (showCreateStoryDialog) {
        com.example.ui.components.CreateStoryDialog(
          currentUser = currentUser,
          onDismiss = { showCreateStoryDialog = false },
          onStoryPublished = { newStory ->
            stories = stories + newStory
            showCreateStoryDialog = false
            coroutineScope.launch {
              snackbarHostState.showSnackbar("Story uploaded successfully to RX BOOK!")
            }
          }
        )
      }

      // Story Viewer Dialog
      activeStoryForViewing?.let { story ->
        com.example.ui.components.StoryViewerDialog(
          story = story,
          onDismiss = { activeStoryForViewing = null }
        )
      }
    }
  }
}
