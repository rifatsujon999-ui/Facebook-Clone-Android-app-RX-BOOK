@file:kotlin.OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.media3.common.util.UnstableApi::class
)

package com.example.ui.components

import android.view.LayoutInflater
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.VideoAdapter
import com.example.model.RxReel
import com.example.model.SocialComment
import com.example.ui.theme.ElectricRoyalBlue
import com.example.ui.theme.MidnightBlueText
import com.example.ui.theme.PureWhiteSurface
import com.example.ui.theme.RazorThinBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * RxReelsViewer: Full-screen vertical Reels viewer built with Jetpack Compose.
 * Directly translates and enhances the Flutter RxReelsViewer specification:
 * - VerticalPager with smooth gesture snapping
 * - Safe play lifecycle constraint: only the active visible reel item initializes and plays video
 * - Zero CLS container stack with background poster / BlurHash gradient backdrop
 * - Interactive right-side action column (Likes, Comments, Share, Rotating Disc)
 * - Profile overlay with avatar, username, follow toggle, and caption
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RxReelsViewer(
  reels: List<RxReel>,
  initialIndex: Int = 0,
  onClose: () -> Unit,
  onShareReel: (RxReel) -> Unit = {},
  modifier: Modifier = Modifier
) {
  if (reels.isEmpty()) {
    onClose()
    return
  }

  val pagerState = rememberPagerState(
    initialPage = initialIndex.coerceIn(0, reels.lastIndex),
    pageCount = { reels.size }
  )

  // Local interaction states for likes and follow status
  val likedReels = remember { mutableStateMapOf<String, Boolean>() }
  val likeCountDeltas = remember { mutableStateMapOf<String, Int>() }
  val followingStatus = remember { mutableStateMapOf<String, Boolean>() }
  var isGlobalMuted by remember { mutableStateOf(false) }

  // Reel Comments bottom sheet state
  var activeCommentReel by remember { mutableStateOf<RxReel?>(null) }
  val commentSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val reelCommentsMap = remember {
    mutableStateMapOf<String, MutableList<Pair<String, String>>>().apply {
      reels.forEach { reel ->
        put(
          reel.id,
          mutableListOf(
            "Sophia Chen" to "Incredible cinematic flow! The volumetric lighting is stunning. 🔥",
            "Alex Mercer" to "Zero-CLS layout performance looking razor-sharp on Compose.",
            "Elena Rostova" to "Love the aesthetic harmony and spatial framing! ✨"
          )
        )
      }
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black) // Dark layout container wrapper specific to immersive reels
      .testTag("rx_reels_viewer")
  ) {
    VerticalPager(
      state = pagerState,
      modifier = Modifier.fillMaxSize(),
      key = { index -> reels[index].id }
    ) { pageIndex ->
      val reel = reels[pageIndex]

      // Safe play lifecycle constraint: Only execute if more than 75% of active item is visible
      // (info.visibleFraction > 0.75)
      val visibleFraction = remember(pagerState.currentPage, pagerState.currentPageOffsetFraction) {
        if (pagerState.currentPage == pageIndex) {
          1f - kotlin.math.abs(pagerState.currentPageOffsetFraction)
        } else {
          0f
        }
      }
      val isVisibleNow = visibleFraction > 0.75f

      val isLiked = likedReels[reel.id] ?: reel.isLiked
      val currentLikeDelta = likeCountDeltas[reel.id] ?: 0
      val isFollowing = followingStatus[reel.author.id] ?: reel.isFollowing

      RxSingleReelItem(
        reel = reel,
        isVisibleNow = isVisibleNow,
        isMuted = isGlobalMuted,
        isLiked = isLiked,
        likeCountDelta = currentLikeDelta,
        isFollowing = isFollowing,
        onToggleLike = {
          val newLiked = !isLiked
          likedReels[reel.id] = newLiked
          likeCountDeltas[reel.id] = currentLikeDelta + (if (newLiked) 1 else -1)
        },
        onToggleFollow = {
          followingStatus[reel.author.id] = !isFollowing
        },
        onCommentClick = {
          activeCommentReel = reel
        },
        onShareClick = {
          onShareReel(reel)
        },
        modifier = Modifier.fillMaxSize()
      )
    }

    // Top Navigation & Header Overlay
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onClose,
          modifier = Modifier.testTag("btn_close_reels")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Close Reels",
            tint = Color.White,
            modifier = Modifier.size(26.dp)
          )
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Reels",
          style = androidx.compose.ui.text.TextStyle(
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = 20.sp,
            letterSpacing = (-0.5).sp
          )
        )
      }

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Stream telemetry tag
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color.Black.copy(alpha = 0.5f),
          border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
        ) {
          Text(
            text = "60 FPS • HLS",
            color = Color(0xFF00F5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }

        // Mute / Unmute Toggle
        IconButton(onClick = { isGlobalMuted = !isGlobalMuted }) {
          Icon(
            imageVector = if (isGlobalMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
            contentDescription = "Toggle Mute",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
          )
        }
      }
    }

    // Reel Comments Bottom Sheet
    if (activeCommentReel != null) {
      val reel = activeCommentReel!!
      val commentsList = reelCommentsMap[reel.id] ?: mutableListOf()
      var newCommentText by remember { mutableStateOf("") }

      ModalBottomSheet(
        onDismissRequest = { activeCommentReel = null },
        sheetState = commentSheetState,
        containerColor = PureWhiteSurface
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(16.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Comments (${commentsList.size})",
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              color = MidnightBlueText
            )
            IconButton(onClick = { activeCommentReel = null }) {
              Icon(Icons.Default.Close, contentDescription = "Close", tint = MidnightBlueText)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // List of comments
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f, fill = false),
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            commentsList.forEach { (authorName, commentText) ->
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
              ) {
                Surface(
                  shape = CircleShape,
                  color = ElectricRoyalBlue.copy(alpha = 0.15f),
                  modifier = Modifier.size(34.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Text(
                      text = authorName.take(1),
                      fontWeight = FontWeight.Bold,
                      color = ElectricRoyalBlue
                    )
                  }
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = authorName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MidnightBlueText
                  )
                  Text(
                    text = commentText,
                    fontSize = 13.sp,
                    color = MidnightBlueText.copy(alpha = 0.85f)
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Comment Input Field
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = newCommentText,
              onValueChange = { newCommentText = it },
              placeholder = { Text("Add a comment on this reel...") },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(24.dp),
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricRoyalBlue,
                unfocusedBorderColor = RazorThinBorder
              )
            )

            IconButton(
              onClick = {
                if (newCommentText.isNotBlank()) {
                  reelCommentsMap[reel.id]?.add("Alex Mercer" to newCommentText.trim())
                  newCommentText = ""
                }
              },
              enabled = newCommentText.isNotBlank()
            ) {
              Icon(
                imageVector = Icons.Default.Send,
                contentDescription = "Post Comment",
                tint = if (newCommentText.isNotBlank()) ElectricRoyalBlue else Color.Gray
              )
            }
          }
        }
      }
    }
  }
}

/**
 * _RxSingleReelItem: Single full-screen reel item.
 * - Safe play lifecycle constraint: Only renders active video when isVisibleNow (> 75%) is true.
 * - Explicit memory disposal releasing video decoding and RAM buffers when leaving viewport.
 * - Zero CLS placeholder stack with BlurHash texture and poster thumbnail.
 * - LinearGradient overlay for pristine text readability.
 * - Full interactive right-side action column and profile block.
 */
@OptIn(UnstableApi::class)
@Composable
private fun RxSingleReelItem(
  reel: RxReel,
  isVisibleNow: Boolean,
  isMuted: Boolean,
  isLiked: Boolean,
  likeCountDelta: Int,
  isFollowing: Boolean,
  onToggleLike: () -> Unit,
  onToggleFollow: () -> Unit,
  onCommentClick: () -> Unit,
  onShareClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var isPlaying by remember { mutableStateOf(true) }
  var isBuffering by remember { mutableStateOf(false) }
  var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
  var showPlayPauseIcon by remember { mutableStateOf(false) }
  var showHeartBurst by remember { mutableStateOf(false) }
  var isCaptionExpanded by remember { mutableStateOf(false) }

  // 💾 স্ক্রিন পরিবর্তন বা সোয়াইপ করার সাথে সাথে প্লেয়ার রিলিজ (০% মেমোরি লিক)
  DisposableEffect(isVisibleNow, reel.hlsUrl) {
    if (isVisibleNow) {
      val httpDataSourceFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(15000)
        .setReadTimeoutMs(15000)
        .setUserAgent("RxBookReelsPlayer/1.0")

      val mediaSourceFactory = DefaultMediaSourceFactory(context)
        .setDataSourceFactory(httpDataSourceFactory)

      val renderersFactory = DefaultRenderersFactory(context)
        .setEnableDecoderFallback(true)

      val player = ExoPlayer.Builder(context, renderersFactory)
        .setMediaSourceFactory(mediaSourceFactory)
        .build().apply {
          repeatMode = Player.REPEAT_MODE_ONE
          volume = if (isMuted) 0f else 1f
          playWhenReady = isPlaying
          setMediaItem(MediaItem.fromUri(reel.hlsUrl))
          addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
              isBuffering = (playbackState == Player.STATE_BUFFERING)
            }

            override fun onPlayerError(error: PlaybackException) {
              isBuffering = false
              android.util.Log.e("RxReelsViewer", "Reel playback error: ${error.errorCodeName} (${error.errorCode}): ${error.message}")
              if (reel.hlsUrl != VideoAdapter.FALLBACK_VIDEO_URL) {
                setMediaItem(MediaItem.fromUri(VideoAdapter.FALLBACK_VIDEO_URL))
                prepare()
                playWhenReady = isPlaying
              }
            }
          })
          prepare()
        }
      exoPlayer = player
    } else {
      exoPlayer?.stop()
      exoPlayer?.clearMediaItems()
      exoPlayer?.release()
      exoPlayer = null
      isBuffering = false
    }

    onDispose {
      exoPlayer?.stop()
      exoPlayer?.clearMediaItems()
      exoPlayer?.release()
      exoPlayer = null
      isBuffering = false
    }
  }

  LaunchedEffect(isPlaying) {
    exoPlayer?.playWhenReady = isPlaying
  }

  LaunchedEffect(isMuted) {
    exoPlayer?.volume = if (isMuted) 0f else 1f
  }

  // Rotating disc animation for audio track
  val infiniteTransition = rememberInfiniteTransition(label = "disc_rotation")
  val discAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 4000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "disc_angle"
  )

  // Like scale bounce animation
  val likeScale by animateFloatAsState(
    targetValue = if (isLiked) 1.25f else 1f,
    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
    label = "like_bounce"
  )

  val coroutineScope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
      .pointerInput(reel.id) {
        detectTapGestures(
          onDoubleTap = {
            if (!isLiked) {
              onToggleLike()
            }
            showHeartBurst = true
            coroutineScope.launch {
              delay(750)
              showHeartBurst = false
            }
          },
          onTap = {
            isPlaying = !isPlaying
            showPlayPauseIcon = true
            coroutineScope.launch {
              delay(600)
              showPlayPauseIcon = false
            }
          }
        )
      }
  ) {
    // 🛡️ Zero CLS Container Stack: Placeholder + Video Layer
    Box(modifier = Modifier.fillMaxSize()) {
      // 1. Instantly rendered placeholder poster / BlurHash smooth texture backdrop
      BlurHashBackdrop(
        hash = reel.blurHash,
        posterRes = reel.posterDrawableRes,
        modifier = Modifier.fillMaxSize()
      )

      // 2. Video Player Layer with safe lifecycle: Only plays if visible (>75%) in viewport
      // TextureView prevents black screen punch-through, resize_mode=zoom fills screen
      if (isVisibleNow && exoPlayer != null) {
        AndroidView(
          factory = { ctx ->
            val view = LayoutInflater.from(ctx).inflate(R.layout.item_reel_player, null, false)
            val playerView = view.findViewById<PlayerView>(R.id.reelPlayerView)
            playerView.player = exoPlayer
            view
          },
          update = { view ->
            val playerView = view.findViewById<PlayerView>(R.id.reelPlayerView)
            playerView.player = exoPlayer
          },
          onRelease = { view ->
            val playerView = view.findViewById<PlayerView>(R.id.reelPlayerView)
            playerView.player = null
          },
          modifier = Modifier.fillMaxSize()
        )
      }

      // Buffering progress indicator tied to STATE_BUFFERING
      if (isBuffering) {
        CircularProgressIndicator(
          color = Color.White,
          modifier = Modifier
            .size(48.dp)
            .align(Alignment.Center)
        )
      }
    }

    // 🎨 Premium Clean Controls Overlays Layer
    // Gradient shading for readability
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(
              Color.Black.copy(alpha = 0.45f),
              Color.Transparent,
              Color.Black.copy(alpha = 0.75f)
            ),
            startY = 0f,
            endY = Float.POSITIVE_INFINITY
          )
        )
    )

    // Center Tap Play / Pause Feedback
    AnimatedVisibility(
      visible = showPlayPauseIcon,
      enter = fadeIn() + scaleIn(),
      exit = fadeOut() + scaleOut(),
      modifier = Modifier.align(Alignment.Center)
    ) {
      Surface(
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.65f),
        modifier = Modifier.size(68.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = if (isPlaying) Icons.Default.PlayArrow else Icons.Default.Close,
            contentDescription = "Playback state",
            tint = Color.White,
            modifier = Modifier.size(40.dp)
          )
        }
      }
    }

    // Double Tap Heart Burst Animation
    AnimatedVisibility(
      visible = showHeartBurst,
      enter = fadeIn() + scaleIn(tween(250)),
      exit = fadeOut() + scaleOut(tween(350)),
      modifier = Modifier.align(Alignment.Center)
    ) {
      Icon(
        imageVector = Icons.Default.Favorite,
        contentDescription = "Liked",
        tint = Color(0xFFEF4444),
        modifier = Modifier
          .size(100.dp)
          .scale(likeScale)
      )
    }

    // Bottom Meta & Action Controls
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 18.dp),
      verticalAlignment = Alignment.Bottom
    ) {
      // Left Profile Block Descriptions
      Column(
        modifier = Modifier
          .weight(1f)
          .padding(end = 16.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.Start
      ) {
        // Author Row: CircleAvatar, UserName, Follow Button
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Image(
            painter = painterResource(id = reel.author.avatarDrawableRes),
            contentDescription = reel.author.displayName,
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .border(1.2.dp, Color.White, CircleShape)
          )

          Text(
            text = reel.author.displayName,
            style = androidx.compose.ui.text.TextStyle(
              color = Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
          )

          // Follow / Following button
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = if (isFollowing) Color.White.copy(alpha = 0.2f) else Color.Transparent,
            border = BorderStroke(0.8.dp, Color.White),
            modifier = Modifier
              .clickable(onClick = onToggleFollow)
              .testTag("btn_follow_reel_${reel.id}")
          ) {
            Text(
              text = if (isFollowing) "Following" else "Follow",
              style = androidx.compose.ui.text.TextStyle(
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              ),
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Caption Text
        Text(
          text = reel.caption,
          style = androidx.compose.ui.text.TextStyle(
            color = Color.White,
            fontSize = 13.sp,
            lineHeight = 18.sp
          ),
          maxLines = if (isCaptionExpanded) 6 else 2,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.clickable { isCaptionExpanded = !isCaptionExpanded }
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Audio Track Bar
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.MusicNote,
            contentDescription = "Audio track",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
          Text(
            text = reel.audioTrackTitle,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      // Right Side Interactive Floating Column Nodes
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Like Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clickable(onClick = onToggleLike)
            .testTag("btn_like_reel_${reel.id}")
        ) {
          Icon(
            imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Like Reel",
            tint = if (isLiked) Color(0xFFEF4444) else Color.White,
            modifier = Modifier
              .size(28.dp)
              .scale(likeScale)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = if (likeCountDelta != 0) "${reel.likesCount + likeCountDelta}" else reel.likes,
            style = androidx.compose.ui.text.TextStyle(
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        // Comment Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clickable(onClick = onCommentClick)
            .testTag("btn_comment_reel_${reel.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ChatBubble,
            contentDescription = "Reel Comments",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = reel.comments,
            style = androidx.compose.ui.text.TextStyle(
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        // Share Button
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clickable(onClick = onShareClick)
            .testTag("btn_share_reel_${reel.id}")
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share Reel",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Share",
            style = androidx.compose.ui.text.TextStyle(
              color = Color.White,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold
            )
          )
        }

        // Rotating Music Disc Album Art
        Surface(
          shape = CircleShape,
          color = Color.Black,
          border = BorderStroke(2.dp, Color.White),
          modifier = Modifier
            .size(34.dp)
            .rotate(if (isPlaying) discAngle else 0f)
        ) {
          Image(
            painter = painterResource(id = reel.author.avatarDrawableRes),
            contentDescription = "Music Disc",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        }
      }
    }
  }
}

/**
 * BlurHashBackdrop: Instantly rendered placeholder texture stack ensuring zero CLS.
 */
@Composable
private fun BlurHashBackdrop(
  hash: String,
  posterRes: Int?,
  modifier: Modifier = Modifier
) {
  Box(modifier = modifier) {
    if (posterRes != null) {
      Image(
        painter = painterResource(id = posterRes),
        contentDescription = "Reel Backdrop",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )
    } else {
      // Deterministic smooth gradient based on BlurHash string
      val hashSeed = hash.hashCode()
      val c1 = Color(
        red = (((hashSeed shr 16) and 0xFF).coerceIn(40, 220)) / 255f,
        green = (((hashSeed shr 8) and 0xFF).coerceIn(40, 220)) / 255f,
        blue = ((hashSeed and 0xFF).coerceIn(40, 220)) / 255f
      )
      val c2 = Color(
        red = ((((hashSeed * 31) shr 16) and 0xFF).coerceIn(20, 200)) / 255f,
        green = ((((hashSeed * 31) shr 8) and 0xFF).coerceIn(20, 200)) / 255f,
        blue = (((hashSeed * 31) and 0xFF).coerceIn(20, 200)) / 255f
      )
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              listOf(c1.copy(alpha = 0.85f), c2.copy(alpha = 0.9f), Color(0xFF0F172A))
            )
          )
      )
    }
  }
}

