package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 🎨 RX BOOK Brand Palette - Modern 2026/2027 Social Platform
val ElectricRoyalBlue = Color(0xFF1877F2)
val RxBlue = ElectricRoyalBlue
val RxBlueDark = Color(0xFF0F56B3)
val RxBlueLight = Color(0xFFE7F3FF)
val VibrantCyan = Color(0xFF00F5FF)
val RxCyan = VibrantCyan

// ☀️ Premium Light/White Design System (Material 3 Compliant)
val PremiumWhiteBackground = Color(0xFFF8F9FA) // আল্ট্রা-ব্রাইট হোয়াইট ক্যানভাস (#F8F9FA to #FFFFFF)
val PureWhiteSurface = Color(0xFFFFFFFF)       // কার্ড এবং সারফেসের জন্য পিওর হোয়াইট
val MidnightBlueText = Color(0xFF0F172A)       // সর্বোচ্চ রিডিবিলিটির জন্য ডিপ টেক্সট কালার
val SlateGreyAction = Color(0xFFF1F5F9)        // বাটন ক্লিক বা হোভার অ্যাকশন স্টেট
val RazorThinBorder = Color(0xFFE9ECEF)        // অত্যন্ত সূক্ষ্ম বর্ডার লাইন (#E9ECEF)
val BodySubText = Color(0xFF334155)            // সাব-হেডার বা ক্যাপশনের টেক্সট কালার

// Aliases for seamless backward compatibility
val RxBackground = PremiumWhiteBackground
val RxSurface = PureWhiteSurface
val RxSurfaceVariant = SlateGreyAction
val RxBorder = RazorThinBorder
val RxDivider = RazorThinBorder

// Typography & Content
val RxTextPrimary = MidnightBlueText
val RxTextSecondary = BodySubText
val RxTextMuted = Color(0xFF64748B)

// Reaction Colors
val ReactionLike = Color(0xFF1877F2)
val ReactionLove = Color(0xFFFA3E3E)
val ReactionHaha = Color(0xFFF7B125)
val ReactionWow = Color(0xFFF7B125)
val ReactionSad = Color(0xFFE2B024)
val ReactionAngry = Color(0xFFE44E27)

// Status & Online Indicators
val RxOnlineGreen = Color(0xFF10B981)
val RxBadgeRed = Color(0xFFEF4444)

