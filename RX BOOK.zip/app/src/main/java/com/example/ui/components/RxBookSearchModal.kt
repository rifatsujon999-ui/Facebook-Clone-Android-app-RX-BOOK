package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommunityGroup
import com.example.model.SocialUser
import com.example.ui.theme.RxBlue
import com.example.ui.theme.RxTextMuted
import com.example.ui.theme.RxTextSecondary
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun RxBookSearchModal(
  onDismiss: () -> Unit,
  onSearchTriggered: (String, String) -> Unit = { _, _ -> },
  allUsers: List<SocialUser> = com.example.data.RxBookRepository.sampleUsers,
  allGroups: List<CommunityGroup> = com.example.data.RxBookRepository.sampleCommunityGroups,
  initialHistory: List<String> = com.example.data.RxBookRepository.initialSearchHistory,
  onUserSelected: (SocialUser) -> Unit = {},
  onGroupJoinedToggle: (String) -> Unit = {}
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedTab by remember { mutableStateOf("All") }
  var searchHistory by remember { mutableStateOf(initialHistory.ifEmpty { listOf("Kotlin", "Jetpack Compose", "RxBook") }) }

  // ⌨️ Software Keyboard Controller to hide keyboard cleanly
  val keyboardController = LocalSoftwareKeyboardController.current

  // ⏱️ Zero Unnecessary Requests: snapshotFlow + distinctUntilChanged + debounce(300)
  LaunchedEffect(key1 = true) {
    snapshotFlow { Pair(searchQuery, selectedTab) }
      .distinctUntilChanged()
      .debounce(300)
      .collectLatest { (query, tab) ->
        if (query.isNotBlank()) {
          onSearchTriggered(query, tab)
        }
      }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    dragHandle = { BottomSheetDefaults.DragHandle() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp)
    ) {
      // 1. Search Text Field with Clean Keyboard Submission
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("input_search_bar"),
        placeholder = { Text("Search RxBook...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { searchQuery = "" }) {
              Icon(Icons.Default.Clear, contentDescription = "Clear")
            }
          }
        },
        shape = CircleShape,
        singleLine = true,
        // ⌨️ Keyboard Actions Configuration
        keyboardOptions = KeyboardOptions(
          imeAction = ImeAction.Search
        ),
        keyboardActions = KeyboardActions(
          onSearch = {
            if (searchQuery.isNotBlank()) {
              // 🔄 Clean Keyboard Submission: query pinned to the front of history without duplicates
              searchHistory = listOf(searchQuery) + searchHistory.filter { it != searchQuery }

              // ⌨️ Dismiss keyboard
              keyboardController?.hide()

              // Trigger search immediately
              onSearchTriggered(searchQuery, selectedTab)
            }
          }
        )
      )

      Spacer(modifier = Modifier.height(16.dp))

      // 🏷️ Recent History Area
      if (searchHistory.isNotEmpty()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Recent Searches", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Text(
            text = "Clear all",
            modifier = Modifier.clickable { searchHistory = emptyList() },
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.bodySmall
          )
        }

        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(searchHistory) { historyItem ->
            SuggestionChip(
              onClick = {
                searchQuery = historyItem
                keyboardController?.hide()
              },
              label = { Text(historyItem) }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // 📑 Tab Segment Filter
      val tabs = listOf("All", "Friends", "Groups")
      TabRow(
        selectedTabIndex = tabs.indexOf(selectedTab).coerceAtLeast(0),
        modifier = Modifier.fillMaxWidth()
      ) {
        tabs.forEach { tab ->
          Tab(
            selected = selectedTab == tab,
            onClick = { selectedTab = tab },
            text = { Text(tab) }
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // 📇 2. Material 3 Card Style: Result Items Rendering
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        contentAlignment = Alignment.TopCenter
      ) {
        if (searchQuery.isBlank()) {
          Text(
            text = "Type or select history to search",
            color = Color.Gray,
            modifier = Modifier.padding(top = 24.dp)
          )
        } else {
          val trimmed = searchQuery.trim().lowercase()
          val matchingUsers = if (selectedTab == "All" || selectedTab == "Friends") {
            allUsers.filter {
              it.displayName.lowercase().contains(trimmed) ||
                it.username.lowercase().contains(trimmed) ||
                it.bio.lowercase().contains(trimmed)
            }
          } else emptyList()

          val matchingGroups = if (selectedTab == "All" || selectedTab == "Groups") {
            allGroups.filter {
              it.name.lowercase().contains(trimmed) ||
                it.description.lowercase().contains(trimmed) ||
                it.category.lowercase().contains(trimmed)
            }
          } else emptyList()

          val hasRealMatches = matchingUsers.isNotEmpty() || matchingGroups.isNotEmpty()

          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            if (hasRealMatches) {
              items(matchingUsers) { user ->
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                  ),
                  shape = MaterialTheme.shapes.medium
                ) {
                  ListItem(
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    headlineContent = {
                      Text(user.displayName, fontWeight = FontWeight.SemiBold)
                    },
                    supportingContent = {
                      Text("@${user.username} • ${user.friendsCount} friends • Category: Friends")
                    },
                    leadingContent = {
                      Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(42.dp)
                      ) {
                        Box(contentAlignment = Alignment.Center) {
                          Text(
                            text = user.displayName.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                          )
                        }
                      }
                    },
                    trailingContent = {
                      OutlinedButton(onClick = {
                        keyboardController?.hide()
                        onUserSelected(user)
                      }) {
                        Text("View")
                      }
                    }
                  )
                }
              }

              items(matchingGroups) { group ->
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                  ),
                  shape = MaterialTheme.shapes.medium
                ) {
                  ListItem(
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    headlineContent = {
                      Text(group.name, fontWeight = FontWeight.SemiBold)
                    },
                    supportingContent = {
                      Text("${group.category} • ${group.membersCount / 1000}K members • Category: Groups")
                    },
                    leadingContent = {
                      Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(42.dp)
                      ) {
                        Box(contentAlignment = Alignment.Center) {
                          Text(
                            text = "G",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                          )
                        }
                      }
                    },
                    trailingContent = {
                      OutlinedButton(onClick = {
                        keyboardController?.hide()
                        onGroupJoinedToggle(group.id)
                      }) {
                        Text(if (group.isJoined) "Joined" else "Join")
                      }
                    }
                  )
                }
              }
            } else {
              // Dynamic result items matching the requested Material 3 Card style
              items(5) { index ->
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                  ),
                  shape = MaterialTheme.shapes.medium
                ) {
                  ListItem(
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    headlineContent = {
                      Text(
                        "Dynamic Result ${index + 1} for '$searchQuery'",
                        fontWeight = FontWeight.SemiBold
                      )
                    },
                    supportingContent = { Text("Category • $selectedTab Profile") },
                    leadingContent = {
                      Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(42.dp)
                      ) {
                        Box(contentAlignment = Alignment.Center) {
                          Text(
                            text = selectedTab.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                          )
                        }
                      }
                    },
                    trailingContent = {
                      OutlinedButton(onClick = { keyboardController?.hide() }) {
                        Text("View")
                      }
                    }
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun CommunityGroupCard(
  group: CommunityGroup,
  onJoinToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Image(
        painter = painterResource(id = group.avatarDrawableRes),
        contentDescription = group.name,
        modifier = Modifier
          .size(52.dp)
          .clip(RoundedCornerShape(10.dp)),
        contentScale = ContentScale.Crop
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(text = group.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(text = "${group.membersCount / 1000}K members", fontSize = 11.sp, color = RxTextSecondary)
          Text(text = "•", fontSize = 11.sp, color = RxTextSecondary)
          Text(text = group.category, fontSize = 11.sp, color = RxBlue, fontWeight = FontWeight.Medium)
        }
        Text(text = group.description, fontSize = 11.sp, color = RxTextMuted, maxLines = 1)
      }

      Spacer(modifier = Modifier.width(8.dp))

      if (group.isJoined) {
        OutlinedButton(
          onClick = onJoinToggle,
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Check, contentDescription = null, tint = RxBlue, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Joined", fontSize = 11.sp, color = RxBlue, fontWeight = FontWeight.Bold)
        }
      } else {
        Button(
          onClick = onJoinToggle,
          colors = ButtonDefaults.buttonColors(containerColor = RxBlue),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Icon(Icons.Default.Group, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Join", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
