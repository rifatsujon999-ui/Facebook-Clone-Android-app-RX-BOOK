package com.example.ui.designsystem

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Modern Design System Tokens for RX BOOK Social Media Architecture
 */
object DesignTokens {

    object Colors {
        // Brand & Accents
        val BrandPrimary = Color(0xFF1877F2)
        val BrandPrimaryDark = Color(0xFF0F56B3)
        val BrandPrimaryLight = Color(0xFFE7F3FF)
        val BrandSecondary = Color(0xFF00C6FF)
        val BrandAccent = Color(0xFF6366F1) // Indigo accent

        // Dark Canvas Palette
        val DarkBackground = Color(0xFF0B0F19)
        val DarkSurface = Color(0xFF131B2E)
        val DarkSurfaceElevated = Color(0xFF1E293B)
        val DarkBorder = Color(0xFF283548)
        val DarkTextPrimary = Color(0xFFF8FAFC)
        val DarkTextSecondary = Color(0xFF94A3B8)
        val DarkTextMuted = Color(0xFF64748B)

        // Light Canvas Palette
        val LightBackground = Color(0xFFF8F9FA)
        val LightSurface = Color(0xFFFFFFFF)
        val LightSurfaceElevated = Color(0xFFF1F5F9)
        val LightBorder = Color(0xFFE2E8F0)
        val LightTextPrimary = Color(0xFF0F172A)
        val LightTextSecondary = Color(0xFF475569)
        val LightTextMuted = Color(0xFF94A3B8)

        // Semantic & Feedback
        val Success = Color(0xFF10B981)
        val Warning = Color(0xFFF59E0B)
        val Error = Color(0xFFEF4444)
        val Info = Color(0xFF38BDF8)
        val HeartRed = Color(0xFFF43F5E)
        val VerifiedBadge = Color(0xFF1D9BF0)

        // Gradients
        val StoryRingGradient = Brush.sweepGradient(
            listOf(
                Color(0xFFF59E0B),
                Color(0xFFEC4899),
                Color(0xFF8B5CF6),
                Color(0xFF3B82F6),
                Color(0xFFF59E0B)
            )
        )

        val ReelsScrim = Brush.verticalGradient(
            colors = listOf(
                Color.Transparent,
                Color.Black.copy(alpha = 0.45f),
                Color.Black.copy(alpha = 0.85f)
            )
        )

        val PrimaryActionGradient = Brush.horizontalGradient(
            listOf(BrandPrimary, BrandSecondary)
        )
    }

    object Spacing {
        val xxs: Dp = 2.dp
        val xs: Dp = 4.dp
        val sm: Dp = 8.dp
        val md: Dp = 12.dp
        val lg: Dp = 16.dp
        val xl: Dp = 20.dp
        val xxl: Dp = 24.dp
        val xxxl: Dp = 32.dp
        val huge: Dp = 48.dp
    }

    object CornerRadius {
        val xs: Dp = 4.dp
        val sm: Dp = 8.dp
        val md: Dp = 12.dp
        val lg: Dp = 16.dp
        val xl: Dp = 24.dp
        val full: Dp = 999.dp
    }

    object Elevation {
        val none: Dp = 0.dp
        val low: Dp = 2.dp
        val medium: Dp = 4.dp
        val high: Dp = 8.dp
    }
}
