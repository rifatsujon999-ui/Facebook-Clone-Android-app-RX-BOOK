@file:kotlin.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Crop169
import androidx.compose.material.icons.filled.CropPortrait
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ai.VeoGenerationState
import com.example.ai.VeoVideoService
import com.example.ui.theme.RxBlue
import com.example.ui.theme.RxCyan
import com.example.ui.theme.RxTextMuted
import com.example.ui.theme.RxTextPrimary
import com.example.ui.theme.RxTextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RxBookVeoVideoModal(
  onDismiss: () -> Unit,
  onPublishVideoPost: (videoUrl: String, prompt: String, aspectRatio: String) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  val clipboardManager = LocalClipboardManager.current

  // Aspect ratio state: either "16:9" (landscape) or "9:16" (portrait)
  var selectedAspectRatio by remember { mutableStateOf("16:9") }
  var promptText by remember {
    mutableStateOf("Cinematic drone flight over futuristic neon skyscraper gardens at golden hour, ultra-detailed volumetric lighting")
  }
  var generationState by remember { mutableStateOf<VeoGenerationState>(VeoGenerationState.Idle) }
  var generatedVideoUri by remember { mutableStateOf<String?>(null) }
  var copiedNotification by remember { mutableStateOf(false) }

  // Sample quick inspiration prompts
  val samplePrompts = listOf(
    "Cyberpunk cityscape at sunset with flying electric vehicles, 4k",
    "Bioluminescent ocean waves crashing against volcanic dark cliffs at night",
    "Macro slow-motion water droplet creating ripple waves with golden refraction",
    "Cute robot barista preparing glowing espresso in a futuristic cafe"
  )

  fun startGeneration() {
    if (promptText.isBlank()) return
    scope.launch {
      VeoVideoService.generateVideo(
        prompt = promptText.trim(),
        aspectRatio = selectedAspectRatio,
        onProgress = { state ->
          generationState = state
          if (state is VeoGenerationState.Success) {
            generatedVideoUri = state.videoUrl
          }
        }
      )
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = CircleShape,
            color = RxBlue.copy(alpha = 0.12f),
            modifier = Modifier.size(38.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = RxBlue,
                modifier = Modifier.size(20.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "Veo 3 Video Studio",
              fontWeight = FontWeight.Bold,
              fontSize = 17.sp,
              color = RxTextPrimary
            )
            Text(
              text = "Model: ${VeoVideoService.MODEL_NAME}",
              fontSize = 11.sp,
              color = RxBlue,
              fontWeight = FontWeight.Medium
            )
          }
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Aspect Ratio Selector (Strictly 16:9 or 9:16)
      Text(
        text = "Aspect Ratio",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = RxTextSecondary
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // 16:9 Landscape Button
        val is169 = selectedAspectRatio == "16:9"
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (is169) RxBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
          border = androidx.compose.foundation.BorderStroke(
            width = if (is169) 2.dp else 1.dp,
            color = if (is169) RxBlue else MaterialTheme.colorScheme.outlineVariant
          ),
          modifier = Modifier
            .weight(1f)
            .clickable { selectedAspectRatio = "16:9" }
        ) {
          Row(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.Crop169,
              contentDescription = null,
              tint = if (is169) RxBlue else RxTextSecondary,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "16:9 Landscape",
                fontWeight = if (is169) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                color = if (is169) RxBlue else RxTextPrimary
              )
              Text("Feed & Desktop", fontSize = 10.sp, color = RxTextSecondary)
            }
          }
        }

        // 9:16 Portrait Button
        val is916 = selectedAspectRatio == "9:16"
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = if (is916) RxBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant,
          border = androidx.compose.foundation.BorderStroke(
            width = if (is916) 2.dp else 1.dp,
            color = if (is916) RxBlue else MaterialTheme.colorScheme.outlineVariant
          ),
          modifier = Modifier
            .weight(1f)
            .clickable { selectedAspectRatio = "9:16" }
        ) {
          Row(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.CropPortrait,
              contentDescription = null,
              tint = if (is916) RxBlue else RxTextSecondary,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "9:16 Portrait",
                fontWeight = if (is916) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                color = if (is916) RxBlue else RxTextPrimary
              )
              Text("Stories & Reels", fontSize = 10.sp, color = RxTextSecondary)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Prompt Input Field
      Text(
        text = "Text Prompt",
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = RxTextSecondary
      )
      Spacer(modifier = Modifier.height(6.dp))

      OutlinedTextField(
        value = promptText,
        onValueChange = { promptText = it },
        placeholder = { Text("Describe what Veo 3 should generate in high fidelity...") },
        modifier = Modifier
          .fillMaxWidth()
          .height(110.dp)
          .testTag("input_veo_prompt"),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = RxBlue,
          unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
        )
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Inspiration Chips
      Text("Inspiration presets:", fontSize = 11.sp, color = RxTextSecondary)
      Spacer(modifier = Modifier.height(4.dp))
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        samplePrompts.forEach { sample ->
          FilterChip(
            selected = promptText == sample,
            onClick = { promptText = sample },
            label = { Text(sample.take(30) + "...", fontSize = 11.sp) },
            shape = RoundedCornerShape(16.dp),
            colors = FilterChipDefaults.filterChipColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Generate Action Button
      val isGenerating = generationState is VeoGenerationState.Submitting || generationState is VeoGenerationState.Polling
      Button(
        onClick = { startGeneration() },
        enabled = !isGenerating && promptText.isNotBlank(),
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("btn_veo_generate"),
        colors = ButtonDefaults.buttonColors(
          containerColor = RxBlue
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        if (isGenerating) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = Color.White,
            strokeWidth = 2.dp
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text("Generating with Veo 3.1...", fontWeight = FontWeight.Bold)
        } else {
          Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("Generate Video ($selectedAspectRatio)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
      }

      // Progress & Status Box
      if (isGenerating) {
        Spacer(modifier = Modifier.height(14.dp))
        Card(
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            CircularProgressIndicator(color = RxBlue, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = when (val s = generationState) {
                is VeoGenerationState.Submitting -> "Submitting job to DeepMind Veo 3.1..."
                is VeoGenerationState.Polling -> s.progressMessage
                else -> "Processing video synthesis..."
              },
              fontWeight = FontWeight.Medium,
              fontSize = 13.sp,
              color = RxTextPrimary
            )
            Text(
              text = "Veo 3 generates realistic temporal motion at 24fps with physics consistency.",
              fontSize = 11.sp,
              color = RxTextMuted,
              modifier = Modifier.padding(top = 4.dp)
            )
          }
        }
      }

      // Error Display & Secrets Panel Guidance
      if (generationState is VeoGenerationState.Error) {
        val errorMsg = (generationState as VeoGenerationState.Error).message
        Spacer(modifier = Modifier.height(14.dp))
        Card(
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
          ),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
          ) {
            Icon(
              Icons.Default.ErrorOutline,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.error,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Veo Video Generation Notice",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.error
              )
              Text(
                text = errorMsg,
                fontSize = 12.sp,
                color = RxTextPrimary,
                modifier = Modifier.padding(vertical = 4.dp)
              )
              if (errorMsg.contains("GEMINI_API_KEY", ignoreCase = true) || errorMsg.contains("key", ignoreCase = true)) {
                Text(
                  text = "Tip: Configure GEMINI_API_KEY in the Secrets panel in AI Studio to enable live Veo 3 calls.",
                  fontSize = 11.sp,
                  color = RxBlue,
                  fontWeight = FontWeight.Medium
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              OutlinedButton(
                onClick = {
                  val sample = VeoVideoService.CURATED_SAMPLE_VIDEOS.first()
                  generatedVideoUri = sample.url
                  generationState = VeoGenerationState.Success(sample.url, sample.prompt, sample.aspectRatio)
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Load Curated 4K Video Stream Instead", fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      // Video Preview & Publish Section
      if (generatedVideoUri != null || generationState is VeoGenerationState.Success) {
        val videoUrl = generatedVideoUri ?: (generationState as? VeoGenerationState.Success)?.videoUrl ?: ""
        Spacer(modifier = Modifier.height(18.dp))
        Text(
          text = "Generated Video Preview ($selectedAspectRatio)",
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black)
            .then(
              if (selectedAspectRatio == "9:16") {
                Modifier
                  .fillMaxWidth(0.65f)
                  .aspectRatio(9f / 16f)
              } else {
                Modifier
                  .fillMaxWidth()
                  .aspectRatio(16f / 9f)
              }
            ),
          contentAlignment = Alignment.Center
        ) {
          val context = androidx.compose.ui.platform.LocalContext.current
          var exoPlayer by remember { mutableStateOf<androidx.media3.exoplayer.ExoPlayer?>(null) }

          androidx.compose.runtime.DisposableEffect(videoUrl) {
            val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
              .setAllowCrossProtocolRedirects(true)
              .setConnectTimeoutMs(15000)
              .setReadTimeoutMs(15000)
              .setUserAgent("RxBookVeoPlayer/1.0")

            val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context)
              .setDataSourceFactory(httpDataSourceFactory)

            val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context)
              .setEnableDecoderFallback(true)

            val player = androidx.media3.exoplayer.ExoPlayer.Builder(context, renderersFactory)
              .setMediaSourceFactory(mediaSourceFactory)
              .build().apply {
                repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                playWhenReady = true
                setMediaItem(androidx.media3.common.MediaItem.fromUri(videoUrl))
                addListener(object : androidx.media3.common.Player.Listener {
                  override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    android.util.Log.e("VeoVideoModal", "Handled video playback error: ${error.errorCodeName}")
                  }
                })
                prepare()
              }
            exoPlayer = player

            onDispose {
              exoPlayer?.stop()
              exoPlayer?.clearMediaItems()
              exoPlayer?.release()
              exoPlayer = null
            }
          }

          AndroidView(
            factory = { ctx ->
              val view = android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.item_reel_player, null, false)
              val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.reelPlayerView)
              playerView.player = exoPlayer
              view
            },
            update = { view ->
              val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.reelPlayerView)
              playerView.player = exoPlayer
            },
            onRelease = { view ->
              val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.reelPlayerView)
              playerView.player = null
            },
            modifier = Modifier.fillMaxSize()
          )

          // Veo badge overlay
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color.Black.copy(alpha = 0.65f),
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(10.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RxCyan, modifier = Modifier.size(12.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Veo 3.1 • $selectedAspectRatio", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Actions on Generated Video
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          OutlinedButton(
            onClick = {
              clipboardManager.setText(AnnotatedString(videoUrl))
              copiedNotification = true
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (copiedNotification) "Copied!" else "Copy URL", fontSize = 12.sp)
          }

          Button(
            onClick = {
              onPublishVideoPost(videoUrl, promptText, selectedAspectRatio)
              onDismiss()
            },
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RxBlue),
            modifier = Modifier.weight(1.4f)
          ) {
            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Publish to RxBook", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(28.dp))
    }
  }
}
