package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.UUID

data class CommentItem(
  val id: String,
  val userName: String,
  val text: String,
  val timestamp: String,
  val initialLikeCount: Int,
  val isLikedByMe: Boolean,
  val isPending: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RxBookCommentSheet(
  postId: String,
  onDismiss: () -> Unit,
  onCommentSubmitted: (String, String) -> Unit // commentId, text
) {
  var commentText by remember { mutableStateOf("") }
  val keyboardController = LocalSoftwareKeyboardController.current
  val coroutineScope = rememberCoroutineScope()

  // Real-time local state engine managing the specific list hierarchy
  var commentsList by remember {
    mutableStateOf(
      listOf(
        CommentItem(UUID.randomUUID().toString(), "Dr. Fahim Ahmed", "Excellent architectural breakdown of the Redis engine!", "2h", 24, true),
        CommentItem(UUID.randomUUID().toString(), "Sarah Karim", "Will this support AVIF fallback on older Android devices?", "45m", 3, false),
        CommentItem(UUID.randomUUID().toString(), "Rashedul Islam", "The CLS mitigation strategies are stellar.", "5m", 0, false)
      )
    )
  }

  fun submitComment() {
    val trimmed = commentText.trim()
    if (trimmed.isNotBlank()) {
      val newCommentId = UUID.randomUUID().toString()
      // 🚀 Optimistic UI Injection: Prepend content locally instantly
      val optimisticComment = CommentItem(
        id = newCommentId,
        userName = "You",
        text = trimmed,
        timestamp = "Sending...",
        initialLikeCount = 0,
        isLikedByMe = false,
        isPending = true
      )
      commentsList = listOf(optimisticComment) + commentsList
      onCommentSubmitted(newCommentId, trimmed)

      commentText = ""
      keyboardController?.hide()

      // Transition pending to confirmed
      coroutineScope.launch {
        kotlinx.coroutines.delay(700)
        commentsList = commentsList.map {
          if (it.id == newCommentId) {
            it.copy(isPending = false, timestamp = "Just now")
          } else it
        }
      }
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    dragHandle = { BottomSheetDefaults.DragHandle() },
    contentWindowInsets = { WindowInsets.ime } // Automatically shifts the container upward when keyboard opens
  ) {
    Column(
      modifier = Modifier
        .fillMaxHeight(0.85f) // Clamps screen real estate to prevent absolute overflow
        .padding(horizontal = 16.dp)
        .imePadding()
    ) {
      // Header Section
      Text(
        text = "Comments (${commentsList.size})",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 12.dp)
      )

      // Dynamic Comments Stream Viewport
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(commentsList, key = { it.id }) { comment ->
          CommentRowCard(
            comment = comment,
            onLikeToggled = { liked ->
              commentsList = commentsList.map {
                if (it.id == comment.id) {
                  it.copy(
                    isLikedByMe = liked,
                    initialLikeCount = it.initialLikeCount + (if (liked) 1 else -1)
                  )
                } else it
              }
            }
          )
        }
      }

      // Input Dock Area (Fixed at base layout barrier)
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        color = MaterialTheme.colorScheme.surface
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = commentText,
            onValueChange = { commentText = it },
            modifier = Modifier
              .weight(1f)
              .testTag("input_comment_text"),
            placeholder = { Text("Write a comment...") },
            shape = CircleShape,
            maxLines = 3,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(
              onSend = { submitComment() }
            )
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = { submitComment() },
            colors = IconButtonDefaults.iconButtonColors(
              containerColor = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier
              .size(48.dp)
              .testTag("button_send_comment")
          ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send Comment")
          }
        }
      }
    }
  }
}

@Composable
fun CommentRowCard(
  comment: CommentItem,
  onLikeToggled: (Boolean) -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(
      containerColor = if (comment.isPending)
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
      else
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    ),
    shape = MaterialTheme.shapes.medium
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.Top
    ) {
      // Initial Avatar Generator
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(36.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Text(
            text = comment.userName.take(1),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Text Payload Core Block
      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = comment.userName,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = if (comment.isPending) "Sending..." else comment.timestamp,
            style = MaterialTheme.typography.labelSmall,
            color = if (comment.isPending) MaterialTheme.colorScheme.primary else Color.Gray
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = comment.text,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          IconButton(
            onClick = { onLikeToggled(!comment.isLikedByMe) },
            modifier = Modifier.size(28.dp)
          ) {
            Icon(
              imageVector = if (comment.isLikedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
              contentDescription = if (comment.isLikedByMe) "Unlike" else "Like",
              tint = if (comment.isLikedByMe) Color(0xFFE0245E) else Color.Gray,
              modifier = Modifier.size(16.dp)
            )
          }
          if (comment.initialLikeCount > 0) {
            Text(
              text = "${comment.initialLikeCount}",
              style = MaterialTheme.typography.labelSmall,
              color = if (comment.isLikedByMe) Color(0xFFE0245E) else Color.Gray,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }
  }
}
