package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

enum class MessageStatus { PENDING, DELIVERED, READ, FAILED_RETRY }

data class MessageBubble(
  val id: String,
  val senderId: String,
  val text: String,
  val timestamp: String,
  val status: MessageStatus
)

data class ActiveUser(
  val id: String,
  val name: String,
  val isOnline: Boolean,
  val unreadCount: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RxBookMessengerSheet(
  recipientId: String = "user_2",
  onDismiss: () -> Unit,
  onSocketMessageDispatched: (String, String) -> Unit = { _, _ -> }
) {
  var chatInput by remember { mutableStateOf("") }
  val keyboardController = LocalSoftwareKeyboardController.current
  val coroutineScope = rememberCoroutineScope()

  // Active Online User Tracker State
  val activeUsers = remember {
    listOf(
      ActiveUser("1", "Tamim", true, 0),
      ActiveUser("2", "Nabila", true, 3),
      ActiveUser("3", "Fahad", true, 1),
      ActiveUser("4", "Anika", false, 0),
      ActiveUser("5", "Rahat", true, 0)
    )
  }

  // Message History Stack Stream
  var executionThread by remember {
    mutableStateOf(
      listOf(
        MessageBubble("m1", "current_user", "Hey, is the production database replica balanced?", "10:30 AM", MessageStatus.READ),
        MessageBubble("m2", recipientId, "Yes, all read-heavy lookups are serving from slaves.", "10:32 AM", MessageStatus.READ),
        MessageBubble("m3", "current_user", "Awesome. Did you push the AVIF processing changes?", "10:33 AM", MessageStatus.DELIVERED)
      )
    )
  }

  fun sendMessage() {
    val trimmed = chatInput.trim()
    if (trimmed.isNotBlank()) {
      val localId = UUID.randomUUID().toString()
      val outgoingBubble = MessageBubble(
        id = localId,
        senderId = "current_user",
        text = trimmed,
        timestamp = "Just now",
        status = MessageStatus.PENDING
      )
      executionThread = executionThread + outgoingBubble
      onSocketMessageDispatched(localId, trimmed)

      chatInput = ""
      keyboardController?.hide()

      // Real-time delivery status transition simulation: PENDING -> DELIVERED -> READ
      coroutineScope.launch {
        delay(700)
        executionThread = executionThread.map {
          if (it.id == localId) it.copy(status = MessageStatus.DELIVERED) else it
        }
        delay(1200)
        executionThread = executionThread.map {
          if (it.id == localId) it.copy(status = MessageStatus.READ) else it
        }
      }
    }
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    dragHandle = { BottomSheetDefaults.DragHandle() },
    contentWindowInsets = { WindowInsets.ime }
  ) {
    Column(
      modifier = Modifier
        .fillMaxHeight(0.9f)
        .padding(horizontal = 16.dp)
        .imePadding()
    ) {
      // 🟢 Horizontal Active User Bar
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .padding(bottom = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        items(activeUsers) { user ->
          ActiveUserNode(user = user)
        }
      }

      HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

      // 📞 WebRTC P2P Call Header (NestJS Signaling Mesh)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(9.dp)
              .clip(CircleShape)
              .background(com.example.ui.theme.RxOnlineGreen)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "E2EE P2P Session (Mesh)",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(
            onClick = {
              com.example.webrtc.RxNestJsSignalingManager.initiateCall(
                peerId = recipientId,
                peerName = "Nabila",
                peerAvatarRes = com.example.R.drawable.rx_feed_post_travel_1789358396512,
                callType = com.example.webrtc.CallType.AUDIO
              )
            },
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Call,
              contentDescription = "Audio Call",
              tint = com.example.ui.theme.ElectricRoyalBlue,
              modifier = Modifier.size(19.dp)
            )
          }

          IconButton(
            onClick = {
              com.example.webrtc.RxNestJsSignalingManager.initiateCall(
                peerId = recipientId,
                peerName = "Nabila",
                peerAvatarRes = com.example.R.drawable.rx_feed_post_travel_1789358396512,
                callType = com.example.webrtc.CallType.VIDEO
              )
            },
            modifier = Modifier.size(36.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Videocam,
              contentDescription = "Video Call",
              tint = com.example.ui.theme.ElectricRoyalBlue,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }

      HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outlineVariant)

      // Dynamic Chat Viewport Stack
      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        reverseLayout = false // Stack messages sequentially
      ) {
        items(executionThread, key = { it.id }) { message ->
          val isMe = message.senderId == "current_user"
          ChatBubbleCard(message = message, isMe = isMe)
        }
      }

      // Chat Form Entry Block
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        color = MaterialTheme.colorScheme.surface
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = chatInput,
            onValueChange = { chatInput = it },
            modifier = Modifier
              .weight(1f)
              .testTag("input_messenger_text"),
            placeholder = { Text("Type a secure message...") },
            shape = CircleShape,
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(
              onSend = { sendMessage() }
            )
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = { sendMessage() },
            colors = IconButtonDefaults.iconButtonColors(
              containerColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
              .size(48.dp)
              .testTag("button_messenger_send")
          ) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
          }
        }
      }
    }
  }
}

@Composable
fun ActiveUserNode(user: ActiveUser) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = Modifier.padding(vertical = 4.dp)
  ) {
    Box(modifier = Modifier.size(52.dp)) {
      // Profile Initials Box
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier.fillMaxSize()
      ) {
        Box(contentAlignment = Alignment.Center) {
          Text(user.name.take(2).uppercase(), fontWeight = FontWeight.Bold)
        }
      }

      // 🟢 Online Status Indicator Dot
      if (user.isOnline) {
        Box(
          modifier = Modifier
            .size(14.dp)
            .clip(CircleShape)
            .background(Color(0xFF2ECC71))
            .align(Alignment.BottomEnd)
        )
      }

      // 🔴 Dynamic Unread Count Badge
      if (user.unreadCount > 0) {
        Box(
          modifier = Modifier
            .size(18.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.error)
            .align(Alignment.TopEnd),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "${user.unreadCount}",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(user.name, style = MaterialTheme.typography.labelMedium)
  }
}

@Composable
fun ChatBubbleCard(message: MessageBubble, isMe: Boolean) {
  Box(
    modifier = Modifier.fillMaxWidth(),
    contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
  ) {
    Column(
      horizontalAlignment = if (isMe) Alignment.End else Alignment.Start,
      modifier = Modifier.padding(horizontal = 4.dp)
    ) {
      Surface(
        shape = RoundedCornerShape(
          topStart = 16.dp,
          topEnd = 16.dp,
          bottomStart = if (isMe) 16.dp else 4.dp,
          bottomEnd = if (isMe) 4.dp else 16.dp
        ),
        color = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        contentColor = if (isMe) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        shadowElevation = 1.dp
      ) {
        Box(
          modifier = Modifier
            .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
          Text(
            text = message.text,
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 14.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      // Status and Timestamp Row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.padding(horizontal = 4.dp)
      ) {
        Text(
          text = message.timestamp,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
          fontSize = 11.sp
        )

        if (isMe) {
          when (message.status) {
            MessageStatus.PENDING -> {
              Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = "Pending",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(12.dp)
              )
            }
            MessageStatus.DELIVERED -> {
              Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Delivered",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(12.dp)
              )
            }
            MessageStatus.READ -> {
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Read",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(12.dp)
              )
            }
            MessageStatus.FAILED_RETRY -> {
              Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = "Failed",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(12.dp)
              )
            }
          }
        }
      }
    }
  }
}
