package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.ui.theme.ElectricRoyalBlue
import com.example.ui.theme.MidnightBlueText
import com.example.ui.theme.PureWhiteSurface
import com.example.ui.theme.RazorThinBorder
import com.example.ui.theme.RxBlueLight
import com.example.ui.theme.RxOnlineGreen
import com.example.webrtc.CallRole
import com.example.webrtc.CallSessionState
import com.example.webrtc.CallStatus
import com.example.webrtc.CallType
import com.example.webrtc.RxNestJsSignalingManager
import com.example.webrtc.SignalingStep

/**
 * Format call duration to MM:SS
 */
fun formatCallDuration(seconds: Int): String {
  val m = seconds / 60
  val s = seconds % 60
  return "%02d:%02d".format(m, s)
}

/**
 * Main WebRTC Calling UI & Root Overlay
 */
@Composable
fun RxCallOverlay(
  modifier: Modifier = Modifier
) {
  val sessionState by RxNestJsSignalingManager.sessionState.collectAsState()

  if (sessionState.status == CallStatus.IDLE) return

  // 1. Incoming Call Prompt Modal
  if (sessionState.status == CallStatus.RINGING_INCOMING) {
    RxIncomingCallDialog(
      sessionState = sessionState,
      onAccept = { RxNestJsSignalingManager.acceptIncomingCall() },
      onDecline = { RxNestJsSignalingManager.declineCall() }
    )
    return
  }

  // 2. Active Call Screen
  RxActiveCallScreen(
    sessionState = sessionState,
    onEndCall = { RxNestJsSignalingManager.endCall() },
    onToggleMic = { RxNestJsSignalingManager.toggleMic() },
    onToggleCamera = { RxNestJsSignalingManager.toggleCamera() },
    onFlipCamera = { RxNestJsSignalingManager.flipCamera() },
    onToggleSpeaker = { RxNestJsSignalingManager.toggleSpeaker() }
  )
}

/**
 * Fullscreen Interactive Call Experience with Live WebRTC Media & Diagnostics
 */
@Composable
fun RxActiveCallScreen(
  sessionState: CallSessionState,
  onEndCall: () -> Unit,
  onToggleMic: () -> Unit,
  onToggleCamera: () -> Unit,
  onFlipCamera: () -> Unit,
  onToggleSpeaker: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showSignalingDrawer by remember { mutableStateOf(false) }

  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulseScale"
  )

  Dialog(
    onDismissRequest = {},
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .background(Color(0xFF090D16))
        .testTag("rx_call_screen")
    ) {
      // 1. Remote Media / Backdrop Stream
      if (sessionState.callType == CallType.VIDEO && sessionState.isCameraEnabled && sessionState.status == CallStatus.CONNECTED) {
        // Video Stream Simulation with realistic peer video
        Box(modifier = Modifier.fillMaxSize()) {
          Image(
            painter = painterResource(id = sessionState.peerAvatarRes ?: R.drawable.rx_feed_post_tech_1789358410043),
            contentDescription = "Remote Video Stream",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
          // Gradient Scrim for controls readability
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(
                    Color.Black.copy(alpha = 0.65f),
                    Color.Transparent,
                    Color.Black.copy(alpha = 0.85f)
                  )
                )
              )
          )
        }
      } else {
        // Audio Call or Connecting state: Clean pulsating avatar canvas
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(top = 110.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Box(contentAlignment = Alignment.Center) {
            if (sessionState.status != CallStatus.CONNECTED) {
              Box(
                modifier = Modifier
                  .size(170.dp)
                  .scale(pulseScale)
                  .clip(CircleShape)
                  .background(ElectricRoyalBlue.copy(alpha = 0.15f))
              )
            }
            Surface(
              shape = CircleShape,
              color = ElectricRoyalBlue,
              modifier = Modifier
                .size(120.dp)
                .border(3.dp, ElectricRoyalBlue.copy(alpha = 0.5f), CircleShape)
            ) {
              Image(
                painter = painterResource(id = sessionState.peerAvatarRes ?: R.drawable.rx_feed_post_tech_1789358410043),
                contentDescription = sessionState.peerName,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
              )
            }
          }

          Spacer(modifier = Modifier.height(20.dp))
          Text(
            text = sessionState.peerName,
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = when (sessionState.status) {
              CallStatus.RINGING_OUTGOING -> "Ringing..."
              CallStatus.CONNECTING -> "Connecting via NestJS Mesh..."
              CallStatus.CONNECTED -> "P2P Connected • ${formatCallDuration(sessionState.durationSeconds)}"
              CallStatus.ENDED -> "Call Ended"
              CallStatus.DECLINED -> "Call Declined"
              else -> "Connecting..."
            },
            color = if (sessionState.status == CallStatus.CONNECTED) RxOnlineGreen else Color(0xFF94A3B8),
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // 2. Floating Local PIP Preview (for Video Calls)
      if (sessionState.callType == CallType.VIDEO && sessionState.isCameraEnabled) {
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = Color(0xFF1E293B),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White.copy(alpha = 0.25f)),
          modifier = Modifier
            .padding(top = 80.dp, end = 16.dp)
            .size(width = 100.dp, height = 150.dp)
            .align(Alignment.TopEnd)
            .testTag("pip_local_video")
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            Image(
              painter = painterResource(id = R.drawable.rx_book_app_icon_1789358378841),
              contentDescription = "Local Camera",
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
            IconButton(
              onClick = onFlipCamera,
              modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(4.dp)
                .size(28.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
              Icon(
                imageVector = Icons.Default.Cameraswitch,
                contentDescription = "Flip Camera",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }

      // 3. Top Call Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // E2EE Badge
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = Color.Black.copy(alpha = 0.55f),
          border = androidx.compose.foundation.BorderStroke(0.8.dp, Color.White.copy(alpha = 0.15f))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = "E2EE",
              tint = RxOnlineGreen,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (sessionState.status == CallStatus.CONNECTED) "P2P WebRTC Direct" else "NestJS Signaling",
              color = Color.White.copy(alpha = 0.9f),
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        // Live Signaling Mesh Step / Diagnostics Button
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = ElectricRoyalBlue.copy(alpha = 0.25f),
          border = androidx.compose.foundation.BorderStroke(1.dp, ElectricRoyalBlue.copy(alpha = 0.4f)),
          modifier = Modifier
            .clickable { showSignalingDrawer = true }
            .testTag("btn_signaling_diagnostics")
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "Signaling Diagnostics",
              tint = ElectricRoyalBlue,
              modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = "Mesh Flow",
              color = Color.White,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // 4. In-Call Bottom Control Deck
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(bottom = 28.dp, start = 20.dp, end = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Quality Telemetry Bar
        if (sessionState.status == CallStatus.CONNECTED) {
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(Color.Black.copy(alpha = 0.6f))
              .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(RxOnlineGreen)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "RTT: ${sessionState.rttLatencyMs}ms • ${sessionState.bitrateKbps} kbps • Opus/VP8",
              color = Color.White.copy(alpha = 0.75f),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(18.dp))
        }

        // Action Buttons Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Mic Toggle
          CallDeckButton(
            icon = if (sessionState.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
            isActive = !sessionState.isMicMuted,
            label = if (sessionState.isMicMuted) "Unmute" else "Mute",
            onClick = onToggleMic,
            testTag = "btn_call_mic"
          )

          // Camera Toggle (for video calls)
          if (sessionState.callType == CallType.VIDEO) {
            CallDeckButton(
              icon = if (sessionState.isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
              isActive = sessionState.isCameraEnabled,
              label = if (sessionState.isCameraEnabled) "Camera On" else "Camera Off",
              onClick = onToggleCamera,
              testTag = "btn_call_camera"
            )
          }

          // Speaker Toggle
          CallDeckButton(
            icon = if (sessionState.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
            isActive = sessionState.isSpeakerOn,
            label = "Speaker",
            onClick = onToggleSpeaker,
            testTag = "btn_call_speaker"
          )

          // End Call Button (Crimson Red)
          Surface(
            shape = CircleShape,
            color = Color(0xFFEF4444),
            modifier = Modifier
              .size(56.dp)
              .clickable(onClick = onEndCall)
              .testTag("btn_end_call")
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.CallEnd,
                contentDescription = "End Call",
                tint = Color.White,
                modifier = Modifier.size(28.dp)
              )
            }
          }
        }
      }

      // 5. NestJS Signaling Mesh Sequence Inspector Sheet
      if (showSignalingDrawer) {
        SignalingSequenceModal(
          sessionState = sessionState,
          onDismiss = { showSignalingDrawer = false }
        )
      }
    }
  }
}

/**
 * Circular action button inside the in-call bottom bar
 */
@Composable
fun CallDeckButton(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isActive: Boolean,
  label: String,
  onClick: () -> Unit,
  testTag: String
) {
  Column(
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Surface(
      shape = CircleShape,
      color = if (isActive) Color.White.copy(alpha = 0.2f) else Color.White,
      modifier = Modifier
        .size(50.dp)
        .clickable(onClick = onClick)
        .testTag(testTag)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = icon,
          contentDescription = label,
          tint = if (isActive) Color.White else Color(0xFF0F172A),
          modifier = Modifier.size(24.dp)
        )
      }
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = label,
      color = Color.White.copy(alpha = 0.7f),
      fontSize = 11.sp
    )
  }
}

/**
 * Incoming Call Notification Dialog
 */
@Composable
fun RxIncomingCallDialog(
  sessionState: CallSessionState,
  onAccept: () -> Unit,
  onDecline: () -> Unit
) {
  Dialog(
    onDismissRequest = onDecline,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black.copy(alpha = 0.8f))
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhiteSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .testTag("incoming_call_dialog")
      ) {
        Column(
          modifier = Modifier.padding(28.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = if (sessionState.callType == CallType.VIDEO) "INCOMING VIDEO CALL" else "INCOMING AUDIO CALL",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = ElectricRoyalBlue,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(18.dp))

          Surface(
            shape = CircleShape,
            color = RxBlueLight,
            modifier = Modifier
              .size(90.dp)
              .border(2.dp, ElectricRoyalBlue, CircleShape)
          ) {
            Image(
              painter = painterResource(id = sessionState.peerAvatarRes ?: R.drawable.rx_feed_post_travel_1789358396512),
              contentDescription = sessionState.peerName,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          }

          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = sessionState.peerName,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = MidnightBlueText
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "rxBook WebRTC Signaling Mesh",
            fontSize = 13.sp,
            color = Color(0xFF64748B)
          )

          Spacer(modifier = Modifier.height(30.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
          ) {
            // Decline Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Surface(
                shape = CircleShape,
                color = Color(0xFFEF4444),
                modifier = Modifier
                  .size(56.dp)
                  .clickable(onClick = onDecline)
                  .testTag("btn_decline_incoming_call")
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.CallEnd,
                    contentDescription = "Decline",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text("Decline", fontSize = 12.sp, color = Color(0xFF64748B))
            }

            // Accept Button
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Surface(
                shape = CircleShape,
                color = RxOnlineGreen,
                modifier = Modifier
                  .size(56.dp)
                  .clickable(onClick = onAccept)
                  .testTag("btn_accept_incoming_call")
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Accept",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                  )
                }
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text("Accept", fontSize = 12.sp, color = RxOnlineGreen, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

/**
 * Bottom Sheet displaying the 6-step sequence diagram in real time
 */
@Composable
fun SignalingSequenceModal(
  sessionState: CallSessionState,
  onDismiss: () -> Unit
) {
  val steps = listOf(
    SignalingStep.STEP_1_INITIATE_CALL_OFFER,
    SignalingStep.STEP_2_INCOMING_SIGNAL_OFFER,
    SignalingStep.STEP_3_ACCEPT_CALL_ANSWER,
    SignalingStep.STEP_4_CALL_ACCEPTED_SIGNAL,
    SignalingStep.STEP_5_ICE_CANDIDATES_SYNC,
    SignalingStep.STEP_6_CONNECTED_P2P
  )

  Dialog(onDismissRequest = onDismiss) {
    Card(
      shape = RoundedCornerShape(20.dp),
      colors = CardDefaults.cardColors(containerColor = PureWhiteSurface),
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
        .testTag("signaling_sequence_dialog")
    ) {
      Column(
        modifier = Modifier.padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "NestJS WebRTC Mesh Protocol",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MidnightBlueText
          )
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = MidnightBlueText)
          }
        }

        Text(
          text = "Real-time state verification corresponding to the 6-step sequence diagram:",
          fontSize = 12.sp,
          color = Color(0xFF64748B)
        )

        Spacer(modifier = Modifier.height(14.dp))

        steps.forEach { step ->
          val isCompleted = sessionState.currentStep.stepNumber >= step.stepNumber
          val isCurrent = sessionState.currentStep == step

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = CircleShape,
              color = if (isCompleted) RxOnlineGreen else Color(0xFFE2E8F0),
              modifier = Modifier.size(24.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                if (isCompleted) {
                  Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                  )
                } else {
                  Text(
                    text = "${step.stepNumber}",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = step.title,
                fontSize = 12.5.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold,
                color = if (isCurrent) ElectricRoyalBlue else MidnightBlueText
              )
              Text(
                text = step.description,
                fontSize = 11.sp,
                color = Color(0xFF64748B)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = RazorThinBorder)
        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "STUN Server: ${sessionState.stunTurnServer}",
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          color = Color(0xFF64748B)
        )
      }
    }
  }
}

/**
 * Jetpack Compose call screen matching the RxCallScreen interface:
 * targetUserName: String, isVideoCall: Boolean, onEndCall: () -> Unit
 */
@Composable
fun RxCallScreen(
  targetUserName: String,
  isVideoCall: Boolean,
  onEndCall: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var isMuted by remember { mutableStateOf(false) }
  var isCameraOff by remember { mutableStateOf(false) }
  val haptic = LocalHapticFeedback.current

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(if (isVideoCall) Color(0xFF0F172A) else Color(0xFFF8F9FA))
      .testTag("rx_call_screen_flutter_equivalent")
  ) {
    if (isVideoCall) {
      // Remote video feed
      Image(
        painter = painterResource(id = R.drawable.rx_feed_post_tech_1789358410043),
        contentDescription = "Remote Video Stream",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
    } else {
      // Audio Call layout
      Column(
        modifier = Modifier.align(Alignment.Center),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(112.dp)
            .clip(CircleShape)
            .background(Color(0xFF1877F2).copy(alpha = 0.1f)),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = "RX",
            style = MaterialTheme.typography.titleLarge.copy(
              fontSize = 28.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF1877F2)
            )
          )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = targetUserName,
          style = MaterialTheme.typography.headlineSmall.copy(
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
          )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "RX BOOK Secure Audio Stream...",
          style = MaterialTheme.typography.bodyMedium.copy(
            color = Color.Gray,
            fontSize = 14.sp
          )
        )
      }
    }

    // Local Video Preview Thumbnail (PiP)
    if (isVideoCall && !isCameraOff) {
      Box(
        modifier = Modifier
          .align(Alignment.TopEnd)
          .padding(top = 54.dp, end = 16.dp)
          .size(width = 110.dp, height = 170.dp)
          .clip(RoundedCornerShape(16.dp))
          .border(2.dp, Color.White, RoundedCornerShape(16.dp))
          .background(Color.Black.copy(alpha = 0.2f))
      ) {
        Image(
          painter = painterResource(id = R.drawable.rx_feed_post_tech_1789358410043),
          contentDescription = "Local Camera Preview",
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
      }
    }

    // Bottom In-Call Controls Pill
    Surface(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(start = 24.dp, end = 24.dp, bottom = 40.dp)
        .shadow(16.dp, RoundedCornerShape(36.dp), spotColor = Color.Black.copy(alpha = 0.1f)),
      shape = RoundedCornerShape(36.dp),
      color = Color.White.copy(alpha = 0.92f)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 14.dp, horizontal = 24.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            isMuted = !isMuted
          }
        ) {
          Icon(
            imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
            contentDescription = if (isMuted) "Unmute" else "Mute",
            tint = if (isMuted) Color.Red else Color(0xFF0F172A)
          )
        }

        if (isVideoCall) {
          IconButton(
            onClick = {
              haptic.performHapticFeedback(HapticFeedbackType.LongPress)
              isCameraOff = !isCameraOff
            }
          ) {
            Icon(
              imageVector = if (isCameraOff) Icons.Default.VideocamOff else Icons.Default.Videocam,
              contentDescription = if (isCameraOff) "Turn Camera On" else "Turn Camera Off",
              tint = if (isCameraOff) Color.Red else Color(0xFF0F172A)
            )
          }
        }

        Surface(
          shape = CircleShape,
          color = Color(0xFFE0245E),
          modifier = Modifier
            .size(48.dp)
            .clickable {
              haptic.performHapticFeedback(HapticFeedbackType.LongPress)
              onEndCall()
            }
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Default.CallEnd,
              contentDescription = "End Call",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }
        }
      }
    }
  }
}

