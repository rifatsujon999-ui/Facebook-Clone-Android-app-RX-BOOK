@file:kotlin.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUpOffAlt
import androidx.compose.material.icons.filled.Videocam
import android.net.Uri
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ReactionType
import com.example.model.SocialComment
import com.example.model.SocialPost
import com.example.model.SocialStory
import com.example.model.SocialUser
import com.example.ui.theme.ElectricRoyalBlue
import com.example.ui.theme.MidnightBlueText
import com.example.ui.theme.PureWhiteSurface
import com.example.ui.theme.RazorThinBorder
import com.example.ui.theme.SlateGreyAction
import com.example.ui.theme.ReactionAngry
import com.example.ui.theme.ReactionHaha
import com.example.ui.theme.ReactionLike
import com.example.ui.theme.ReactionLove
import com.example.ui.theme.ReactionSad
import com.example.ui.theme.ReactionWow
import com.example.ui.theme.RxBlue
import com.example.ui.theme.RxBorder
import com.example.ui.theme.RxCyan
import com.example.ui.theme.RxOnlineGreen
import com.example.ui.theme.RxTextMuted
import com.example.ui.theme.RxTextPrimary
import com.example.ui.theme.RxTextSecondary

@Composable
fun RxTopBar(
  unreadChatCount: Int,
  onOpenChat: () -> Unit,
  onSearchClick: () -> Unit,
  onOpenReels: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = PureWhiteSurface,
    shadowElevation = 0.dp
  ) {
    Column {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "RX",
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Black,
              color = ElectricRoyalBlue,
              letterSpacing = (-1).sp
            )
          )
          Text(
            text = "BOOK",
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              color = MidnightBlueText,
              letterSpacing = (-0.5).sp
            )
          )
          Spacer(modifier = Modifier.width(6.dp))
          Surface(
            shape = CircleShape,
            color = RxOnlineGreen,
            modifier = Modifier.size(8.dp)
          ) {}
        }

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Reels Quick Access Button
          Surface(
            shape = RoundedCornerShape(20.dp),
            color = SlateGreyAction,
            modifier = Modifier
              .height(38.dp)
              .clickable(onClick = onOpenReels)
              .testTag("btn_top_reels")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Watch Reels",
                tint = Color(0xFFEF4444),
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "Reels",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MidnightBlueText
              )
            }
          }

          Surface(
            shape = CircleShape,
            color = SlateGreyAction,
            modifier = Modifier
              .size(38.dp)
              .clickable(onClick = onSearchClick)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = MidnightBlueText,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          BadgedBox(
            badge = {
              if (unreadChatCount > 0) {
                Badge(
                  containerColor = Color(0xFFEF4444),
                  contentColor = Color.White
                ) {
                  Text("$unreadChatCount", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          ) {
            Surface(
              shape = CircleShape,
              color = SlateGreyAction,
              modifier = Modifier
                .size(38.dp)
                .clickable(onClick = onOpenChat)
                .testTag("btn_top_messenger")
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.ChatBubbleOutline,
                  contentDescription = "Messenger",
                  tint = ElectricRoyalBlue,
                  modifier = Modifier.size(20.dp)
                )
              }
            }
          }
        }
      }
      Divider(color = RazorThinBorder, thickness = 1.dp)
    }
  }
}

@Composable
fun CreatePostEntryCard(
  currentUser: SocialUser,
  onOpenCreatePost: () -> Unit,
  onOpenVeoVideo: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhiteSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, RazorThinBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        Image(
          painter = painterResource(id = currentUser.avatarDrawableRes),
          contentDescription = currentUser.displayName,
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape),
          contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.width(10.dp))

        Box(
          modifier = Modifier
            .weight(1f)
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(SlateGreyAction)
            .clickable(onClick = onOpenCreatePost)
            .padding(horizontal = 14.dp),
          contentAlignment = Alignment.CenterStart
        ) {
          Text(
            text = "What's on your mind, ${currentUser.displayName.split(" ")[0]}?",
            color = RxTextSecondary,
            fontSize = 13.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))
      Divider(color = RazorThinBorder, thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround
      ) {
        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onOpenCreatePost)
            .padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(19.dp))
          Spacer(modifier = Modifier.width(5.dp))
          Text("Photo", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
        }

        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onOpenVeoVideo)
            .padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RxBlue, modifier = Modifier.size(19.dp))
          Spacer(modifier = Modifier.width(5.dp))
          Text("Veo 3 Video", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = RxBlue)
        }

        Row(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onOpenCreatePost)
            .padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Videocam, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(19.dp))
          Spacer(modifier = Modifier.width(5.dp))
          Text("Stream Video", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
        }
      }
    }
  }
}

@Composable
fun StoriesTray(
  stories: List<SocialStory>,
  onStoryClick: (SocialStory) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyRow(
    modifier = modifier.fillMaxWidth(),
    contentPadding = PaddingValues(horizontal = 16.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(stories) { story ->
      Card(
        modifier = Modifier
          .width(105.dp)
          .height(160.dp)
          .clip(RoundedCornerShape(14.dp))
          .clickable { onStoryClick(story) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Box(modifier = Modifier.fillMaxSize()) {
          Image(
            painter = painterResource(id = story.mediaDrawableRes),
            contentDescription = story.user.displayName,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )

          // Gradient scrim
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                )
              )
          )

          // Avatar / Add button
          if (story.isUserStory) {
            Surface(
              shape = CircleShape,
              color = RxBlue,
              modifier = Modifier
                .padding(8.dp)
                .size(34.dp)
                .align(Alignment.TopStart)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Add, contentDescription = "Add Story", tint = Color.White, modifier = Modifier.size(20.dp))
              }
            }
          } else {
            Box(
              modifier = Modifier
                .padding(8.dp)
                .size(36.dp)
                .align(Alignment.TopStart)
                .clip(CircleShape)
                .border(
                  width = 2.dp,
                  brush = Brush.linearGradient(listOf(RxBlue, RxCyan)),
                  shape = CircleShape
                )
            ) {
              Image(
                painter = painterResource(id = story.user.avatarDrawableRes),
                contentDescription = story.user.displayName,
                modifier = Modifier
                  .fillMaxSize()
                  .padding(2.dp)
                  .clip(CircleShape),
                contentScale = ContentScale.Crop
              )
            }
          }

          // Author label
          Text(
            text = if (story.isUserStory) "Create Story" else story.user.displayName,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            maxLines = 2,
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(8.dp)
          )
        }
      }
    }
  }
}

@Composable
fun StoriesAndReelsSection(
  stories: List<SocialStory>,
  reels: List<com.example.model.RxReel>,
  onStoryClick: (SocialStory) -> Unit,
  onReelClick: (Int) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { androidx.compose.runtime.mutableIntStateOf(0) }

  Column(modifier = modifier.fillMaxWidth()) {
    // Header Segmented Tabs
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (selectedTab == 0) ElectricRoyalBlue else SlateGreyAction,
        modifier = Modifier
          .clickable { selectedTab = 0 }
          .testTag("tab_stories_header")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Stories",
            color = if (selectedTab == 0) Color.White else MidnightBlueText,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (selectedTab == 1) ElectricRoyalBlue else SlateGreyAction,
        modifier = Modifier
          .clickable { selectedTab = 1 }
          .testTag("tab_reels_header")
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = null,
            tint = if (selectedTab == 1) Color.White else Color(0xFFEF4444),
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Reels",
            color = if (selectedTab == 1) Color.White else MidnightBlueText,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
          )
        }
      }
    }

    if (selectedTab == 0) {
      StoriesTray(
        stories = stories,
        onStoryClick = onStoryClick
      )
    } else {
      LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(reels.size) { index ->
          val reel = reels[index]
          Card(
            modifier = Modifier
              .width(115.dp)
              .height(175.dp)
              .clip(RoundedCornerShape(14.dp))
              .clickable { onReelClick(index) }
              .testTag("reel_preview_card_$index"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black)
          ) {
            Box(modifier = Modifier.fillMaxSize()) {
              if (reel.posterDrawableRes != null) {
                Image(
                  painter = painterResource(id = reel.posterDrawableRes),
                  contentDescription = reel.caption,
                  modifier = Modifier.fillMaxSize(),
                  contentScale = ContentScale.Crop
                )
              } else {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
                )
              }

              // Gradient Scrim
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                      colors = listOf(
                        Color.Black.copy(alpha = 0.3f),
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.8f)
                      )
                    )
                  )
              )

              // Center Play button
              Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.5f),
                modifier = Modifier
                  .size(32.dp)
                  .align(Alignment.Center)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Play Reel",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                  )
                }
              }

              // Top Tag
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color.Black.copy(alpha = 0.6f),
                modifier = Modifier
                  .padding(6.dp)
                  .align(Alignment.TopStart)
              ) {
                Text(
                  text = "Reel",
                  color = Color.White,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
              }

              // Bottom Author & Metric
              Column(
                modifier = Modifier
                  .align(Alignment.BottomStart)
                  .padding(8.dp)
              ) {
                Text(
                  text = reel.author.displayName,
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  maxLines = 1,
                  overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                  text = "▶ ${reel.likes}",
                  color = Color.White.copy(alpha = 0.85f),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun SocialPostCard(
  post: SocialPost,
  onReactionSelected: (ReactionType) -> Unit,
  onCommentClick: () -> Unit,
  onShareClick: () -> Unit,
  onUserClick: (SocialUser) -> Unit,
  onSaveToggle: ((SocialPost) -> Unit)? = null,
  onReportPost: ((SocialPost) -> Unit)? = null,
  onHidePost: ((SocialPost) -> Unit)? = null,
  onCopyLink: ((SocialPost) -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  var showReactionTray by remember { mutableStateOf(false) }
  var isPlayingVideo by remember { mutableStateOf(false) }
  var videoError by remember { mutableStateOf(false) }
  var showOptionsMenu by remember { mutableStateOf(false) }

  Card(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhiteSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, RazorThinBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
  ) {
    Column(modifier = Modifier.padding(vertical = 12.dp)) {
      // Header: Author, Verified, TimeAgo, Visibility
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .clickable { onUserClick(post.author) }
        ) {
          Image(
            painter = painterResource(id = post.author.avatarDrawableRes),
            contentDescription = post.author.displayName,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
          if (post.author.isOnline) {
            Surface(
              shape = CircleShape,
              color = RxOnlineGreen,
              border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White),
              modifier = Modifier
                .size(12.dp)
                .align(Alignment.BottomEnd)
            ) {}
          }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = post.author.displayName,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              modifier = Modifier.clickable { onUserClick(post.author) }
            )
            if (post.author.isVerified) {
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Verified",
                tint = RxBlue,
                modifier = Modifier.size(15.dp)
              )
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Text(text = post.timeAgo, fontSize = 11.sp, color = RxTextSecondary)
            Text(text = "•", fontSize = 11.sp, color = RxTextSecondary)
            Icon(
              imageVector = Icons.Default.Public,
              contentDescription = "Public",
              tint = RxTextSecondary,
              modifier = Modifier.size(12.dp)
            )
          }
        }

        Box {
          IconButton(onClick = { showOptionsMenu = true }) {
            Icon(Icons.Default.MoreHoriz, contentDescription = "More Options", tint = RxTextSecondary)
          }
          PostOptionsMenu(
            expanded = showOptionsMenu,
            onDismiss = { showOptionsMenu = false },
            isSaved = post.isSaved,
            onToggleSave = { onSaveToggle?.invoke(post) },
            onHidePost = { onHidePost?.invoke(post) },
            onReportPost = { onReportPost?.invoke(post) },
            onCopyLink = { onCopyLink?.invoke(post) }
          )
        }
      }

      // Content text
      if (post.content.isNotBlank()) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = post.content,
          style = MaterialTheme.typography.bodyMedium.copy(
            color = RxTextPrimary,
            lineHeight = 20.sp
          ),
          modifier = Modifier.padding(horizontal = 14.dp)
        )
      }

      // Media Asset: Video (Veo 3 AI Video / HLS Stream) or Photo
      if (post.videoUrl != null) {
        Spacer(modifier = Modifier.height(10.dp))
        val rawRatio = if (post.videoAspectRatio == "9:16") (9f / 16f) else (16f / 9f)
        val clampedRatio = rawRatio.coerceIn(0.5f, 2.2f) // 🛡️ Zero CLS Guard (.clamp(0.5, 2.2))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .aspectRatio(clampedRatio)
            .background(Color(0xFF0F172A)), // Midnight Blue texture backdrop
          contentAlignment = Alignment.Center
        ) {
          if (isPlayingVideo && !videoError) {
            val context = androidx.compose.ui.platform.LocalContext.current
            var exoPlayer by remember { mutableStateOf<androidx.media3.exoplayer.ExoPlayer?>(null) }
            var isBuffering by remember { mutableStateOf(true) }

            androidx.compose.runtime.DisposableEffect(post.videoUrl) {
              val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)
                .setUserAgent("RxBookPostPlayer/1.0")

              val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context)
                .setDataSourceFactory(httpDataSourceFactory)

              val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context)
                .setEnableDecoderFallback(true)

              val player = androidx.media3.exoplayer.ExoPlayer.Builder(context, renderersFactory)
                .setMediaSourceFactory(mediaSourceFactory)
                .build().apply {
                  repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                  playWhenReady = true
                  setMediaItem(androidx.media3.common.MediaItem.fromUri(post.videoUrl))
                  addListener(object : androidx.media3.common.Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                      isBuffering = (playbackState == androidx.media3.common.Player.STATE_BUFFERING)
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                      android.util.Log.e("SocialPostCard", "Handled video playback error: ${error.errorCodeName}")
                      if (post.videoUrl != com.example.VideoAdapter.FALLBACK_VIDEO_URL) {
                        setMediaItem(androidx.media3.common.MediaItem.fromUri(com.example.VideoAdapter.FALLBACK_VIDEO_URL))
                        prepare()
                        playWhenReady = true
                      } else {
                        videoError = true
                        isPlayingVideo = false
                      }
                    }
                  })
                  prepare()
                }
              exoPlayer = player

              onDispose {
                exoPlayer?.stop()
                exoPlayer?.clearMediaItems()
                exoPlayer?.release()
                exoPlayer = null
              }
            }

            AndroidView(
              factory = { ctx ->
                val view = android.view.LayoutInflater.from(ctx).inflate(com.example.R.layout.item_video_player, null, false)
                val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.playerView)
                playerView.player = exoPlayer
                view
              },
              update = { view ->
                val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.playerView)
                playerView.player = exoPlayer
                val pBar = view.findViewById<android.view.View>(com.example.R.id.videoProgressBar)
                pBar?.visibility = if (isBuffering) android.view.View.VISIBLE else android.view.View.GONE
              },
              onRelease = { view ->
                val playerView = view.findViewById<androidx.media3.ui.PlayerView>(com.example.R.id.playerView)
                playerView.player = null
              },
              modifier = Modifier
                .fillMaxSize()
                .clickable { isPlayingVideo = false }
            )
          } else {
            // Poster thumbnail image or fallback dark container
            if (post.mediaDrawableRes != null) {
              Image(
                painter = painterResource(id = post.mediaDrawableRes),
                contentDescription = "Video Poster",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(Color.Black.copy(alpha = 0.3f))
              )
            }

            // Interactive Play Button
            Surface(
              shape = CircleShape,
              color = Color.Black.copy(alpha = 0.7f),
              modifier = Modifier
                .size(54.dp)
                .clickable {
                  videoError = false
                  isPlayingVideo = true
                }
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.PlayArrow,
                  contentDescription = "Play Video",
                  tint = Color.White,
                  modifier = Modifier.size(32.dp)
                )
              }
            }
          }

          // Video Streaming Indicator Badge
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color.Black.copy(alpha = 0.75f),
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(10.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = RxCyan,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (post.isAiGenerated) "Veo 3.1 • ${post.videoAspectRatio}" else "60fps Stream",
                fontSize = 11.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      } else if (post.multiImages.isNotEmpty()) {
        Spacer(modifier = Modifier.height(10.dp))
        MultiImageCarousel(images = post.multiImages)
      } else if (post.mediaDrawableRes != null) {
        Spacer(modifier = Modifier.height(10.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(Color.Black)
        ) {
          Image(
            painter = painterResource(id = post.mediaDrawableRes),
            contentDescription = "Post Media",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
        }
      } else if (post.linkPreview != null) {
        Spacer(modifier = Modifier.height(10.dp))
        LinkPreviewCard(
          preview = post.linkPreview,
          onClick = {},
          modifier = Modifier.padding(horizontal = 14.dp)
        )
      }

      // Reaction Stats Row
      Spacer(modifier = Modifier.height(10.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        val totalReactions = post.reactionCounts.values.sum()
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(shape = CircleShape, color = RxBlue, modifier = Modifier.size(18.dp)) {
            Box(contentAlignment = Alignment.Center) {
              Text("👍", fontSize = 10.sp)
            }
          }
          Surface(shape = CircleShape, color = ReactionLove, modifier = Modifier.size(18.dp)) {
            Box(contentAlignment = Alignment.Center) {
              Text("❤️", fontSize = 10.sp)
            }
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "$totalReactions",
            fontSize = 12.sp,
            color = RxTextSecondary
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(text = "${post.commentsCount} comments", fontSize = 12.sp, color = RxTextSecondary)
          Text(text = "•", fontSize = 12.sp, color = RxTextSecondary)
          Text(text = "${post.sharesCount} shares", fontSize = 12.sp, color = RxTextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Divider(color = RxBorder, thickness = 0.8.dp, modifier = Modifier.padding(horizontal = 14.dp))
      Spacer(modifier = Modifier.height(4.dp))

      // Reaction and Action Buttons Section
      Column(modifier = Modifier.fillMaxWidth()) {
        if (showReactionTray) {
          Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, RxBorder),
            modifier = Modifier.padding(start = 14.dp, bottom = 8.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              ReactionType.values().forEach { reaction ->
                Text(
                  text = reaction.emoji,
                  fontSize = 22.sp,
                  modifier = Modifier
                    .clip(CircleShape)
                    .clickable {
                      onReactionSelected(reaction)
                      showReactionTray = false
                    }
                    .padding(2.dp)
                )
              }
            }
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          // Like button
          Row(
            modifier = Modifier
              .pointerInput(Unit) {
                detectTapGestures(
                  onTap = {
                    onReactionSelected(ReactionType.LIKE)
                  },
                  onLongPress = {
                    showReactionTray = !showReactionTray
                  }
                )
              }
              .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            if (post.userReaction != null) {
              Text(post.userReaction.emoji, fontSize = 16.sp)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = post.userReaction.label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = when (post.userReaction) {
                  ReactionType.LIKE -> ReactionLike
                  ReactionType.LOVE -> ReactionLove
                  ReactionType.HAHA, ReactionType.WOW -> ReactionHaha
                  ReactionType.SAD -> ReactionSad
                  ReactionType.ANGRY -> ReactionAngry
                }
              )
            } else {
              Icon(
                imageVector = Icons.Default.ThumbUpOffAlt,
                contentDescription = "Like",
                tint = RxTextSecondary,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("Like", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
            }
          }

          // Comment
          Row(
            modifier = Modifier
              .clickable(onClick = onCommentClick)
              .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.ChatBubbleOutline,
              contentDescription = "Comment",
              tint = RxTextSecondary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Comment", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
          }

          // Share
          Row(
            modifier = Modifier
              .clickable(onClick = onShareClick)
              .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Share,
              contentDescription = "Share",
              tint = RxTextSecondary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Share", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostModal(
  currentUser: SocialUser,
  onDismiss: () -> Unit,
  onPostCreated: (content: String, hasPhoto: Boolean) -> Unit,
  onOpenVeoVideo: () -> Unit = {}
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var postText by remember { mutableStateOf("") }
  var attachPhoto by remember { mutableStateOf(true) }
  var visibility by remember { mutableStateOf("PUBLIC") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
        Text("Create Post", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Button(
          onClick = {
            if (postText.isNotBlank() || attachPhoto) {
              onPostCreated(postText, attachPhoto)
              onDismiss()
            }
          },
          enabled = postText.isNotBlank() || attachPhoto,
          colors = ButtonDefaults.buttonColors(containerColor = RxBlue),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("Post", fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
          painter = painterResource(id = currentUser.avatarDrawableRes),
          contentDescription = currentUser.displayName,
          modifier = Modifier
            .size(44.dp)
            .clip(CircleShape),
          contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(text = currentUser.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
              selected = visibility == "PUBLIC",
              onClick = { visibility = if (visibility == "PUBLIC") "FRIENDS" else "PUBLIC" },
              label = { Text(if (visibility == "PUBLIC") "Public" else "Friends", fontSize = 11.sp) },
              leadingIcon = {
                Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(12.dp))
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      OutlinedTextField(
        value = postText,
        onValueChange = { postText = it },
        placeholder = { Text("What's on your mind? Share your thoughts with RX BOOK...") },
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
          .testTag("input_create_post"),
        shape = RoundedCornerShape(12.dp)
      )

      Spacer(modifier = Modifier.height(12.dp))

      if (attachPhoto) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black)
        ) {
          Image(
            painter = painterResource(id = R.drawable.rx_feed_post_tech_1789358410043),
            contentDescription = "Attached photo preview",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
          )
          IconButton(
            onClick = { attachPhoto = false },
            modifier = Modifier
              .align(Alignment.TopEnd)
              .padding(6.dp)
              .background(Color.Black.copy(alpha = 0.6f), CircleShape)
          ) {
            Icon(Icons.Default.Close, contentDescription = "Remove photo", tint = Color.White)
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
      }

      Surface(
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, RxBorder),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Add to your post", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            IconButton(onClick = { attachPhoto = !attachPhoto }) {
              Icon(Icons.Default.Image, contentDescription = "Photo", tint = Color(0xFF45BD62))
            }
            IconButton(onClick = {
              onDismiss()
              onOpenVeoVideo()
            }) {
              Icon(Icons.Default.AutoAwesome, contentDescription = "Veo 3 AI Video", tint = RxBlue)
            }
            IconButton(onClick = {}) {
              Icon(Icons.Default.Videocam, contentDescription = "Video", tint = Color(0xFFF3425F))
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsModal(
  post: SocialPost,
  comments: List<SocialComment>,
  currentUser: SocialUser,
  onDismiss: () -> Unit,
  onAddComment: (text: String) -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var commentText by remember { mutableStateOf("") }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
    ) {
      Text(
        text = "Comments (${comments.size})",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.padding(vertical = 10.dp)
      )

      Divider(color = RxBorder)

      LazyColumn(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f, fill = false)
          .height(340.dp)
          .padding(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(comments) { comment ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
          ) {
            Image(
              painter = painterResource(id = comment.author.avatarDrawableRes),
              contentDescription = comment.author.displayName,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape),
              contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
              Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
              ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                  Text(text = comment.author.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(text = comment.content, fontSize = 13.sp, color = RxTextPrimary)
                }
              }

              Row(
                modifier = Modifier.padding(start = 6.dp, top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
              ) {
                Text(text = comment.timeAgo, fontSize = 11.sp, color = RxTextSecondary)
                Text(text = "Like (${comment.likesCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (comment.isLiked) RxBlue else RxTextSecondary)
                Text(text = "Reply", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = RxTextSecondary)
              }
            }
          }
        }
      }

      Divider(color = RxBorder)

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Image(
          painter = painterResource(id = currentUser.avatarDrawableRes),
          contentDescription = currentUser.displayName,
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape),
          contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.width(8.dp))

        OutlinedTextField(
          value = commentText,
          onValueChange = { commentText = it },
          placeholder = { Text("Write a comment...", fontSize = 13.sp) },
          modifier = Modifier
            .weight(1f)
            .height(50.dp)
            .testTag("input_add_comment"),
          shape = RoundedCornerShape(25.dp),
          colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = RxBorder,
            focusedBorderColor = RxBlue
          )
        )

        Spacer(modifier = Modifier.width(8.dp))

        IconButton(
          onClick = {
            if (commentText.isNotBlank()) {
              onAddComment(commentText)
              commentText = ""
            }
          },
          enabled = commentText.isNotBlank()
        ) {
          Icon(Icons.Default.Send, contentDescription = "Send", tint = if (commentText.isNotBlank()) RxBlue else RxTextMuted)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
fun CreateStoryDialog(
  currentUser: SocialUser,
  onDismiss: () -> Unit,
  onStoryPublished: (SocialStory) -> Unit
) {
  androidx.compose.material3.AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Upload New Story", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Share a 24-hour visual story with your followers and friends.", fontSize = 13.sp, color = RxTextSecondary)
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(com.example.ui.theme.RxBlueLight),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Add, contentDescription = null, tint = RxBlue, modifier = Modifier.size(42.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Tap to pick photo / cinematic media", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = RxBlue)
          }
        }
      }
    },
    confirmButton = {
      androidx.compose.material3.Button(
        onClick = {
          val newStory = SocialStory(
            id = "story_${System.currentTimeMillis()}",
            user = currentUser,
            mediaDrawableRes = R.drawable.rx_feed_post_travel_1789358396512,
            isUserStory = false,
            hasUnseen = false
          )
          onStoryPublished(newStory)
        },
        colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = RxBlue)
      ) {
        Text("Publish Story")
      }
    },
    dismissButton = {
      androidx.compose.material3.TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

@Composable
fun StoryViewerDialog(
  story: SocialStory,
  onDismiss: () -> Unit
) {
  androidx.compose.ui.window.Dialog(
    onDismissRequest = onDismiss,
    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
    ) {
      Image(
        painter = painterResource(id = story.mediaDrawableRes),
        contentDescription = null,
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .statusBarsPadding()
          .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape)
              .border(2.dp, RxBlue, CircleShape)
          ) {
            Image(
              painter = painterResource(id = story.user.avatarDrawableRes),
              contentDescription = null,
              modifier = Modifier
                .fillMaxSize()
                .padding(2.dp)
                .clip(CircleShape),
              contentScale = ContentScale.Crop
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(story.user.displayName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Active Story", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
          }
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
        }
      }
    }
  }
}
