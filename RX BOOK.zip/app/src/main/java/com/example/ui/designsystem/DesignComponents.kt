package com.example.ui.designsystem

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R

enum class RxButtonVariant {
    PRIMARY,
    SECONDARY,
    OUTLINED,
    GHOST,
    DESTRUCTIVE
}

@Composable
fun RxButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: RxButtonVariant = RxButtonVariant.PRIMARY,
    icon: ImageVector? = null,
    isLoading: Boolean = false,
    enabled: Boolean = true,
    testTag: String = "rx_button"
) {
    val shape = RoundedCornerShape(DesignTokens.CornerRadius.md)

    when (variant) {
        RxButtonVariant.PRIMARY -> {
            Button(
                onClick = onClick,
                modifier = modifier.testTag(testTag),
                enabled = enabled && !isLoading,
                shape = shape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                RxButtonContent(text, icon, isLoading, MaterialTheme.colorScheme.onPrimary)
            }
        }
        RxButtonVariant.SECONDARY -> {
            Button(
                onClick = onClick,
                modifier = modifier.testTag(testTag),
                enabled = enabled && !isLoading,
                shape = shape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                RxButtonContent(text, icon, isLoading, MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        RxButtonVariant.OUTLINED -> {
            OutlinedButton(
                onClick = onClick,
                modifier = modifier.testTag(testTag),
                enabled = enabled && !isLoading,
                shape = shape,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                RxButtonContent(text, icon, isLoading, MaterialTheme.colorScheme.primary)
            }
        }
        RxButtonVariant.GHOST -> {
            Surface(
                onClick = onClick,
                modifier = modifier.clip(shape).testTag(testTag),
                enabled = enabled && !isLoading,
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    RxButtonContent(text, icon, isLoading, MaterialTheme.colorScheme.primary)
                }
            }
        }
        RxButtonVariant.DESTRUCTIVE -> {
            Button(
                onClick = onClick,
                modifier = modifier.testTag(testTag),
                enabled = enabled && !isLoading,
                shape = shape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                )
            ) {
                RxButtonContent(text, icon, isLoading, MaterialTheme.colorScheme.onError)
            }
        }
    }
}

@Composable
private fun RxButtonContent(
    text: String,
    icon: ImageVector?,
    isLoading: Boolean,
    tint: Color
) {
    if (isLoading) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = tint
        )
        Spacer(modifier = Modifier.width(8.dp))
    } else if (icon != null) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
    }
    Text(
        text = text,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp
    )
}

@Composable
fun RxCard(
    modifier: Modifier = Modifier,
    elevation: Dp = DesignTokens.Elevation.low,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val cardColors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface
    )
    val cardBorder = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
    val shape = RoundedCornerShape(DesignTokens.CornerRadius.lg)

    if (onClick != null) {
        Card(
            onClick = onClick,
            modifier = modifier,
            shape = shape,
            colors = cardColors,
            border = cardBorder,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation)
        ) {
            content()
        }
    } else {
        Card(
            modifier = modifier,
            shape = shape,
            colors = cardColors,
            border = cardBorder,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation)
        ) {
            content()
        }
    }
}

@Composable
fun RxAvatar(
    imageUrl: String?,
    drawableRes: Int = 0,
    displayName: String = "User",
    size: Dp = 44.dp,
    isOnline: Boolean = false,
    isVerified: Boolean = false,
    hasStoryRing: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val baseModifier = modifier
        .size(size)
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)

    Box(modifier = baseModifier) {
        // Story Ring if active
        val avatarModifier = if (hasStoryRing) {
            Modifier
                .size(size)
                .border(2.5.dp, DesignTokens.Colors.StoryRingGradient, CircleShape)
                .padding(3.dp)
                .clip(CircleShape)
        } else {
            Modifier
                .size(size)
                .clip(CircleShape)
        }

        if (!imageUrl.isNullOrEmpty()) {
            AsyncImage(
                model = imageUrl,
                contentDescription = displayName,
                modifier = avatarModifier,
                contentScale = ContentScale.Crop
            )
        } else {
            Image(
                painter = painterResource(id = if (drawableRes != 0) drawableRes else R.drawable.rx_book_app_icon_1789358378841),
                contentDescription = displayName,
                modifier = avatarModifier,
                contentScale = ContentScale.Crop
            )
        }

        // Online Indicator
        if (isOnline) {
            Surface(
                shape = CircleShape,
                color = DesignTokens.Colors.Success,
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .size(size * 0.28f)
                    .align(Alignment.BottomEnd)
            ) {}
        }

        // Verified Badge
        if (isVerified && !isOnline) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Verified",
                tint = DesignTokens.Colors.VerifiedBadge,
                modifier = Modifier
                    .size(size * 0.35f)
                    .align(Alignment.BottomEnd)
                    .background(MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

/**
 * Modern Shimmer Box for Loading Skeletons
 */
@Composable
fun RxShimmerBox(
    modifier: Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(DesignTokens.CornerRadius.sm)
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_anim"
    )

    val shimmerColors = listOf(
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    )

    val brush = Brush.linearGradient(
        colors = shimmerColors,
        start = Offset.Zero,
        end = Offset(x = translateAnim, y = translateAnim)
    )

    Box(modifier = modifier.clip(shape).background(brush))
}

@Composable
fun RxPostCardSkeleton(modifier: Modifier = Modifier) {
    RxCard(modifier = modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RxShimmerBox(modifier = Modifier.size(44.dp), shape = CircleShape)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    RxShimmerBox(modifier = Modifier.size(width = 120.dp, height = 14.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    RxShimmerBox(modifier = Modifier.size(width = 70.dp, height = 10.dp))
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            RxShimmerBox(modifier = Modifier.fillMaxWidth().height(16.dp))
            Spacer(modifier = Modifier.height(6.dp))
            RxShimmerBox(modifier = Modifier.fillMaxWidth(0.7f).height(16.dp))
            Spacer(modifier = Modifier.height(14.dp))
            RxShimmerBox(
                modifier = Modifier.fillMaxWidth().height(200.dp),
                shape = RoundedCornerShape(DesignTokens.CornerRadius.md)
            )
        }
    }
}

@Composable
fun RxEmptyStateView(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(DesignTokens.Spacing.xxxl),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
            modifier = Modifier.size(72.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(DesignTokens.Spacing.lg))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(DesignTokens.Spacing.xs))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionText != null && onAction != null) {
            Spacer(modifier = Modifier.height(DesignTokens.Spacing.lg))
            RxButton(
                text = actionText,
                onClick = onAction,
                variant = RxButtonVariant.PRIMARY
            )
        }
    }
}

@Composable
fun RxErrorBanner(
    errorMessage: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(DesignTokens.CornerRadius.md),
        modifier = modifier.fillMaxWidth().padding(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Connection issue",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    text = errorMessage,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                )
            }
            IconButton(onClick = onRetry) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Retry",
                    tint = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}
