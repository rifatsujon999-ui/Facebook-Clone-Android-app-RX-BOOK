package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricRoyalBlue
import com.example.ui.theme.MidnightBlueText
import com.example.ui.theme.PureWhiteSurface
import com.example.ui.theme.RazorThinBorder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RxFeedSearchableHeader(
    onSearchClick: () -> Unit,
    onNotificationClick: () -> Unit,
    userAvatarUrl: String? = null,
    modifier: Modifier = Modifier,
    userInitial: String = "U",
    onProfileClick: () -> Unit = {},
    onVideoFeedClick: (() -> Unit)? = null
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .testTag("rx_feed_searchable_header"),
        color = PureWhiteSurface,
        border = BorderStroke(1.dp, RazorThinBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // 🚀 ব্র্যান্ড লোগো টেক্সট (ইলেকট্রিক রয়্যাল ব্লু)
            Text(
                text = "rxBook",
                color = ElectricRoyalBlue,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.testTag("header_brand_logo")
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 🔍 সার্চ বার ক্যাপসুল (ক্লিক করলেই সার্চ মডাল ওপেন হবে)
                Row(
                    modifier = Modifier
                        .width(180.dp)
                        .height(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9)) // Slate Grey অ্যাকশন ব্যাকগ্রাউন্ড
                        .clickable { onSearchClick() }
                        .padding(horizontal = 12.dp)
                        .testTag("btn_search_capsule"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = MidnightBlueText.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Search...",
                        color = MidnightBlueText.copy(alpha = 0.5f),
                        fontSize = 14.sp
                    )
                }

                // 🎬 ভিডিও ফিড বাটন (Media3 Player Feed Activity)
                if (onVideoFeedClick != null) {
                    IconButton(
                        onClick = onVideoFeedClick,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(ElectricRoyalBlue.copy(alpha = 0.1f))
                            .testTag("btn_header_video_feed")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OndemandVideo,
                            contentDescription = "Video Feed",
                            tint = ElectricRoyalBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // 🔔 নোটিফিকেশন আইকন বাটন
                IconButton(
                    onClick = onNotificationClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFF1F5F9))
                        .testTag("btn_header_notification")
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsNone,
                        contentDescription = "Notifications",
                        tint = MidnightBlueText,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 🧑 ইউজার প্রোফাইল অ্যাভাটার প্লেসহোল্ডার
                Surface(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onProfileClick)
                        .testTag("header_user_avatar"),
                    color = ElectricRoyalBlue
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = userInitial.take(1).uppercase().ifEmpty { "U" },
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}
