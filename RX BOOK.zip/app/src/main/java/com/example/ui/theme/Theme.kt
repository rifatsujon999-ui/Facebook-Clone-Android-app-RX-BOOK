package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.ui.designsystem.DesignTokens

enum class ThemeMode {
  LIGHT,
  DARK,
  SYSTEM
}

val LocalThemeMode = compositionLocalOf { mutableStateOf(ThemeMode.LIGHT) }

private val DarkColorScheme =
  darkColorScheme(
    primary = DesignTokens.Colors.BrandPrimary,
    onPrimary = Color.White,
    primaryContainer = DesignTokens.Colors.BrandPrimaryDark,
    onPrimaryContainer = Color.White,
    secondary = DesignTokens.Colors.BrandSecondary,
    background = DesignTokens.Colors.DarkBackground,
    surface = DesignTokens.Colors.DarkSurface,
    surfaceVariant = DesignTokens.Colors.DarkSurfaceElevated,
    outline = DesignTokens.Colors.DarkBorder,
    onBackground = DesignTokens.Colors.DarkTextPrimary,
    onSurface = DesignTokens.Colors.DarkTextPrimary,
    onSurfaceVariant = DesignTokens.Colors.DarkTextSecondary
  )

private val LightColorScheme =
  lightColorScheme(
    primary = DesignTokens.Colors.BrandPrimary,
    onPrimary = Color.White,
    primaryContainer = DesignTokens.Colors.BrandPrimaryLight,
    onPrimaryContainer = DesignTokens.Colors.BrandPrimaryDark,
    secondary = DesignTokens.Colors.BrandSecondary,
    background = DesignTokens.Colors.LightBackground,
    surface = DesignTokens.Colors.LightSurface,
    surfaceVariant = DesignTokens.Colors.LightSurfaceElevated,
    outline = DesignTokens.Colors.LightBorder,
    onBackground = DesignTokens.Colors.LightTextPrimary,
    onSurface = DesignTokens.Colors.LightTextPrimary,
    onSurfaceVariant = DesignTokens.Colors.LightTextSecondary
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as Activity).window
      window.statusBarColor = colorScheme.surface.toArgb()
      WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
    }
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun RxBookTheme(
  darkTheme: Boolean = false,
  content: @Composable () -> Unit
) {
  MyApplicationTheme(darkTheme = darkTheme, content = content)
}


