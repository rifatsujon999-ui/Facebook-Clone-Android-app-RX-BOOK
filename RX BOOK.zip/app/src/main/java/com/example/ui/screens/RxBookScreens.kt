package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ChatConversation
import com.example.model.ChatMessage
import com.example.model.NotificationItem
import com.example.model.ReactionType
import com.example.model.RxReel
import com.example.model.SocialPost
import com.example.model.SocialStory
import com.example.model.SocialUser
import com.example.ui.components.CreatePostEntryCard
import com.example.ui.components.FeedRecommendedReelsSection
import com.example.ui.components.SocialPostCard
import com.example.ui.components.StoriesAndReelsSection
import com.example.ui.components.StoriesTray
import com.example.ui.components.SuggestedUsersSection
import com.example.ui.theme.ElectricRoyalBlue
import com.example.ui.theme.MidnightBlueText
import com.example.ui.theme.PureWhiteSurface
import com.example.ui.theme.RazorThinBorder
import com.example.ui.theme.RxBlue
import com.example.ui.theme.RxBlueLight
import com.example.ui.theme.RxBorder
import com.example.ui.theme.RxOnlineGreen
import com.example.ui.theme.RxTextMuted
import com.example.ui.theme.RxTextPrimary
import com.example.ui.theme.RxTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewsFeedScreen(
  currentUser: SocialUser,
  stories: List<SocialStory>,
  posts: List<SocialPost>,
  reels: List<RxReel> = emptyList(),
  suggestedUsers: List<SocialUser> = emptyList(),
  searchQuery: String = "",
  selectedCategory: String = "All",
  isRefreshing: Boolean = false,
  onRefresh: () -> Unit = {},
  onClearSearch: () -> Unit = {},
  onOpenCreatePost: () -> Unit,
  onOpenVeoVideo: () -> Unit = {},
  onOpenReels: () -> Unit = {},
  onReelClick: (Int) -> Unit = {},
  onStoryClick: (SocialStory) -> Unit = {},
  onReactionSelected: (postId: String, reaction: ReactionType) -> Unit,
  onCommentClick: (SocialPost) -> Unit,
  onShareClick: (SocialPost) -> Unit,
  onUserClick: (SocialUser) -> Unit,
  onFollowClick: (SocialUser) -> Unit = {},
  onSaveToggle: (SocialPost) -> Unit = {},
  onHidePost: (SocialPost) -> Unit = {},
  onReportPost: (SocialPost) -> Unit = {},
  onCopyLink: (SocialPost) -> Unit = {},
  modifier: Modifier = Modifier
) {
  val isFiltering = searchQuery.isNotBlank() || selectedCategory != "All"

  val filteredPosts = remember(posts, searchQuery, selectedCategory) {
    posts.filter { post ->
      val matchesQuery = if (searchQuery.isBlank()) true else {
        post.author.displayName.contains(searchQuery, ignoreCase = true) ||
          post.author.username.contains(searchQuery, ignoreCase = true) ||
          post.content.contains(searchQuery, ignoreCase = true)
      }
      val matchesCategory = when (selectedCategory) {
        "📷 Photos" -> post.mediaDrawableRes != null && post.videoUrl == null
        "💻 Tech & AI" -> post.isAiGenerated ||
          post.content.contains("AI", ignoreCase = true) ||
          post.content.contains("Kotlin", ignoreCase = true) ||
          post.content.contains("Compose", ignoreCase = true) ||
          post.content.contains("tech", ignoreCase = true)
        "🔥 Trending" -> post.reactionCounts.values.sum() > 20 || post.commentsCount > 5
        "🎬 Reels" -> post.videoUrl != null
        "💬 Discussions" -> post.commentsCount > 3 || post.content.contains("?")
        else -> true
      }
      matchesQuery && matchesCategory
    }
  }

  val pullRefreshState = rememberPullToRefreshState()

  PullToRefreshBox(
    isRefreshing = isRefreshing,
    onRefresh = onRefresh,
    state = pullRefreshState,
    modifier = modifier
      .fillMaxSize()
      .testTag("feed_pull_to_refresh"),
    indicator = {
      PullToRefreshDefaults.Indicator(
        state = pullRefreshState,
        isRefreshing = isRefreshing,
        modifier = Modifier.align(Alignment.TopCenter),
        containerColor = Color.White,
        color = RxBlue
      )
    }
  ) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 90.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
    if (isFiltering) {
      // Search / Filter Active Results Banner
      item {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = RxBlueLight,
          border = BorderStroke(1.dp, ElectricRoyalBlue.copy(alpha = 0.25f)),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("feed_search_results_banner")
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
            ) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = ElectricRoyalBlue,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = buildString {
                  append("Found ${filteredPosts.size} post${if (filteredPosts.size == 1) "" else "s"}")
                  if (searchQuery.isNotBlank()) append(" for \"$searchQuery\"")
                  if (selectedCategory != "All") append(" in $selectedCategory")
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MidnightBlueText
              )
            }

            Text(
              text = "Clear",
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              color = ElectricRoyalBlue,
              modifier = Modifier
                .clickable(onClick = onClearSearch)
                .padding(horizontal = 8.dp, vertical = 4.dp)
                .testTag("btn_banner_clear_search")
            )
          }
        }
      }
    } else {
      item {
        CreatePostEntryCard(
          currentUser = currentUser,
          onOpenCreatePost = onOpenCreatePost,
          onOpenVeoVideo = onOpenVeoVideo,
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
      }

      item {
        StoriesAndReelsSection(
          stories = stories,
          reels = reels,
          onStoryClick = onStoryClick,
          onReelClick = onReelClick,
          modifier = Modifier.padding(vertical = 4.dp)
        )
      }
    }

    if (filteredPosts.isEmpty()) {
      item {
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = PureWhiteSurface,
          border = BorderStroke(1.dp, RazorThinBorder),
          shadowElevation = 0.5.dp,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 18.dp)
            .testTag("feed_empty_search_state")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Surface(
              shape = CircleShape,
              color = RxBlueLight,
              modifier = Modifier.size(68.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Search,
                  contentDescription = null,
                  tint = ElectricRoyalBlue,
                  modifier = Modifier.size(32.dp)
                )
              }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
              text = "No matching posts found",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = MidnightBlueText
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "We couldn't find any posts matching your search query. Try different keywords or clear the category filters.",
              fontSize = 13.sp,
              color = RxTextSecondary,
              textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(18.dp))
            Button(
              onClick = onClearSearch,
              colors = ButtonDefaults.buttonColors(containerColor = ElectricRoyalBlue),
              shape = RoundedCornerShape(20.dp),
              modifier = Modifier.testTag("btn_reset_feed_search")
            ) {
              Text("Reset Search", fontWeight = FontWeight.Bold, color = Color.White)
            }
          }
        }
      }
    } else {
      itemsIndexed(filteredPosts, key = { _, post -> post.id }) { index, post ->
        SocialPostCard(
          post = post,
          onReactionSelected = { reaction -> onReactionSelected(post.id, reaction) },
          onCommentClick = { onCommentClick(post) },
          onShareClick = { onShareClick(post) },
          onUserClick = onUserClick,
          onSaveToggle = onSaveToggle,
          onHidePost = onHidePost,
          onReportPost = onReportPost,
          onCopyLink = onCopyLink,
          modifier = Modifier.padding(horizontal = 14.dp)
        )

        // Recommended Reels Carousel after the first post
        if (index == 0 && reels.isNotEmpty() && !isFiltering) {
          FeedRecommendedReelsSection(
            reels = reels,
            onReelClick = onReelClick,
            modifier = Modifier.padding(vertical = 6.dp)
          )
        }

        // Suggested Users Carousel after the second post
        if (index == 1 && suggestedUsers.isNotEmpty() && !isFiltering) {
          SuggestedUsersSection(
            users = suggestedUsers,
            onFollowClick = onFollowClick,
            onUserClick = onUserClick,
            modifier = Modifier.padding(vertical = 6.dp)
          )
        }
      }
    }
  }
}
}


@Composable
fun MessengerScreen(
  currentUser: SocialUser,
  conversations: List<ChatConversation>,
  activeMessages: Map<String, List<ChatMessage>>,
  onSendMessage: (conversationId: String, text: String) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedConversation by remember { mutableStateOf<ChatConversation?>(null) }

  if (selectedConversation == null) {
    LazyColumn(
      modifier = modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 90.dp)
    ) {
      item {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Chats",
            style = MaterialTheme.typography.headlineMedium.copy(
              fontWeight = FontWeight.Bold,
              color = RxTextPrimary
            )
          )
          Spacer(modifier = Modifier.height(12.dp))

          Text(text = "Online Now", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = RxTextSecondary)
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(conversations) { conv ->
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { selectedConversation = conv }
              ) {
                Box {
                  Image(
                    painter = painterResource(id = conv.partner.avatarDrawableRes),
                    contentDescription = conv.partner.displayName,
                    modifier = Modifier
                      .size(52.dp)
                      .clip(CircleShape),
                    contentScale = ContentScale.Crop
                  )
                  Surface(
                    shape = CircleShape,
                    color = RxOnlineGreen,
                    border = androidx.compose.foundation.BorderStroke(2.dp, Color.White),
                    modifier = Modifier
                      .size(14.dp)
                      .align(Alignment.BottomEnd)
                  ) {}
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = conv.partner.displayName.split(" ")[0],
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Medium,
                  color = RxTextPrimary
                )
              }
            }
          }
        }
        Divider(color = RxBorder)
      }

      items(conversations) { conv ->
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { selectedConversation = conv }
            .padding(horizontal = 16.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box {
            Image(
              painter = painterResource(id = conv.partner.avatarDrawableRes),
              contentDescription = conv.partner.displayName,
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape),
              contentScale = ContentScale.Crop
            )
            if (conv.partner.isOnline) {
              Surface(
                shape = CircleShape,
                color = RxOnlineGreen,
                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White),
                modifier = Modifier
                  .size(14.dp)
                  .align(Alignment.BottomEnd)
              ) {}
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = conv.partner.displayName,
              fontWeight = if (conv.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
              fontSize = 15.sp,
              color = RxTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            if (conv.isTyping) {
              Text(
                text = "Typing...",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = RxBlue
              )
            } else {
              Text(
                text = conv.lastMessage,
                fontSize = 13.sp,
                fontWeight = if (conv.unreadCount > 0) FontWeight.Bold else FontWeight.Normal,
                color = if (conv.unreadCount > 0) RxTextPrimary else RxTextSecondary,
                maxLines = 1
              )
            }
          }

          Column(horizontalAlignment = Alignment.End) {
            Text(
              text = conv.lastMessageTime,
              fontSize = 11.sp,
              color = if (conv.unreadCount > 0) RxBlue else RxTextSecondary,
              fontWeight = if (conv.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
            )
            if (conv.unreadCount > 0) {
              Spacer(modifier = Modifier.height(4.dp))
              Surface(
                shape = CircleShape,
                color = RxBlue,
                modifier = Modifier.size(20.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text(
                    text = "${conv.unreadCount}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
          }
        }
      }
    }
  } else {
    val conv = selectedConversation!!
    var messageInput by remember { mutableStateOf("") }
    val messages = activeMessages[conv.id] ?: emptyList()

    Column(modifier = modifier.fillMaxSize()) {
      Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = { selectedConversation = null }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
          Image(
            painter = painterResource(id = conv.partner.avatarDrawableRes),
            contentDescription = conv.partner.displayName,
            modifier = Modifier
              .size(38.dp)
              .clip(CircleShape),
            contentScale = ContentScale.Crop
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(text = conv.partner.displayName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
              text = if (conv.partner.isOnline) "Active now" else "Offline",
              fontSize = 11.sp,
              color = if (conv.partner.isOnline) RxOnlineGreen else RxTextSecondary
            )
          }
          IconButton(onClick = {
            com.example.webrtc.RxNestJsSignalingManager.initiateCall(
              peerId = conv.partner.id,
              peerName = conv.partner.displayName,
              peerAvatarRes = conv.partner.avatarDrawableRes,
              callType = com.example.webrtc.CallType.AUDIO
            )
          }) {
            Icon(Icons.Default.Call, contentDescription = "Call", tint = RxBlue)
          }
          IconButton(onClick = {
            com.example.webrtc.RxNestJsSignalingManager.initiateCall(
              peerId = conv.partner.id,
              peerName = conv.partner.displayName,
              peerAvatarRes = conv.partner.avatarDrawableRes,
              callType = com.example.webrtc.CallType.VIDEO
            )
          }) {
            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = RxBlue)
          }
        }
      }

      LazyColumn(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(messages) { msg ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (msg.isFromMe) Arrangement.End else Arrangement.Start
          ) {
            Surface(
              shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (msg.isFromMe) 16.dp else 4.dp,
                bottomEnd = if (msg.isFromMe) 4.dp else 16.dp
              ),
              color = if (msg.isFromMe) RxBlue else MaterialTheme.colorScheme.surfaceVariant,
              modifier = Modifier.widthIn(max = 280.dp)
            ) {
              Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                  text = msg.text,
                  color = if (msg.isFromMe) Color.White else RxTextPrimary,
                  fontSize = 14.sp
                )
                Text(
                  text = msg.timestamp,
                  color = if (msg.isFromMe) Color.White.copy(alpha = 0.7f) else RxTextSecondary,
                  fontSize = 10.sp,
                  modifier = Modifier.align(Alignment.End)
                )
              }
            }
          }
        }
      }

      Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
          .fillMaxWidth()
          .padding(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = messageInput,
            onValueChange = { messageInput = it },
            placeholder = { Text("Aa", fontSize = 14.sp) },
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("input_chat_message"),
            colors = OutlinedTextFieldDefaults.colors(
              unfocusedBorderColor = RxBorder,
              focusedBorderColor = RxBlue
            )
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = {
              if (messageInput.isNotBlank()) {
                onSendMessage(conv.id, messageInput)
                messageInput = ""
              }
            },
            enabled = messageInput.isNotBlank()
          ) {
            Icon(Icons.Default.Send, contentDescription = "Send", tint = if (messageInput.isNotBlank()) RxBlue else RxTextMuted)
          }
        }
      }
    }
  }
}

@Composable
fun SocialGraphScreen(
  users: List<SocialUser>,
  onAcceptRequest: (String) -> Unit,
  onAddFriend: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Text(
        text = "Friends & Network",
        style = MaterialTheme.typography.headlineMedium.copy(
          fontWeight = FontWeight.Bold,
          color = RxTextPrimary
        )
      )
      Spacer(modifier = Modifier.height(10.dp))
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = RxBlue
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("Suggestions", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Requests (1)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        )
      }
    }

    items(users) { user ->
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Image(
            painter = painterResource(id = user.avatarDrawableRes),
            contentDescription = user.displayName,
            modifier = Modifier
              .size(60.dp)
              .clip(CircleShape),
            contentScale = ContentScale.Crop
          )

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(text = user.displayName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(text = user.bio, fontSize = 11.sp, color = RxTextSecondary, maxLines = 1)
            Text(text = "${user.friendsCount} mutual friends", fontSize = 11.sp, color = RxTextMuted)

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              if (user.friendshipStatus == "PENDING") {
                Button(
                  onClick = { onAcceptRequest(user.id) },
                  colors = ButtonDefaults.buttonColors(containerColor = RxBlue),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Text("Confirm", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                  onClick = {},
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Text("Delete", fontSize = 11.sp)
                }
              } else {
                Button(
                  onClick = { onAddFriend(user.id) },
                  colors = ButtonDefaults.buttonColors(containerColor = RxBlue),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.height(34.dp)
                ) {
                  Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Add Friend", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun NotificationsScreen(
  notifications: List<NotificationItem>,
  onNotificationClick: (NotificationItem) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 90.dp)
  ) {
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Notifications",
          style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "Mark all as read",
          color = RxBlue,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.clickable {}
        )
      }
      Divider(color = RxBorder)
    }

    items(notifications) { notif ->
      Surface(
        color = if (!notif.isRead) RxBlue.copy(alpha = 0.06f) else MaterialTheme.colorScheme.surface,
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNotificationClick(notif) }
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box {
            Image(
              painter = painterResource(id = notif.actor.avatarDrawableRes),
              contentDescription = notif.actor.displayName,
              modifier = Modifier
                .size(48.dp)
                .clip(CircleShape),
              contentScale = ContentScale.Crop
            )
            Surface(
              shape = CircleShape,
              color = Color.White,
              shadowElevation = 2.dp,
              modifier = Modifier
                .size(20.dp)
                .align(Alignment.BottomEnd)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(text = notif.iconEmoji, fontSize = 10.sp)
              }
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "${notif.actor.displayName} ${notif.actionText}",
              fontSize = 13.sp,
              color = RxTextPrimary,
              lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = notif.timeAgo, fontSize = 11.sp, color = RxTextSecondary)
          }

          if (!notif.isRead) {
            Surface(
              shape = CircleShape,
              color = RxBlue,
              modifier = Modifier.size(9.dp)
            ) {}
          }
        }
      }
    }
  }
}

@Composable
fun ProfileScreen(
  currentUser: SocialUser,
  userPosts: List<SocialPost>,
  userReels: List<RxReel> = emptyList(),
  onReelClick: (Int) -> Unit = {},
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var isPostsGridView by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(bottom = 90.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
        Image(
          painter = painterResource(id = R.drawable.rx_feed_post_travel_1789358396512),
          contentDescription = "Cover Banner",
          modifier = Modifier
            .fillMaxWidth()
            .height(150.dp),
          contentScale = ContentScale.Crop
        )

        Box(
          modifier = Modifier
            .padding(start = 16.dp)
            .size(96.dp)
            .align(Alignment.BottomStart)
            .clip(CircleShape)
            .border(3.dp, Color.White, CircleShape)
        ) {
          if (!currentUser.avatarUrl.isNullOrEmpty()) {
            coil.compose.AsyncImage(
              model = currentUser.avatarUrl,
              contentDescription = currentUser.displayName,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          } else {
            Image(
              painter = painterResource(id = if (currentUser.avatarDrawableRes != 0) currentUser.avatarDrawableRes else R.drawable.rx_book_app_icon_1789358378841),
              contentDescription = currentUser.displayName,
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )
          }
        }
      }

      Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Spacer(modifier = Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = currentUser.displayName,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
          )
          if (currentUser.isVerified) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = RxBlue, modifier = Modifier.size(18.dp))
          }
        }
        Text(text = "@${currentUser.username}", fontSize = 13.sp, color = RxTextSecondary)
        if (currentUser.email.isNotEmpty()) {
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = currentUser.email, fontSize = 12.sp, color = RxTextSecondary)
        }
        if (currentUser.phone.isNotEmpty()) {
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = "📞 ${currentUser.phone}", fontSize = 12.sp, color = RxTextSecondary)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = currentUser.bio, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${currentUser.friendsCount}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text = "Friends", fontSize = 11.sp, color = RxTextSecondary)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${currentUser.followersCount}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text = "Followers", fontSize = 11.sp, color = RxTextSecondary)
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "${currentUser.followingCount}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text = "Following", fontSize = 11.sp, color = RxTextSecondary)
          }
        }

        val context = LocalContext.current

        Spacer(modifier = Modifier.height(14.dp))
        Button(
          onClick = {
            context.startActivity(android.content.Intent(context, com.example.EditProfileActivity::class.java))
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          shape = RoundedCornerShape(8.dp)
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Edit Public Profile", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold)
        }

        var currentFirebaseUser by remember { mutableStateOf(com.google.firebase.auth.FirebaseAuth.getInstance().currentUser) }

        Spacer(modifier = Modifier.height(8.dp))
        Button(
          onClick = {
            if (currentFirebaseUser != null) {
              com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
              currentFirebaseUser = null
              android.widget.Toast.makeText(context, "Signed out of Firebase", android.widget.Toast.LENGTH_SHORT).show()
            } else {
              context.startActivity(android.content.Intent(context, com.example.SignUpActivity::class.java))
            }
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (currentFirebaseUser != null) MaterialTheme.colorScheme.errorContainer else RxBlue
          ),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(
            text = if (currentFirebaseUser != null) "Sign Out (${currentFirebaseUser?.email})" else "Sign Up / Switch Account",
            color = if (currentFirebaseUser != null) MaterialTheme.colorScheme.onErrorContainer else Color.White,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    }

    item {
      Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = RxBlue
      ) {
        val tabs = listOf("Posts", "Photos", "Reels", "About")
        tabs.forEachIndexed { index, title ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
          )
        }
      }
    }

    when (selectedTab) {
      0 -> {
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${userPosts.size} Posts",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            )
            Text(
              text = if (isPostsGridView) "☰ Feed View" else "⊞ Grid View",
              color = RxBlue,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.clickable { isPostsGridView = !isPostsGridView }
            )
          }
        }

        if (isPostsGridView) {
          item {
            val chunked = userPosts.chunked(3)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              chunked.forEach { rowPosts ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  rowPosts.forEach { p ->
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                      if (p.mediaDrawableRes != null) {
                        Image(
                          painter = painterResource(id = p.mediaDrawableRes),
                          contentDescription = null,
                          modifier = Modifier.fillMaxSize(),
                          contentScale = ContentScale.Crop
                        )
                      } else {
                        Text(
                          text = p.content.take(30),
                          fontSize = 10.sp,
                          modifier = Modifier.padding(6.dp)
                        )
                      }
                    }
                  }
                  repeat(3 - rowPosts.size) {
                    Spacer(modifier = Modifier.weight(1f))
                  }
                }
              }
            }
          }
        } else {
          items(userPosts) { post ->
            SocialPostCard(
              post = post,
              onReactionSelected = {},
              onCommentClick = {},
              onShareClick = {},
              onUserClick = {},
              modifier = Modifier.padding(horizontal = 14.dp)
            )
          }
        }
      }

      1 -> {
        // Photos tab (3-column grid)
        val photoPosts = userPosts.filter { it.mediaDrawableRes != null }
        if (photoPosts.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("No photos shared yet", color = RxTextSecondary, fontSize = 13.sp)
            }
          }
        } else {
          item {
            val chunked = photoPosts.chunked(3)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              chunked.forEach { rowPosts ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                  rowPosts.forEach { p ->
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .background(Color.Black)
                    ) {
                      Image(
                        painter = painterResource(id = p.mediaDrawableRes!!),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                      )
                    }
                  }
                  repeat(3 - rowPosts.size) {
                    Spacer(modifier = Modifier.weight(1f))
                  }
                }
              }
            }
          }
        }
      }

      2 -> {
        // Reels tab (3-column vertical grid)
        if (userReels.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text("No reels created yet", color = RxTextSecondary, fontSize = 13.sp)
            }
          }
        } else {
          item {
            val chunked = userReels.chunked(3)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(horizontal = 10.dp)) {
              chunked.forEach { rowReels ->
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                  rowReels.forEach { r ->
                    val rIndex = userReels.indexOf(r)
                    Card(
                      modifier = Modifier
                        .weight(1f)
                        .aspectRatio(9f / 16f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onReelClick(rIndex) },
                      shape = RoundedCornerShape(8.dp),
                      colors = CardDefaults.cardColors(containerColor = Color.Black)
                    ) {
                      Box(modifier = Modifier.fillMaxSize()) {
                        if (r.posterDrawableRes != null) {
                          Image(
                            painter = painterResource(id = r.posterDrawableRes),
                            contentDescription = r.caption,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                          )
                        }
                        Box(
                          modifier = Modifier
                            .fillMaxSize()
                            .background(
                              androidx.compose.ui.graphics.Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                              )
                            )
                        )
                        Text(
                          text = "▶ ${r.likes}",
                          color = Color.White,
                          fontSize = 10.sp,
                          fontWeight = FontWeight.Bold,
                          modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(6.dp)
                        )
                      }
                    }
                  }
                  repeat(3 - rowReels.size) {
                    Spacer(modifier = Modifier.weight(1f))
                  }
                }
              }
            }
          }
        }
      }

      3 -> {
        // About Tab
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text("About ${currentUser.displayName}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
              Divider()
              Text("Bio: ${currentUser.bio.ifEmpty { "No bio added" }}", fontSize = 13.sp)
              Text("Email: ${currentUser.email.ifEmpty { "Not set" }}", fontSize = 13.sp)
              Text("Phone: ${currentUser.phone.ifEmpty { "Not set" }}", fontSize = 13.sp)
              Text("Username: @${currentUser.username}", fontSize = 13.sp)
              Text("Member Since: March 2024", fontSize = 13.sp)
              Text("Network Status: Verified Creator", fontSize = 13.sp, color = RxBlue, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }
}
