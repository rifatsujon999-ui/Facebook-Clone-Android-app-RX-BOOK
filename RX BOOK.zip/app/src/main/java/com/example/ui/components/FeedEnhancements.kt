package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LinkPreviewData
import com.example.model.RxReel
import com.example.model.SocialUser
import com.example.ui.designsystem.DesignTokens
import com.example.ui.designsystem.RxAvatar
import com.example.ui.designsystem.RxButton
import com.example.ui.designsystem.RxButtonVariant

/**
 * Suggested Users to Follow Horizontal Section
 */
@Composable
fun SuggestedUsersSection(
    users: List<SocialUser>,
    onFollowClick: (SocialUser) -> Unit,
    onUserClick: (SocialUser) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Suggested For You",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "See All",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(users, key = { it.id }) { user ->
                var isFollowed by remember { mutableStateOf(user.friendshipStatus == "FRIENDS") }

                Card(
                    modifier = Modifier
                        .width(140.dp)
                        .clip(RoundedCornerShape(DesignTokens.CornerRadius.md)),
                    shape = RoundedCornerShape(DesignTokens.CornerRadius.md),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RxAvatar(
                            imageUrl = user.avatarUrl,
                            drawableRes = user.avatarDrawableRes,
                            displayName = user.displayName,
                            size = 54.dp,
                            isVerified = user.isVerified,
                            onClick = { onUserClick(user) }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = user.displayName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "@${user.username}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        RxButton(
                            text = if (isFollowed) "Following" else "Follow",
                            onClick = {
                                isFollowed = !isFollowed
                                onFollowClick(user)
                            },
                            variant = if (isFollowed) RxButtonVariant.SECONDARY else RxButtonVariant.PRIMARY,
                            modifier = Modifier.fillMaxWidth().height(32.dp),
                            testTag = "btn_follow_${user.id}"
                        )
                    }
                }
            }
        }
    }
}

/**
 * Recommended Reels Carousel inside the Feed
 */
@Composable
fun FeedRecommendedReelsSection(
    reels: List<RxReel>,
    onReelClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    if (reels.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = DesignTokens.Colors.HeartRed,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Recommended Reels",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reels.take(6).indices.toList(), key = { it }) { index ->
                val reel = reels[index]
                Card(
                    modifier = Modifier
                        .width(130.dp)
                        .height(210.dp)
                        .clip(RoundedCornerShape(DesignTokens.CornerRadius.md))
                        .clickable { onReelClick(index) },
                    shape = RoundedCornerShape(DesignTokens.CornerRadius.md),
                    colors = CardDefaults.cardColors(containerColor = Color.Black)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (reel.posterDrawableRes != null) {
                            Image(
                                painter = painterResource(id = reel.posterDrawableRes),
                                contentDescription = reel.caption,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F172A)))
                        }

                        // Gradient Scrim
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(DesignTokens.Colors.ReelsScrim)
                        )

                        // Center Play Button
                        Surface(
                            shape = CircleShape,
                            color = Color.Black.copy(alpha = 0.5f),
                            modifier = Modifier.size(34.dp).align(Alignment.Center)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "Play Reel",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Bottom Text
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = reel.author.displayName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "▶ ${reel.likes}",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Multi-Image Carousel for Social Posts
 */
@Composable
fun MultiImageCarousel(
    images: List<Int>,
    modifier: Modifier = Modifier
) {
    if (images.isEmpty()) return

    val pagerState = rememberPagerState(pageCount = { images.size })

    Box(modifier = modifier.fillMaxWidth()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxWidth().aspectRatio(1.25f)
        ) { page ->
            Image(
                painter = painterResource(id = images[page]),
                contentDescription = "Post image ${page + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Indicator pills
        if (images.size > 1) {
            Surface(
                shape = RoundedCornerShape(DesignTokens.CornerRadius.full),
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                Text(
                    text = "${pagerState.currentPage + 1}/${images.size}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

/**
 * Rich Link Preview Card
 */
@Composable
fun LinkPreviewCard(
    preview: LinkPreviewData,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(DesignTokens.CornerRadius.md))
            .clickable { onClick() },
        shape = RoundedCornerShape(DesignTokens.CornerRadius.md),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Column {
            if (preview.imageRes != null) {
                Image(
                    painter = painterResource(id = preview.imageRes),
                    contentDescription = preview.title,
                    modifier = Modifier.fillMaxWidth().height(140.dp),
                    contentScale = ContentScale.Crop
                )
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = preview.domain.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = preview.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = preview.description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Post 3-Dot Options Dropdown Menu
 */
@Composable
fun PostOptionsMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    isSaved: Boolean,
    onToggleSave: () -> Unit,
    onHidePost: () -> Unit,
    onReportPost: () -> Unit,
    onCopyLink: () -> Unit,
    modifier: Modifier = Modifier
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        modifier = modifier
    ) {
        DropdownMenuItem(
            text = { Text(if (isSaved) "Remove from Saved" else "Save Post") },
            onClick = {
                onToggleSave()
                onDismiss()
            },
            leadingIcon = {
                Icon(
                    imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = null
                )
            }
        )
        DropdownMenuItem(
            text = { Text("Copy Link") },
            onClick = {
                onCopyLink()
                onDismiss()
            },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Link, contentDescription = null)
            }
        )
        DropdownMenuItem(
            text = { Text("Hide Post") },
            onClick = {
                onHidePost()
                onDismiss()
            },
            leadingIcon = {
                Icon(imageVector = Icons.Default.VisibilityOff, contentDescription = null)
            }
        )
        DropdownMenuItem(
            text = { Text("Report Post", color = MaterialTheme.colorScheme.error) },
            onClick = {
                onReportPost()
                onDismiss()
            },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            }
        )
    }
}
