package com.example.video

import kotlinx.coroutines.delay

/**
 * Backend API contract for cursor-based video feed pagination.
 */
interface VideoBackendApi {
    /**
     * Fetches a paginated slice of videos starting after the provided [cursor].
     * If [cursor] is null, fetches the initial page.
     */
    suspend fun fetchVideos(cursor: String?, limit: Int = 5): VideoFeedResponse
}

/**
 * Default backend implementation supporting cursor-based pagination.
 * Simulates network fetch latency and generates cursor-linked pages of streaming video content.
 */
class DefaultVideoBackendApi : VideoBackendApi {

    companion object {
        private val VIDEO_POOL = listOf(
            Triple(
                "https://vjs.zencdn.net/v/oceans.mp4",
                "Pacific Ocean Wonders",
                "Deep sea cinematography captured off the Polynesian barrier reef. 🌊 #ocean #marine #nature"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                "Chasing Mountain Trails",
                "High speed downhill gravel biking through the Alps at sunrise. 🚴‍♂️ #adventure #outdoors"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                "Nordic Winter Cabin",
                "Warm fires and snowy pines in northern Norway. Cozy vibes only. ❄️☕ #norway #cozy"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                "Tokyo Neon Nights",
                "Exploring Shinjuku alleyways and street food after dark. 🍜 #tokyo #travel #cyberpunk"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4",
                "Sunset Surf Session",
                "Golden hour waves rolling in at Uluwatu, Bali. Pure bliss. 🏄 #surf #sunset #bali"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                "Classic Muscle Heritage",
                "V8 rumble echoing through the canyon roads during the annual road rally. 🏎️💨 #cars"
            ),
            Triple(
                "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
                "Budget Track Car Build",
                "Taking our 1000 budget sports car to the test track! Will it survive lap 1? 🏁 #automotive"
            )
        )

        private val CREATORS = listOf(
            Triple("Aria Sterling", "@ariasterling", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&q=80"),
            Triple("Marcus Vance", "@marcusvance", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&q=80"),
            Triple("Elena Rostova", "@elenarostova", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&q=80"),
            Triple("Kaito Tanaka", "@kaitotravels", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&q=80"),
            Triple("Chloe Bennett", "@chloewaves", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&q=80")
        )
    }

    override suspend fun fetchVideos(cursor: String?, limit: Int): VideoFeedResponse {
        // Simulate real-world network latency (300ms)
        delay(300)

        // Parse page offset from cursor, e.g. "cursor_page_1" or start at page 0
        val page = cursor?.removePrefix("cursor_page_")?.toIntOrNull() ?: 0
        val startIndex = page * limit
        val maxTotalPages = 15 // Supports up to 75 videos continuously

        if (page >= maxTotalPages) {
            return VideoFeedResponse(items = emptyList(), nextCursor = null, hasMore = false)
        }

        val items = (0 until limit).map { i ->
            val globalIndex = startIndex + i
            val videoTemplate = VIDEO_POOL[globalIndex % VIDEO_POOL.size]
            val creator = CREATORS[globalIndex % CREATORS.size]
            val videoId = "vid_${page}_$i"
            val itemCursor = "cursor_page_${page + 1}"

            VideoPost(
                id = videoId,
                videoUrl = videoTemplate.first,
                title = videoTemplate.second,
                description = videoTemplate.third,
                thumbnailUrl = "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=400&q=80",
                authorName = creator.first,
                authorHandle = creator.second,
                authorAvatarUrl = creator.third,
                likesCount = 1200 + (globalIndex * 137 % 8900),
                commentsCount = 45 + (globalIndex * 23 % 350),
                sharesCount = 12 + (globalIndex * 7 % 90),
                durationMs = 15000L + (globalIndex * 2000L % 10000L),
                cursor = itemCursor
            )
        }

        val nextCursor = if (page + 1 < maxTotalPages) "cursor_page_${page + 1}" else null
        return VideoFeedResponse(
            items = items,
            nextCursor = nextCursor,
            hasMore = nextCursor != null
        )
    }
}
