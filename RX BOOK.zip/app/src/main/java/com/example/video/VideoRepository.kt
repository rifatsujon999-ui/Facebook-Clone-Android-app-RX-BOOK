package com.example.video

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import kotlinx.coroutines.flow.Flow

/**
 * Repository interface exposing cursor-paginated video streams and feed operations.
 */
interface VideoRepository {
    /**
     * Exposes a Flow of PagingData configured for cursor-based pagination.
     * Near-end scrolling triggers automatic prefetch according to [prefetchDistance].
     */
    fun getVideoFeedStream(
        pageSize: Int = 5,
        prefetchDistance: Int = 2
    ): Flow<PagingData<VideoPost>>

    /**
     * Direct query method for fetching a single page by cursor.
     */
    suspend fun fetchDirectFeed(cursor: String?, limit: Int = 5): VideoFeedResponse
}

/**
 * Standard implementation of [VideoRepository] backed by [VideoBackendApi] and Paging 3.
 */
class DefaultVideoRepository(
    private val backendApi: VideoBackendApi = DefaultVideoBackendApi()
) : VideoRepository {

    override fun getVideoFeedStream(
        pageSize: Int,
        prefetchDistance: Int
    ): Flow<PagingData<VideoPost>> {
        return Pager(
            config = PagingConfig(
                pageSize = pageSize,
                prefetchDistance = prefetchDistance,
                enablePlaceholders = false,
                initialLoadSize = pageSize
            ),
            pagingSourceFactory = { VideoPagingSource(backendApi) }
        ).flow
    }

    override suspend fun fetchDirectFeed(cursor: String?, limit: Int): VideoFeedResponse {
        return backendApi.fetchVideos(cursor = cursor, limit = limit)
    }

    companion object {
        val instance: VideoRepository by lazy {
            DefaultVideoRepository()
        }
    }
}
