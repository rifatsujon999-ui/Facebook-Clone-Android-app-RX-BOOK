package com.example.video

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Manages Media3 ExoPlayer instances for seamless video playback and preloading:
 * 1. Current video autoplay on active position
 * 2. Next video background preload to minimize buffer delay
 * 3. Graceful resource recycling & release
 */
@OptIn(UnstableApi::class)
class VideoPreloadManager(private val context: Context) {

    private var activePlayer: ExoPlayer? = null
    private var preloaderPlayer: ExoPlayer? = null

    private var currentActiveUrl: String? = null
    private var currentPreloadUrl: String? = null
    private var currentBoundPlayerView: PlayerView? = null

    private val httpDataSourceFactory by lazy {
        DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setUserAgent("RxBookVideoFeed/1.0")
    }

    private val mediaSourceFactory by lazy {
        DefaultMediaSourceFactory(context)
            .setDataSourceFactory(httpDataSourceFactory)
    }

    private val renderersFactory by lazy {
        DefaultRenderersFactory(context)
            .setEnableDecoderFallback(true)
    }

    private fun createExoPlayer(): ExoPlayer {
        return ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
            }
    }

    /**
     * Autoplays the video at [videoUrl] on the specified [playerView].
     * Pauses any existing active playback and releases previous bindings.
     */
    fun playCurrent(
        playerView: PlayerView,
        videoUrl: String,
        onBuffering: ((Boolean) -> Unit)? = null
    ) {
        if (currentActiveUrl == videoUrl && activePlayer != null) {
            // Already initialized for this URL
            if (currentBoundPlayerView != playerView) {
                currentBoundPlayerView?.player = null
                playerView.player = activePlayer
                currentBoundPlayerView = playerView
            }
            activePlayer?.playWhenReady = true
            return
        }

        // Check if preloaded player already has this exact URL buffered
        if (currentPreloadUrl == videoUrl && preloaderPlayer != null) {
            // Promote preloaded player to active player!
            activePlayer?.stop()
            activePlayer?.release()

            val promotedPlayer = preloaderPlayer!!
            preloaderPlayer = null
            currentPreloadUrl = null

            currentBoundPlayerView?.player = null
            playerView.player = promotedPlayer
            currentBoundPlayerView = playerView
            currentActiveUrl = videoUrl
            activePlayer = promotedPlayer

            promotedPlayer.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    onBuffering?.invoke(playbackState == Player.STATE_BUFFERING)
                }

                override fun onPlayerError(error: PlaybackException) {
                    onBuffering?.invoke(false)
                }
            })

            promotedPlayer.playWhenReady = true
            return
        }

        // Fresh player initialization
        activePlayer?.stop()
        activePlayer?.release()

        val newPlayer = createExoPlayer()
        currentBoundPlayerView?.player = null
        playerView.player = newPlayer
        currentBoundPlayerView = playerView
        currentActiveUrl = videoUrl
        activePlayer = newPlayer

        newPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                onBuffering?.invoke(playbackState == Player.STATE_BUFFERING)
            }

            override fun onPlayerError(error: PlaybackException) {
                onBuffering?.invoke(false)
            }
        })

        val mediaItem = MediaItem.fromUri(videoUrl)
        newPlayer.setMediaItem(mediaItem)
        newPlayer.prepare()
        newPlayer.playWhenReady = true
    }

    /**
     * Preloads the next video in sequence to warm up network cache and buffer ahead of time.
     */
    fun preloadNext(nextVideoUrl: String?) {
        if (nextVideoUrl.isNullOrBlank() || nextVideoUrl == currentActiveUrl || nextVideoUrl == currentPreloadUrl) {
            return
        }

        try {
            preloaderPlayer?.stop()
            preloaderPlayer?.release()

            val preloader = createExoPlayer().apply {
                playWhenReady = false // Preload only, do not play
                val mediaItem = MediaItem.fromUri(nextVideoUrl)
                setMediaItem(mediaItem)
                prepare()
            }

            preloaderPlayer = preloader
            currentPreloadUrl = nextVideoUrl
        } catch (e: Exception) {
            android.util.Log.e("VideoPreloadManager", "Preload failed gracefully: ${e.message}")
        }
    }

    /**
     * Pauses the currently playing video.
     */
    fun pauseCurrent() {
        activePlayer?.playWhenReady = false
    }

    /**
     * Resumes playback on the current video if paused.
     */
    fun resumeCurrent() {
        activePlayer?.playWhenReady = true
    }

    /**
     * Releases all players and cancels preloading. Call in onDestroy or when view is detached.
     */
    fun releaseAll() {
        activePlayer?.stop()
        activePlayer?.clearMediaItems()
        activePlayer?.release()
        activePlayer = null

        preloaderPlayer?.stop()
        preloaderPlayer?.clearMediaItems()
        preloaderPlayer?.release()
        preloaderPlayer = null

        currentBoundPlayerView?.player = null
        currentBoundPlayerView = null
        currentActiveUrl = null
        currentPreloadUrl = null
    }
}
