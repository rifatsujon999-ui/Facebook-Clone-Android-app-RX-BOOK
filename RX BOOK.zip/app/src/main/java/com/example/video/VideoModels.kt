package com.example.video

/**
 * Data model for a video feed post with cursor metadata for seamless pagination.
 */
data class VideoPost(
    val id: String,
    val videoUrl: String,
    val title: String = "",
    val description: String = "",
    val thumbnailUrl: String = "",
    val authorName: String = "Creator",
    val authorHandle: String = "@creator",
    val authorAvatarUrl: String = "",
    val likesCount: Int = 1240,
    val commentsCount: Int = 89,
    val sharesCount: Int = 42,
    val durationMs: Long = 15000L,
    val cursor: String = id
)

/**
 * API Response returned by backend containing cursor-based paginated results.
 */
data class VideoFeedResponse(
    val items: List<VideoPost>,
    val nextCursor: String?,
    val hasMore: Boolean
)
