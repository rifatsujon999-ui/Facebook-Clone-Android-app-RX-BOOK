package com.example.video

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.example.R

/**
 * PagingDataAdapter for vertical full-screen video feeds with Media3 ExoPlayer autoplay and preloading.
 */
class VideoPagingAdapter(
    private val preloadManager: VideoPreloadManager,
    private val onShareClick: ((VideoPost) -> Unit)? = null
) : PagingDataAdapter<VideoPost, VideoPagingAdapter.VideoViewHolder>(DIFF_CALLBACK) {

    inner class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val playerView: androidx.media3.ui.PlayerView = itemView.findViewById(R.id.playerView)
        val progressBar: ProgressBar = itemView.findViewById(R.id.videoProgressBar)
        val ivAuthorAvatar: ImageView = itemView.findViewById(R.id.ivAuthorAvatar)
        val tvAuthorName: TextView = itemView.findViewById(R.id.tvAuthorName)
        val tvAuthorHandle: TextView = itemView.findViewById(R.id.tvAuthorHandle)
        val tvVideoTitle: TextView = itemView.findViewById(R.id.tvVideoTitle)
        val tvVideoDescription: TextView = itemView.findViewById(R.id.tvVideoDescription)
        val tvLikesCount: TextView = itemView.findViewById(R.id.tvLikesCount)
        val tvCommentsCount: TextView = itemView.findViewById(R.id.tvCommentsCount)
        val tvSharesCount: TextView = itemView.findViewById(R.id.tvSharesCount)
        val btnLike: ImageView = itemView.findViewById(R.id.btnLike)
        val btnShare: ImageView = itemView.findViewById(R.id.btnShare)

        private var isLiked = false
        private var currentLikes = 0

        fun bind(post: VideoPost?) {
            if (post == null) return

            tvAuthorName.text = post.authorName
            tvAuthorHandle.text = post.authorHandle
            tvVideoTitle.text = post.title
            tvVideoDescription.text = post.description

            currentLikes = post.likesCount
            tvLikesCount.text = formatCount(currentLikes)
            tvCommentsCount.text = formatCount(post.commentsCount)
            tvSharesCount.text = formatCount(post.sharesCount)

            if (post.authorAvatarUrl.isNotBlank()) {
                ivAuthorAvatar.load(post.authorAvatarUrl) {
                    crossfade(true)
                    transformations(CircleCropTransformation())
                }
            }

            btnLike.setOnClickListener {
                isLiked = !isLiked
                if (isLiked) {
                    currentLikes++
                    btnLike.setColorFilter(android.graphics.Color.parseColor("#F43F5E"))
                    btnLike.animate().scaleX(1.25f).scaleY(1.25f).setDuration(150).withEndAction {
                        btnLike.animate().scaleX(1.0f).scaleY(1.0f).setDuration(150).start()
                    }.start()
                } else {
                    currentLikes--
                    btnLike.setColorFilter(android.graphics.Color.WHITE)
                }
                tvLikesCount.text = formatCount(currentLikes)
            }

            btnShare.setOnClickListener {
                onShareClick?.invoke(post)
            }
        }

        fun play(videoUrl: String) {
            progressBar.visibility = View.VISIBLE
            preloadManager.playCurrent(playerView, videoUrl) { isBuffering ->
                progressBar.visibility = if (isBuffering) View.VISIBLE else View.GONE
            }
        }

        fun pause() {
            preloadManager.pauseCurrent()
        }

        private fun formatCount(count: Int): String {
            return when {
                count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
                count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
                else -> count.toString()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_vertical_video_paging, parent, false)
        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<VideoPost>() {
            override fun areItemsTheSame(oldItem: VideoPost, newItem: VideoPost): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: VideoPost, newItem: VideoPost): Boolean {
                return oldItem == newItem
            }
        }
    }
}
