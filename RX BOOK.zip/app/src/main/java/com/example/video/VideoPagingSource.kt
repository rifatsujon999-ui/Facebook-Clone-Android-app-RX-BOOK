package com.example.video

import androidx.paging.PagingSource
import androidx.paging.PagingState

/**
 * Paging 3 PagingSource implementing cursor-based pagination for video feeds.
 * Uses cursor strings for sequential loading of video pages.
 */
class VideoPagingSource(
    private val backendApi: VideoBackendApi
) : PagingSource<String, VideoPost>() {

    override suspend fun load(params: LoadParams<String>): LoadResult<String, VideoPost> {
        return try {
            val cursor = params.key // null for initial page load
            val pageSize = params.loadSize

            val response = backendApi.fetchVideos(
                cursor = cursor,
                limit = pageSize
            )

            LoadResult.Page(
                data = response.items,
                prevKey = null, // Video feeds stream forward continuously
                nextKey = if (response.hasMore) response.nextCursor else null
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<String, VideoPost>): String? {
        // When refreshing, reload from the beginning or from the closest anchor cursor
        return state.anchorPosition?.let { anchorPosition ->
            state.closestItemToPosition(anchorPosition)?.cursor
        }
    }
}
