package com.example.model

enum class ReactionType(val label: String, val emoji: String) {
  LIKE("Like", "👍"),
  LOVE("Love", "❤️"),
  HAHA("Haha", "😆"),
  WOW("Wow", "😮"),
  SAD("Sad", "😢"),
  ANGRY("Angry", "😡")
}

data class SocialUser(
  val id: String,
  val username: String,
  val displayName: String,
  val avatarDrawableRes: Int = 0,
  val avatarUrl: String? = null,
  val email: String = "",
  val phone: String = "",
  val bio: String = "",
  val isVerified: Boolean = false,
  val isOnline: Boolean = false,
  val followersCount: Int = 1240,
  val followingCount: Int = 380,
  val friendsCount: Int = 642,
  val friendshipStatus: String = "FRIENDS" // NONE, PENDING, ACCEPTED, FRIENDS
)

data class SocialStory(
  val id: String,
  val user: SocialUser,
  val mediaDrawableRes: Int,
  val isUserStory: Boolean = false,
  val hasUnseen: Boolean = true
)

data class LinkPreviewData(
  val url: String,
  val title: String,
  val description: String,
  val domain: String,
  val imageRes: Int? = null
)

data class SocialPost(
  val id: String,
  val author: SocialUser,
  val content: String,
  val mediaDrawableRes: Int? = null,
  val multiImages: List<Int> = emptyList(),
  val linkPreview: LinkPreviewData? = null,
  val videoUrl: String? = null,
  val videoAspectRatio: String = "16:9", // "16:9" or "9:16"
  val isAiGenerated: Boolean = false,
  val timeAgo: String,
  val reactionCounts: Map<ReactionType, Int>,
  val userReaction: ReactionType? = null,
  val commentsCount: Int,
  val sharesCount: Int,
  val isSaved: Boolean = false,
  val isReposted: Boolean = false,
  val topCommentPreview: SocialComment? = null,
  val visibility: String = "PUBLIC" // PUBLIC, FRIENDS, ONLY_ME
)

data class SocialComment(
  val id: String,
  val postId: String,
  val author: SocialUser,
  val content: String,
  val timeAgo: String,
  val likesCount: Int = 0,
  val isLiked: Boolean = false,
  val parentCommentId: String? = null
)

data class ChatMessage(
  val id: String,
  val conversationId: String,
  val senderId: String,
  val text: String,
  val timestamp: String,
  val isFromMe: Boolean,
  val status: String = "READ" // SENT, DELIVERED, READ
)

data class ChatConversation(
  val id: String,
  val partner: SocialUser,
  val lastMessage: String,
  val lastMessageTime: String,
  val unreadCount: Int = 0,
  val isTyping: Boolean = false
)

data class NotificationItem(
  val id: String,
  val actor: SocialUser,
  val actionText: String,
  val timeAgo: String,
  val isRead: Boolean = false,
  val iconEmoji: String = "👍",
  val postPreview: String? = null
)

data class CommunityGroup(
  val id: String,
  val name: String,
  val description: String,
  val membersCount: Int,
  val category: String,
  val avatarDrawableRes: Int,
  val isJoined: Boolean = false,
  val privacy: String = "PUBLIC" // PUBLIC, PRIVATE
)

data class RxReel(
  val id: String,
  val hlsUrl: String,
  val blurHash: String = "LEHV6nWB2yk8pyo0adR*.7kCMdnj",
  val author: SocialUser,
  val caption: String,
  val likes: String = "124.5K",
  val likesCount: Int = 124500,
  val comments: String = "1,842",
  val commentsCount: Int = 1842,
  val shares: String = "14.2K",
  val audioTrackTitle: String = "Original Audio • DeepMind Veo Engine",
  val posterDrawableRes: Int? = null,
  val isLiked: Boolean = false,
  val isFollowing: Boolean = false
)
