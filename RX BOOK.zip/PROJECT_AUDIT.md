# PROJECT AUDIT REPORT: auraestate (RX BOOK Social Media Platform)
**Date:** September 16, 2026
**Auditor:** Senior Android Architect, UI/UX Engineer, Backend Architect, Performance & QA Engineer
**Target:** Production-grade social network combining Facebook Feed + Instagram Stories + TikTok Reels + Messenger + AI Video Creation

---

## 1. CURRENT ARCHITECTURE

### 1.1 Overview
The application is a hybrid Android project incorporating both **Jetpack Compose** (Material 3) for the primary UI (`MainActivity`, `RxBookScreens`, `RxBookComponents`, `RxReelsViewer`, `RxCallScreen`) and legacy **Android Views / XML Activities** (`LoginActivity`, `SignUpActivity`, `EditProfileActivity`, `FeedActivity`).

### 1.2 Module & Component Layout
- **Entry Points:**
  - `LoginActivity` (XML layout `activity_login.xml`) configured as the main launcher activity in `AndroidManifest.xml`.
  - `MainActivity` (Compose) hosting a 5-tab social scaffold (`NewsFeedScreen`, `SocialGraphScreen`, `MessengerScreen`, `NotificationsScreen`, `ProfileScreen`).
  - `FeedActivity` (XML layout `activity_feed.xml`) hosting vertical full-screen video with Paging 3.
  - `SignUpActivity` and `EditProfileActivity` (XML layouts).
- **Core Video & Media Pipeline:**
  - `VideoBackendApi` + `DefaultVideoBackendApi` (Cursor-based pagination simulation).
  - `VideoPagingSource` (Paging 3 implementation with cursor tokens).
  - `VideoRepository` + `DefaultVideoRepository` (Flow<PagingData<VideoPost>>).
  - `VideoPreloadManager` (AndroidX Media3 ExoPlayer with current video autoplay and next video pre-buffering).
  - `VideoPagingAdapter` (RecyclerView `PagingDataAdapter` with `PagerSnapHelper`).
  - `RxReelsViewer` (Compose `VerticalPager` with Media3 PlayerView interop and animation overlays).
- **AI & Video Creation:**
  - `VeoVideoService` (Google DeepMind Veo 3 / 2.0 long-running REST client with fallback to curated high-performance streams).
  - `RxBookVeoVideoModal` (Aspect ratio selection 16:9 / 9:16, prompt generation, live polling, and publishing to feed).
- **Signaling & Communications:**
  - `RxNestJsSignalingManager` (Full-duplex WebRTC SDP Offer/Answer, dynamic ICE candidate exchange simulation, call metrics telemetry).
  - `RxCallOverlay` & `RxCallScreen` (Floating PiP and full-screen video/audio calling interface).
  - `RxBookMessengerSheet` (Bottom sheet conversation viewer with socket dispatch simulation and typing states).
- **Persistence & Cloud:**
  - Firebase Authentication, Firestore, and Storage (optional / remote).
  - `RxBookRepository` (In-memory reactive repository with Firebase synchronization hooks).
  - Room Database dependencies declared in `build.gradle.kts`.

---

## 2. CURRENT FEATURES

1. **Social Feed (NewsFeedScreen):**
   - Top search header with notification & profile shortcuts.
   - Stories tray with unseen ring indicator and "Add Story" affordance.
   - Post creation card with text, image, and Veo AI video action.
   - Feed filtering by category (All, Technology, Lifestyle, Design, AI Labs).
   - Post reactions (Like, Love, Haha, Wow, Sad, Angry) with counter toggling.
   - Post comments sheet modal with instant thread updates.
   - Share to timeline action.
2. **Reels Engine (RxReelsViewer & FeedActivity):**
   - 9:16 full-screen vertical swipe interface.
   - Media3 ExoPlayer playback with autoplay on settled page.
   - Background pre-buffering for upcoming items.
   - Sound mute/unmute toggle.
   - Double-tap like animation with heart overlay.
   - Comment sheet and share dialog triggers.
3. **AI Video Creator (VeoVideoService & RxBookVeoVideoModal):**
   - Aspect ratio selection (16:9 landscape or 9:16 portrait for Reels).
   - Prompt input with curated suggestions.
   - Asynchronous polling with status feedback.
   - Direct publication to social feed.
4. **Messenger & Calling:**
   - Conversation list with typing indicators and online badges.
   - Direct message thread with optimistic message dispatch.
   - Peer-to-peer WebRTC video/audio call simulation with stats (RTT, jitter, resolution).
5. **Profile & Account:**
   - Cover photo, profile picture, verification badge, bio, stats (Followers, Following, Friends).
   - `EditProfileActivity` supporting Android Photo Picker and Firebase profile synchronization.
   - Firebase Email/Password Login, Sign Up, and Password Reset.

---

## 3. BROKEN & FRAGILE AREAS

1. **Authentication Bottleneck / Dead-End:**
   - `LoginActivity` is the launcher activity. If Firebase credentials or internet are absent or credentials fail, the user is trapped without a "Continue as Guest" or offline demo access.
   - Localization inconsistency: hardcoded Bengali error toasts mixed with English strings.
2. **Deprecated Material 3 APIs:**
   - Multiple warnings for deprecated `androidx.compose.material3.Divider` (should be `HorizontalDivider`).
   - Deprecated `Icons.Filled.Send`, `Icons.Filled.VolumeUp`, `Icons.Filled.VolumeMute` (should use `Icons.AutoMirrored` or direct vectors).
   - Deprecated `window.statusBarColor` in `Theme.kt`.
3. **Reels Viewer Dialog Isolation:**
   - In `MainActivity.kt`, `RxReelsViewer` is launched inside an `androidx.compose.ui.window.Dialog`. While functional, this can lead to window leak warnings if dismissed abruptly during orientation or system back navigation.
4. **Multiple Inconsistent Player Implementations:**
   - `RxReelsViewer.kt`, `VideoAdapter.kt`, `VideoFeedComposeScreen.kt`, and `VideoPagingAdapter.kt` have slightly different ExoPlayer lifecycle handling. Unifying through `VideoPreloadManager` ensures zero audio leaks.

---

## 4. MISSING FEATURES (Per Specification)

1. **Design System:** Unified light/dark theme with comprehensive tokens for elevation, skeletons, state indicators, and typography across both Compose and XML.
2. **Infinite Pagination in Feed & Reels:** While Paging 3 was built for `FeedActivity`, the main Compose `NewsFeedScreen` uses a static in-memory post list rather than a paginated flow.
3. **Optimistic UI Engine with Rollback:** Liking/commenting directly modifies local state, but lacks an explicit network failure rollback and retry mechanism.
4. **Advanced Profile Tabs:** Profile lacks dedicated tabs for POSTS, REELS, PHOTOS, ABOUT, SAVED, and distinct views for own vs. other user profiles (Follow/Message/Block).
5. **Stories 2.0 Viewer & Creator:** Stories currently open as a static preview; needs full-screen viewer with segment progress bars, tap left/right, pause on hold, and interactive story reactions.
6. **Video Upload Pipeline:** Video selection, validation, compression simulation, thumbnail generation, captions, hashtags, and 0-100% progress tracking.
7. **Settings & Data Saver:** Settings screen with Privacy, Playback (Autoplay toggle), Data Saver (low res / reduced preload), and Appearance controls.
8. **Content Moderation & Report:** UI actions to report post/reel/user, block/mute user, and filter inappropriate content.
9. **Analytics Abstraction:** Pluggable event tracker interface with standard social events.

---

## 5. TECHNICAL DEBT & CODE QUALITY

1. **Monolithic UI Files:**
   - `RxBookScreens.kt` (971 lines) contains NewsFeed, Messenger, SocialGraph, Notifications, and Profile in a single file. Modularization into distinct screen files will improve maintainability.
   - `RxBookComponents.kt` (1300+ lines) needs modular decomposition.
2. **Memory Leaks & ExoPlayer Management:**
   - Player instances must strictly release codecs and surfaces when navigating across tabs to prevent OOM errors on low-memory devices.
3. **Stable Identifiers:**
   - Ensure all list items in Compose have stable keys (`key = { it.id }`) to eliminate unnecessary recompositions during feed updates.

---

## 6. PERFORMANCE & SECURITY RISKS

1. **Security:**
   - API keys (e.g. Gemini) are read from `BuildConfig.GEMINI_API_KEY` with graceful checks. Never hardcode credentials in code.
   - Firebase rules and Firestore queries must enforce user ownership.
2. **Performance:**
   - Bitmaps loaded via resources need Coil caching and sampling to avoid raster overhead.
   - PlayerView in Compose must avoid recreation on every recomposition.

---

## 7. RECOMMENDED TARGET ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                       │
│  - Jetpack Compose (M3) + Unified Design System             │
│  - Modular Screens (Feed, Stories, Reels, Chat, Profile)    │
│  - ViewModel + StateFlow (UI State, Events, Effects)        │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│                      Domain Layer                           │
│  - Use Cases & Repository Contracts                         │
│  - Analytics & Moderation Interfaces                        │
│  - Optimistic Mutation Engine (Action -> Optimistic -> Sync)│
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│                       Data Layer                            │
│  - Paging 3 (Cursor-based PagingSource)                     │
│  - Local Storage (Preferences DataStore / Cache / Room)     │
│  - Media3 Engine (VideoPreloadManager + Player Pooling)     │
│  - Remote Services (Firebase Auth/Firestore, Veo AI, Mock)  │
└─────────────────────────────────────────────────────────────┘
```
